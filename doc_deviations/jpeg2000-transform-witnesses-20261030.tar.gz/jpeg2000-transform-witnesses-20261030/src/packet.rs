use crate::{
    DecodeError, MalformedKind, Resource, ResourceLimits,
    codestream::{ProgressionChange, ProgressionChanges, ProgressionOrder, TilePartPayload},
    tier1::{SubbandOrientation, Tier1CodeBlockDecoder, Tier1CodingStyle},
};

#[cfg(verus_keep_ghost)]
use vstd::prelude::*;

const MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION: usize = 164;
const SOP_MARKER: [u8; 2] = [0xff, 0x91];
const EPH_MARKER: [u8; 2] = [0xff, 0x92];

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct PacketBitReader<'a> {
    input: &'a [u8],
    byte_index: usize,
    current_byte: u8,
    bits_remaining: u8,
    previous_byte_was_ff: bool,
    bits_read: u64,
    maximum_work_units: u64,
    maximum_header_bytes: u64,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_bit_reader_view(reader: &PacketBitReader<'_>) -> crate::specs::Part1PacketReaderState {
        crate::specs::Part1PacketReaderState {
            input: reader.input@, byte_index: reader.byte_index, current_byte: reader.current_byte,
            bits_remaining: reader.bits_remaining, previous_byte_was_ff: reader.previous_byte_was_ff,
            bits_read: reader.bits_read, maximum_work_units: reader.maximum_work_units,
            maximum_header_bytes: reader.maximum_header_bytes,
        }
    }

    pub open spec fn packet_reader_outcome(result: Result<PacketBitReader<'_>, DecodeError>)
        -> Result<crate::specs::Part1PacketReaderState, DecodeError>
    {
        match result { Ok(reader) => Ok(packet_bit_reader_view(&reader)), Err(error) => Err(error) }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_reader_error(offset, kind),
))]
pub(crate) fn packet_reader_error(offset: usize, kind: MalformedKind) -> DecodeError {
    DecodeError::MalformedInput {
        offset: offset as u64,
        kind,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_reader_limit(resource, limit, actual),
))]
fn packet_reader_limit(resource: Resource, limit: u64, actual: u64) -> DecodeError {
    DecodeError::LimitExceeded {
        resource,
        limit,
        actual,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_bit_reader_view(&result) == crate::specs::part1_packet_reader_prefix(input@, header_limit, work_limit),
))]
pub(crate) fn packet_reader_prefix_from_input(
    input: &[u8],
    header_limit: u64,
    work_limit: u64,
) -> PacketBitReader<'_> {
    PacketBitReader {
        input,
        byte_index: 0,
        current_byte: 0,
        bits_remaining: 0,
        previous_byte_was_ff: false,
        bits_read: 0,
        maximum_work_units: work_limit,
        maximum_header_bytes: header_limit,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_reader_outcome(result) == crate::specs::part1_packet_reader_initial(input@, header_limit, work_limit),
))]
pub(crate) fn packet_reader_from_input(
    input: &[u8],
    header_limit: u64,
    work_limit: u64,
) -> Result<PacketBitReader<'_>, DecodeError> {
    let input_length = input.len() as u64;
    if input_length > header_limit {
        return Err(packet_reader_limit(
            Resource::PacketHeaderBytes,
            header_limit,
            input_length,
        ));
    }
    Ok(packet_reader_prefix_from_input(
        input,
        header_limit,
        work_limit,
    ))
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_reader_outcome(result) == crate::specs::part1_packet_reader_initial(
        input@, crate::limits::resource_packet_header_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
pub(crate) fn packet_reader_new<'a>(
    input: &'a [u8],
    limits: &ResourceLimits,
) -> Result<PacketBitReader<'a>, DecodeError> {
    packet_reader_from_input(
        input,
        limits.maximum_packet_header_bytes(),
        limits.maximum_work_units(),
    )
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_bit_reader_view(&result) == crate::specs::part1_packet_reader_prefix(
        input@, crate::limits::resource_packet_header_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
pub(crate) fn packet_reader_prefix<'a>(
    input: &'a [u8],
    limits: &ResourceLimits,
) -> PacketBitReader<'a> {
    packet_reader_prefix_from_input(
        input,
        limits.maximum_packet_header_bytes(),
        limits.maximum_work_units(),
    )
}

impl<'a> PacketBitReader<'a> {
    pub fn new(input: &'a [u8], limits: &ResourceLimits) -> Result<Self, DecodeError> {
        packet_reader_new(input, limits)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == packet_bit_reader_view(self).bits_read,))]
    pub const fn bits_read(&self) -> u64 {
        self.bits_read
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == packet_bit_reader_view(self).byte_index,))]
    pub const fn bytes_consumed(&self) -> usize {
        self.byte_index
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == (packet_bit_reader_view(self).bits_remaining == 0),))]
    pub const fn is_byte_aligned(&self) -> bool {
        self.bits_remaining == 0
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(
        ensures packet_bit_reader_view(final(self)) == (crate::specs::Part1PacketReaderState {
            bits_remaining: 0, ..packet_bit_reader_view(old(self))
        }),
    ))]
    pub fn align_to_byte(&mut self) {
        self.bits_remaining = 0;
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, packet_bit_reader_view(final(self))) == crate::specs::part1_packet_reader_read(packet_bit_reader_view(old(self))),
    ))]
    pub fn read_bit(&mut self) -> Result<bool, DecodeError> {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_reader_read); }
        if self.bits_remaining == 0 {
            self.load_byte()?;
        }
        if self.bits_remaining == 0 || self.bits_remaining > 8 {
            return Err(packet_reader_error(
                self.byte_index,
                MalformedKind::InvalidBitStuffing,
            ));
        }
        self.bits_remaining = match self.bits_remaining.checked_sub(1) {
            Some(count) => count,
            None => {
                return Err(packet_reader_error(
                    self.byte_index,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        let bit = crate::refinement::packet_bit(self.current_byte, self.bits_remaining);
        self.bits_read = match self.bits_read.checked_add(1) {
            Some(count) => count,
            None => {
                return Err(packet_reader_error(
                    self.byte_index,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        if self.bits_read > self.maximum_work_units {
            return Err(packet_reader_limit(
                Resource::WorkUnits,
                self.maximum_work_units,
                self.bits_read,
            ));
        }
        Ok(bit)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, packet_bit_reader_view(final(self))) == crate::specs::part1_packet_reader_read_bits(packet_bit_reader_view(old(self)), count),
    ))]
    pub fn read_bits(&mut self, count: u8) -> Result<u32, DecodeError> {
        #[cfg(verus_keep_ghost)]
        proof_decl! { let ghost initial = packet_bit_reader_view(self); }
        if count > 32 {
            return Err(packet_reader_error(
                self.byte_index,
                MalformedKind::InvalidMarkerLength,
            ));
        }
        let mut value = 0_u32;
        let mut read = 0_u8;
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant read <= count,
                    count <= 32, initial == packet_bit_reader_view(old(self)),
                    crate::specs::part1_packet_reader_read_bits(initial, count)
                        == crate::specs::part1_packet_reader_word(packet_bit_reader_view(self), (count - read) as nat, value),
                decreases count - read,
            )
        )]
        while read < count {
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_packet_reader_word); }
            value <<= 1;
            #[cfg(verus_keep_ghost)]
            proof! { assert(value | 0u32 == value) by(bit_vector); }
            if self.read_bit()? {
                value |= 1;
            }
            read = match read.checked_add(1) {
                Some(count) => count,
                None => {
                    return Err(packet_reader_error(
                        self.byte_index,
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_reader_word); }
        Ok(value)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, packet_bit_reader_view(final(self))) == crate::specs::part1_packet_reader_load(packet_bit_reader_view(old(self))),
    ))]
    fn load_byte(&mut self) -> Result<(), DecodeError> {
        if self.byte_index as u64 >= self.maximum_header_bytes {
            let actual = match (self.byte_index as u64).checked_add(1) {
                Some(actual) => actual,
                None => {
                    return Err(packet_reader_error(
                        self.byte_index,
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
            return Err(packet_reader_limit(
                Resource::PacketHeaderBytes,
                self.maximum_header_bytes,
                actual,
            ));
        }
        if self.byte_index >= self.input.len() {
            return Err(packet_reader_error(
                self.byte_index,
                MalformedKind::Truncated,
            ));
        }
        let byte = self.input[self.byte_index];
        if self.previous_byte_was_ff && byte & 0x80 != 0 {
            return Err(packet_reader_error(
                self.byte_index,
                MalformedKind::InvalidBitStuffing,
            ));
        }
        self.byte_index = match self.byte_index.checked_add(1) {
            Some(index) => index,
            None => {
                return Err(packet_reader_error(
                    self.byte_index,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        self.current_byte = byte;
        self.bits_remaining = crate::refinement::packet_data_bits(self.previous_byte_was_ff);
        self.previous_byte_was_ff = byte == 0xff;
        Ok(())
    }
}

#[cfg_attr(not(verus_keep_ghost), derive(Clone, Debug, Eq, PartialEq))]
pub struct PacketGrid {
    layers: u16,
    components: u16,
    resolutions: u8,
    component_resolutions: Vec<u8>,
    maximum_precincts_per_resolution: u32,
    precinct_counts: Vec<u32>,
    precinct_offsets: Vec<usize>,
    candidate_count: u64,
    packet_count: u64,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_grid_view(grid: &PacketGrid) -> crate::specs::Part1PacketGrid {
        crate::specs::Part1PacketGrid {
            layers:grid.layers, components:grid.components, resolutions:grid.resolutions,
            component_resolutions:grid.component_resolutions@,
            maximum_precincts_per_resolution:grid.maximum_precincts_per_resolution,
            precinct_counts:grid.precinct_counts@, precinct_offsets:grid.precinct_offsets@,
            candidate_count:grid.candidate_count, packet_count:grid.packet_count,
        }
    }
    pub open spec fn packet_grid_outcome(value:Result<PacketGrid,DecodeError>) -> Result<crate::specs::Part1PacketGrid,DecodeError> {
        match value {Ok(grid)=>Ok(packet_grid_view(&grid)),Err(error)=>Err(error)}
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_grid_resolution_summary(values@, 0, 0, false),
))]
fn packet_grid_resolution_summary(values: &[u8]) -> Result<(u8, bool), DecodeError> {
    let mut maximum = 0_u8;
    let mut zero = false;
    let mut index = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_grid_resolution_summary); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant index <= values@.len(),
            crate::specs::part1_grid_resolution_summary(values@, 0, 0, false)
                == crate::specs::part1_grid_resolution_summary(values@, index, maximum, zero),
        decreases values@.len() - index,
    ))]
    while index < values.len() {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_grid_resolution_summary); }
        let resolution = match values.get(index) {
            Some(resolution) => *resolution,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        if resolution == 0 {
            zero = true;
        }
        maximum = maximum.max(resolution);
        index = match index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_grid_resolution_summary); }
    Ok((maximum, zero))
}

struct PacketGridCountState {
    index: usize,
    component: usize,
    resolution: usize,
    total: u64,
    maximum: u32,
    offsets: Vec<usize>,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_grid_count_view(value: &PacketGridCountState) -> crate::specs::Part1GridCountState {
        crate::specs::Part1GridCountState {
            index:value.index,component:value.component,resolution:value.resolution,total:value.total,
            maximum:value.maximum,offsets:value.offsets@,
        }
    }
    pub open spec fn packet_grid_count_outcome(value:Result<PacketGridCountState,DecodeError>)
        -> Result<crate::specs::Part1GridCountState,DecodeError> {
        match value { Ok(state) => Ok(packet_grid_count_view(&state)),Err(error)=>Err(error) }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_grid_count_outcome(result) == crate::specs::part1_grid_count_summary(
        counts@,component_resolutions@,resolutions,expected),
))]
fn packet_grid_count_summary(
    counts: &[u32],
    component_resolutions: &[u8],
    resolutions: u8,
    expected: usize,
) -> Result<PacketGridCountState, DecodeError> {
    let capacity = match expected.checked_add(1) {
        Some(capacity) => capacity,
        None => return Err(packet_arithmetic_overflow()),
    };
    let mut state = PacketGridCountState {
        index: 0,
        component: 0,
        resolution: 0,
        total: 0,
        maximum: 0,
        offsets: Vec::with_capacity(capacity),
    };
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_grid_count_summary_run); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant state.index <= counts@.len(),
            crate::specs::part1_grid_count_summary(counts@,component_resolutions@,resolutions,expected)
            == crate::specs::part1_grid_count_summary_run(counts@,component_resolutions@,resolutions,packet_grid_count_view(&state)),
        decreases counts@.len()-state.index,
    ))]
    while state.index < counts.len() {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_grid_count_summary_run); }
        let offset = match usize::try_from(state.total) {
            Ok(offset) => offset,
            Err(_) => return Err(packet_arithmetic_overflow()),
        };
        state.offsets.push(offset);
        let precincts = counts[state.index];
        let available = match component_resolutions.get(state.component) {
            Some(count) => usize::from(*count),
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        if state.resolution >= available && precincts != 0 {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        state.total = match state.total.checked_add(u64::from(precincts)) {
            Some(total) => total,
            None => return Err(packet_arithmetic_overflow()),
        };
        if precincts > state.maximum {
            state.maximum = precincts;
        }
        state.index = match state.index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        state.resolution = match state.resolution.checked_add(1) {
            Some(resolution) => resolution,
            None => return Err(packet_arithmetic_overflow()),
        };
        if state.resolution == usize::from(resolutions) {
            state.resolution = 0;
            state.component = match state.component.checked_add(1) {
                Some(component) => component,
                None => return Err(packet_arithmetic_overflow()),
            };
        }
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_grid_count_summary_run); }
    let offset = match usize::try_from(state.total) {
        Ok(offset) => offset,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    state.offsets.push(offset);
    Ok(state)
}

#[cfg(verus_keep_ghost)]
verus! {
    pub open spec fn packet_selection_view(value:Option<&[u8]>) -> Option<Seq<u8>> {
        match value {Some(counts)=>Some(counts@),None=>None}
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_grid_selected_precincts(
        packet_selection_view(selection),component_resolutions@,counts@,resolutions,components,initial_total),
))]
fn packet_grid_selected_precincts(
    selection: Option<&[u8]>,
    component_resolutions: &[u8],
    counts: &[u32],
    resolutions: u8,
    components: u16,
    initial_total: u64,
) -> Result<u64, DecodeError> {
    let Some(selected) = selection else {
        return Ok(initial_total);
    };
    if selected.len() != usize::from(components) {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    let mut total = 0_u64;
    let mut component = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_grid_selected_components);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant component<=selected@.len(),
            packet_selection_view(selection)==Some(selected@),
            selected@.len()==components as nat,
            crate::specs::part1_grid_selected_precincts(packet_selection_view(selection),component_resolutions@,counts@,resolutions,components,initial_total)
                ==crate::specs::part1_grid_selected_components(selected@,component_resolutions@,counts@,resolutions,component,total),
        decreases selected@.len()-component,
    ))]
    while component < selected.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_grid_selected_components);}
        let count = match selected.get(component) {
            Some(count) => *count,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        let available = match component_resolutions.get(component) {
            Some(count) => *count,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        if count == 0 || count > available {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        let mut resolution = 0_u8;
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_grid_selected_row);}
        #[cfg_attr(verus_keep_ghost,verus_spec(
            invariant resolution<=count,
                packet_selection_view(selection)==Some(selected@),
                selected@.len()==components as nat,
                crate::specs::part1_grid_selected_precincts(packet_selection_view(selection),component_resolutions@,counts@,resolutions,components,initial_total)
                    ==match crate::specs::part1_grid_selected_row(counts@,resolutions,component,resolution,count,total) {
                        Err(error)=>Err(error),
                        Ok(total)=>crate::specs::part1_grid_selected_components(
                            selected@,component_resolutions@,counts@,resolutions,(component+1) as usize,total),
                    },
            decreases count-resolution,
        ))]
        while resolution < count {
            #[cfg(verus_keep_ghost)]
            proof! {reveal(crate::specs::part1_grid_selected_row);}
            let product = match component.checked_mul(usize::from(resolutions)) {
                Some(product) => product,
                None => return Err(packet_arithmetic_overflow()),
            };
            let index = match product.checked_add(usize::from(resolution)) {
                Some(index) => index,
                None => return Err(packet_arithmetic_overflow()),
            };
            let amount = match counts.get(index) {
                Some(amount) => u64::from(*amount),
                None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
            };
            total = match total.checked_add(amount) {
                Some(total) => total,
                None => return Err(packet_arithmetic_overflow()),
            };
            resolution = match resolution.checked_add(1) {
                Some(value) => value,
                None => return Err(packet_arithmetic_overflow()),
            };
        }
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_grid_selected_row);}
        component = match component.checked_add(1) {
            Some(value) => value,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_grid_selected_components);}
    Ok(total)
}

impl PacketGrid {
    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_packet_grid_total_precincts(packet_grid_view(self)),
    ))]
    pub fn total_precinct_count(&self) -> Result<u64, DecodeError> {
        match self.packet_count.checked_div(u64::from(self.layers)) {
            Some(count) => Ok(count),
            None => Err(packet_arithmetic_overflow()),
        }
    }

    pub fn new(
        layers: u16,
        components: u16,
        resolutions: u8,
        precinct_counts: Vec<u32>,
        limits: &ResourceLimits,
    ) -> Result<Self, DecodeError> {
        Self::new_with_component_resolutions(
            layers,
            components,
            vec![resolutions; usize::from(components)],
            precinct_counts,
            limits,
        )
    }

    pub(crate) fn new_with_component_resolutions(
        layers: u16,
        components: u16,
        component_resolutions: Vec<u8>,
        precinct_counts: Vec<u32>,
        limits: &ResourceLimits,
    ) -> Result<Self, DecodeError> {
        packet_grid_new_with_component_resolutions(
            layers,
            components,
            component_resolutions,
            precinct_counts,
            limits,
        )
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures packet_grid_outcome(result)==crate::specs::part1_packet_grid_new(
        layers,components,component_resolutions@,precinct_counts@,None,limits),
))]
pub(crate) fn packet_grid_new_with_component_resolutions(
    layers: u16,
    components: u16,
    component_resolutions: Vec<u8>,
    precinct_counts: Vec<u32>,
    limits: &ResourceLimits,
) -> Result<PacketGrid, DecodeError> {
    packet_grid_new_with_selected_resolutions(
        layers,
        components,
        component_resolutions,
        precinct_counts,
        None,
        limits,
    )
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures packet_grid_outcome(result)==crate::specs::part1_packet_grid_new(
        layers,components,component_resolutions@,precinct_counts@,packet_selection_view(selected_resolution_counts),limits),
))]
pub(crate) fn packet_grid_new_with_selected_resolutions(
    layers: u16,
    components: u16,
    component_resolutions: Vec<u8>,
    precinct_counts: Vec<u32>,
    selected_resolution_counts: Option<&[u8]>,
    limits: &ResourceLimits,
) -> Result<PacketGrid, DecodeError> {
    let (resolutions, has_zero_resolution) =
        packet_grid_resolution_summary(&component_resolutions)?;
    if layers == 0 || components == 0 {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    if resolutions == 0 {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    if component_resolutions.len() != usize::from(components) || has_zero_resolution {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    if layers > limits.maximum_layers() {
        return Err(packet_reader_limit(
            Resource::Layers,
            u64::from(limits.maximum_layers()),
            u64::from(layers),
        ));
    }
    if components > limits.maximum_components() {
        return Err(packet_reader_limit(
            Resource::Components,
            u64::from(limits.maximum_components()),
            u64::from(components),
        ));
    }
    if resolutions > limits.maximum_resolutions_per_component() {
        return Err(packet_reader_limit(
            Resource::Resolutions,
            u64::from(limits.maximum_resolutions_per_component()),
            u64::from(resolutions),
        ));
    }
    let expected_counts = match usize::from(components).checked_mul(usize::from(resolutions)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    if precinct_counts.len() != expected_counts {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }

    let summary = packet_grid_count_summary(
        &precinct_counts,
        &component_resolutions,
        resolutions,
        expected_counts,
    )?;
    let total_precincts = summary.total;
    let maximum_precincts_per_resolution = summary.maximum;
    let precinct_offsets = summary.offsets;
    let selected_precincts = packet_grid_selected_precincts(
        selected_resolution_counts,
        &component_resolutions,
        &precinct_counts,
        resolutions,
        components,
        total_precincts,
    )?;
    if selected_precincts > limits.maximum_precincts() {
        return Err(packet_reader_limit(
            Resource::Precincts,
            limits.maximum_precincts(),
            selected_precincts,
        ));
    }
    let packet_count = match total_precincts.checked_mul(u64::from(layers)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    let selected_packet_count = match selected_precincts.checked_mul(u64::from(layers)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    if selected_packet_count > limits.maximum_packets() {
        return Err(packet_reader_limit(
            Resource::Packets,
            limits.maximum_packets(),
            selected_packet_count,
        ));
    }
    let first = match u64::from(layers).checked_mul(u64::from(components)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    let second = match first.checked_mul(u64::from(resolutions)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    let candidate_count = match second.checked_mul(u64::from(maximum_precincts_per_resolution)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    if candidate_count > limits.maximum_work_units() {
        return Err(packet_reader_limit(
            Resource::WorkUnits,
            limits.maximum_work_units(),
            candidate_count,
        ));
    }
    Ok(PacketGrid {
        layers,
        components,
        resolutions,
        component_resolutions,
        maximum_precincts_per_resolution,
        precinct_counts,
        precinct_offsets,
        candidate_count,
        packet_count,
    })
}

impl PacketGrid {
    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == packet_grid_view(self).packet_count,))]
    pub const fn packet_count(&self) -> u64 {
        self.packet_count
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_packet_grid_selected_count(packet_grid_view(self), resolution_counts@),
    ))]
    pub(crate) fn selected_packet_count(
        &self,
        resolution_counts: &[u8],
    ) -> Result<u64, DecodeError> {
        if resolution_counts.len() != usize::from(self.components) {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_selected_count_run); }
        let mut precincts = 0_u64;
        let mut component = 0_u16;
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant component <= self.components,
                    crate::specs::part1_packet_grid_selected_count(packet_grid_view(self), resolution_counts@)
                        == crate::specs::part1_packet_selected_count_run(packet_grid_view(self), resolution_counts@, component, precincts),
                decreases self.components - component,
            )
        )]
        while component < self.components {
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_packet_selected_count_run); }
            let count = match resolution_counts.get(usize::from(component)) {
                Some(count) => *count,
                None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
            };
            if count == 0 {
                return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
            }
            let available = match self.component_resolutions.get(usize::from(component)) {
                Some(count) => *count,
                None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
            };
            if count > available {
                return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
            }
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_packet_selected_row); }
            let mut resolution = 0_u8;
            #[cfg_attr(
                verus_keep_ghost,
                verus_spec(
                    invariant resolution <= count,
                        crate::specs::part1_packet_grid_selected_count(packet_grid_view(self), resolution_counts@)
                            == match crate::specs::part1_packet_selected_row(packet_grid_view(self), component, resolution, count, precincts) {
                                Err(error) => Err(error),
                                Ok(total) => crate::specs::part1_packet_selected_count_run(
                                    packet_grid_view(self), resolution_counts@, (component + 1) as u16, total),
                            },
                    decreases count - resolution,
                )
            )]
            while resolution < count {
                #[cfg(verus_keep_ghost)]
                proof! {
                    reveal(crate::specs::part1_packet_selected_count_run);
                    reveal(crate::specs::part1_packet_selected_row);
                }
                let amount = u64::from(self.precinct_count(component, resolution)?);
                precincts = match precincts.checked_add(amount) {
                    Some(total) => total,
                    None => return Err(packet_arithmetic_overflow()),
                };
                resolution = match resolution.checked_add(1) {
                    Some(resolution) => resolution,
                    None => return Err(packet_arithmetic_overflow()),
                };
            }
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_packet_selected_row); }
            component = match component.checked_add(1) {
                Some(component) => component,
                None => return Err(packet_arithmetic_overflow()),
            };
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_selected_count_run); }
        match precincts.checked_mul(u64::from(self.layers)) {
            Some(total) => Ok(total),
            None => Err(packet_arithmetic_overflow()),
        }
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_packet_grid_precinct_count(packet_grid_view(self), component, resolution),
    ))]
    pub fn precinct_count(&self, component: u16, resolution: u8) -> Result<u32, DecodeError> {
        if component >= self.components || resolution >= self.resolutions {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        let component_resolution_count =
            match self.component_resolutions.get(usize::from(component)) {
                Some(count) => *count,
                None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
            };
        if resolution >= component_resolution_count {
            return Ok(0);
        }
        let product = match usize::from(component).checked_mul(usize::from(self.resolutions)) {
            Some(product) => product,
            None => return Err(packet_arithmetic_overflow()),
        };
        let index = match product.checked_add(usize::from(resolution)) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        if index >= self.precinct_counts.len() {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        Ok(self.precinct_counts[index])
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_packet_grid_precinct_index(packet_grid_view(self), component, resolution, precinct),
    ))]
    pub fn precinct_index(
        &self,
        component: u16,
        resolution: u8,
        precinct: u32,
    ) -> Result<usize, DecodeError> {
        let count = self.precinct_count(component, resolution)?;
        if precinct >= count {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }

        let product = match usize::from(component).checked_mul(usize::from(self.resolutions)) {
            Some(product) => product,
            None => return Err(packet_arithmetic_overflow()),
        };
        let component_resolution = match product.checked_add(usize::from(resolution)) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        let start = match self.precinct_offsets.get(component_resolution) {
            Some(start) => *start,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        let precinct = match usize::try_from(precinct) {
            Ok(precinct) => precinct,
            Err(_) => return Err(packet_arithmetic_overflow()),
        };
        match start.checked_add(precinct) {
            Some(index) => Ok(index),
            None => Err(packet_arithmetic_overflow()),
        }
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,packet_precinct_view(final(precinct)))==crate::specs::part1_jpip_precinct_packet(
        packet_precinct_view(old(precinct)),template,data@,expected_sop_sequence,layer,limits),
        result.is_err() ==> packet_precinct_view(final(precinct))==packet_precinct_view(old(precinct)),
))]
pub(crate) fn decode_jpip_precinct_packet(
    template: &TilePartPayload<'_>,
    data: &[u8],
    expected_sop_sequence: u16,
    layer: u16,
    precinct: &mut PacketPrecinctDecoder,
    limits: &ResourceLimits,
) -> Result<usize, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {let ghost initial=packet_precinct_view(precinct);}
    let states = precinct.states.clone();
    let contexts = precinct.contexts.clone();
    let subbands = precinct.subbands.clone();
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(states@.map_values(|state:CodeBlockPacketState|code_block_packet_state_view(&state))==initial.states);
        assert(contexts@==initial.contexts);
        assert(subbands@.map_values(|subband:PacketSubbandState|packet_subband_view(&subband))==initial.subbands);
    }
    let result = decode_jpip_precinct_packet_inner(
        template,
        data,
        expected_sop_sequence,
        layer,
        precinct,
        limits,
    );
    if result.is_err() {
        precinct.states = states;
        precinct.contexts = contexts;
        precinct.subbands = subbands;
    }
    result
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,packet_precinct_view(final(precinct)))==crate::specs::part1_jpip_precinct_packet_inner(
        packet_precinct_view(old(precinct)),template,data@,expected_sop_sequence,layer,limits),
        final(precinct).decoders@==old(precinct).decoders@,
        (final(precinct).component,final(precinct).resolution,final(precinct).precinct)
            ==(old(precinct).component,old(precinct).resolution,old(precinct).precinct),
))]
fn decode_jpip_precinct_packet_inner(
    template: &TilePartPayload<'_>,
    data: &[u8],
    expected_sop_sequence: u16,
    layer: u16,
    precinct: &mut PacketPrecinctDecoder,
    limits: &ResourceLimits,
) -> Result<usize, DecodeError> {
    set_progression_context_layer(&mut precinct.contexts, layer)?;
    let inline = TilePartPayload {
        tile_index: template.tile_index,
        tile_part_index: 0,
        tile_part_count: 1,
        coding_style: template.coding_style,
        quantization: template.quantization,
        component_coding_styles: template.component_coding_styles,
        component_quantizations: template.component_quantizations.clone(),
        roi_shifts: template.roi_shifts,
        progression_changes: template.progression_changes.clone(),
        multiple_component_transform: template.multiple_component_transform.clone(),
        part2_extensions: template.part2_extensions.clone(),
        packet_lengths: crate::codestream::packet_lengths_none(),
        packed_packet_headers: crate::codestream::packed_packet_headers_none(),
        has_functional_header_marker: template.has_functional_header_marker,
        has_roi_marker: template.has_roi_marker,
        data,
    };
    let (decoded, consumed, packed) = decode_precinct_packet(
        &inline,
        0,
        &[],
        0,
        None,
        expected_sop_sequence,
        precinct,
        false,
        limits,
    )?;
    if packed != 0 {
        return Err(packet_reader_error(0, MalformedKind::InvalidPacketLength));
    }
    let logical = match usize::try_from(decoded.bytes_consumed) {
        Ok(logical) => logical,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    if consumed != logical {
        return Err(packet_reader_error(0, MalformedKind::InvalidPacketLength));
    }
    Ok(consumed)
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, Hash, PartialEq))]
pub struct PacketCoordinate {
    pub layer: u16,
    pub resolution: u8,
    pub component: u16,
    pub precinct: u32,
}

pub struct PacketIterator<'a> {
    grid: &'a PacketGrid,
    order: ProgressionOrder,
    candidate_index: u64,
    emitted: u64,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_iterator_view(value: &PacketIterator<'_>) -> crate::specs::Part1PacketIterator {
        crate::specs::Part1PacketIterator {
            grid:packet_grid_view(value.grid), order:value.order,
            candidate_index:value.candidate_index, emitted:value.emitted,
        }
    }

    pub open spec fn packet_unravel_outcome(value: Result<[u64;4], DecodeError>)
        -> Result<Seq<u64>, DecodeError> {
        match value { Ok(values) => Ok(values@), Err(error) => Err(error) }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_iterator_view(&result) == crate::specs::part1_packet_iterator_initial(packet_grid_view(grid), order),
))]
pub(crate) const fn packet_iterator_new(
    grid: &PacketGrid,
    order: ProgressionOrder,
) -> PacketIterator<'_> {
    PacketIterator {
        grid,
        order,
        candidate_index: 0,
        emitted: 0,
    }
}

impl<'a> PacketIterator<'a> {
    pub const fn new(grid: &'a PacketGrid, order: ProgressionOrder) -> Self {
        packet_iterator_new(grid, order)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == packet_iterator_view(self).emitted,))]
    pub const fn emitted(&self) -> u64 {
        self.emitted
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, packet_iterator_view(final(self))) == crate::specs::part1_packet_iterator_next(packet_iterator_view(old(self))),
    ))]
    pub fn next_packet(&mut self) -> Result<Option<PacketCoordinate>, DecodeError> {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_iterator_next); }
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant
                    packet_iterator_view(self).grid == packet_iterator_view(old(self)).grid,
                    self.order == old(self).order,
                    crate::specs::part1_packet_iterator_next(packet_iterator_view(old(self)))
                        == crate::specs::part1_packet_iterator_next(packet_iterator_view(self)),
                decreases self.grid.candidate_count as int - self.candidate_index as int,
            )
        )]
        while self.candidate_index < self.grid.candidate_count {
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_packet_iterator_next); }
            let candidate = self.candidate_index;
            self.candidate_index = match self.candidate_index.checked_add(1) {
                Some(index) => index,
                None => return Err(packet_arithmetic_overflow()),
            };
            let coordinate = self.decode_candidate(candidate)?;
            if coordinate.precinct
                < self
                    .grid
                    .precinct_count(coordinate.component, coordinate.resolution)?
            {
                self.emitted = match self.emitted.checked_add(1) {
                    Some(emitted) => emitted,
                    None => return Err(packet_arithmetic_overflow()),
                };
                if self.emitted > self.grid.packet_count {
                    return Err(packet_arithmetic_overflow());
                }
                return Ok(Some(coordinate));
            }
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_iterator_next); }
        Ok(None)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_packet_candidate(packet_grid_view(self.grid), self.order, candidate),
    ))]
    fn decode_candidate(&self, candidate: u64) -> Result<PacketCoordinate, DecodeError> {
        let layers = u64::from(self.grid.layers);
        let resolutions = u64::from(self.grid.resolutions);
        let components = u64::from(self.grid.components);
        let precincts = u64::from(self.grid.maximum_precincts_per_resolution);
        let (layer, resolution, component, precinct) = match self.order {
            ProgressionOrder::Lrcp => {
                let values = unravel(candidate, [layers, resolutions, components, precincts])?;
                (values[0], values[1], values[2], values[3])
            }
            ProgressionOrder::Rlcp => {
                let values = unravel(candidate, [resolutions, layers, components, precincts])?;
                (values[1], values[0], values[2], values[3])
            }
            ProgressionOrder::Rpcl => {
                let values = unravel(candidate, [resolutions, precincts, components, layers])?;
                (values[3], values[0], values[2], values[1])
            }
            ProgressionOrder::Pcrl => {
                let values = unravel(candidate, [precincts, components, resolutions, layers])?;
                (values[3], values[2], values[1], values[0])
            }
            ProgressionOrder::Cprl => {
                let values = unravel(candidate, [components, precincts, resolutions, layers])?;
                (values[3], values[2], values[0], values[1])
            }
        };
        Ok(PacketCoordinate {
            layer: match u16::try_from(layer) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            resolution: match u8::try_from(resolution) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            component: match u16::try_from(component) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            precinct: match u32::try_from(precinct) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
        })
    }
}

#[cfg(not(verus_keep_ghost))]
impl Iterator for PacketIterator<'_> {
    type Item = Result<PacketCoordinate, DecodeError>;

    fn next(&mut self) -> Option<Self::Item> {
        self.next_packet().transpose()
    }
}

pub struct ProgressionPacketIterator<'a> {
    grid: &'a PacketGrid,
    changes: &'a ProgressionChanges,
    default: Option<PacketIterator<'a>>,
    window_index: usize,
    window_candidate: u64,
    window_candidates: u64,
    emitted: u64,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn progression_packet_iterator_view(value: &ProgressionPacketIterator<'_>)
        -> crate::specs::Part1ProgressionPacketIterator {
        crate::specs::Part1ProgressionPacketIterator {
            grid:packet_grid_view(value.grid), changes:crate::codestream::progression_changes_view(value.changes),
            default:match value.default { Some(default) => Some(packet_iterator_view(&default)), None => None },
            window_index:value.window_index, window_candidate:value.window_candidate,
            window_candidates:value.window_candidates, emitted:value.emitted,
        }
    }

    pub open spec fn progression_packet_iterator_outcome(value: Result<ProgressionPacketIterator<'_>,DecodeError>)
        -> Result<crate::specs::Part1ProgressionPacketIterator,DecodeError> {
        match value { Ok(iterator) => Ok(progression_packet_iterator_view(&iterator)), Err(error) => Err(error) }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures progression_packet_iterator_outcome(result) == crate::specs::part1_progression_iterator_initial(
        packet_grid_view(grid), default_order, crate::codestream::progression_changes_view(changes),
        crate::limits::resource_work_limit(limits)),
))]
pub(crate) fn progression_packet_iterator_new<'a>(
    grid: &'a PacketGrid,
    default_order: ProgressionOrder,
    changes: &'a ProgressionChanges,
    limits: &ResourceLimits,
) -> Result<ProgressionPacketIterator<'a>, DecodeError> {
    let default = if changes.is_empty() {
        Some(packet_iterator_new(grid, default_order))
    } else {
        None
    };
    let mut candidate_work = 0_u64;
    let change_count = changes.records().len();
    let mut index = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_progression_admission); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant index <= change_count,
            change_count == crate::codestream::progression_changes_view(changes).len(),
            crate::specs::part1_progression_admission(packet_grid_view(grid),
                crate::codestream::progression_changes_view(changes),0,0,crate::limits::resource_work_limit(limits))
            == crate::specs::part1_progression_admission(packet_grid_view(grid),
                crate::codestream::progression_changes_view(changes),index,candidate_work,crate::limits::resource_work_limit(limits)),
        decreases change_count-index,
    ))]
    while index < change_count {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_progression_admission); }
        let record = match changes.records().get(index) {
            Some(record) => *record,
            None => {
                return Err(packet_reader_error(
                    0,
                    MalformedKind::InvalidProgressionOrderChange,
                ));
            }
        };
        candidate_work = match candidate_work.checked_add(window_candidate_count(grid, record)?) {
            Some(work) => work,
            None => return Err(packet_arithmetic_overflow()),
        };
        if candidate_work > limits.maximum_work_units() {
            return Err(packet_reader_limit(
                Resource::WorkUnits,
                limits.maximum_work_units(),
                candidate_work,
            ));
        }
        index = match index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_progression_admission); }
    let window_candidates = match changes.records().first() {
        Some(record) => window_candidate_count(grid, *record)?,
        None => 0,
    };
    Ok(ProgressionPacketIterator {
        grid,
        changes,
        default,
        window_index: 0,
        window_candidate: 0,
        window_candidates,
        emitted: 0,
    })
}

impl<'a> ProgressionPacketIterator<'a> {
    pub fn new(
        grid: &'a PacketGrid,
        default_order: ProgressionOrder,
        changes: &'a ProgressionChanges,
        limits: &ResourceLimits,
    ) -> Result<Self, DecodeError> {
        progression_packet_iterator_new(grid, default_order, changes, limits)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == progression_packet_iterator_view(self).emitted,
    ))]
    pub const fn emitted(&self) -> u64 {
        self.emitted
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, progression_packet_iterator_view(final(self))) ==
            crate::specs::part1_progression_iterator_next(progression_packet_iterator_view(old(self))),
    ))]
    pub fn next_packet(&mut self) -> Result<Option<PacketCoordinate>, DecodeError> {
        let default_step = {
            if let Some(default) = self.default.as_mut() {
                let result = default.next_packet();
                Some((result, default.emitted()))
            } else {
                None
            }
        };
        if let Some((result, emitted)) = default_step {
            let coordinate = result?;
            self.emitted = emitted;
            return Ok(coordinate);
        }
        let change_count = self.changes.records().len();
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_progression_windows_next); }
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant change_count == progression_packet_iterator_view(self).changes.len(),
                    self.default.is_none(),
                    crate::specs::part1_progression_iterator_next(progression_packet_iterator_view(old(self)))
                        == crate::specs::part1_progression_windows_next(progression_packet_iterator_view(self)),
                decreases change_count - self.window_index,
            )
        )]
        while self.window_index < change_count {
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_progression_windows_next); }
            let record = match self.changes.records().get(self.window_index) {
                Some(record) => *record,
                None => {
                    return Err(packet_reader_error(
                        0,
                        MalformedKind::InvalidProgressionOrderChange,
                    ));
                }
            };
            #[cfg(verus_keep_ghost)]
            proof_decl! { let ghost initial_window_index = self.window_index; }
            #[cfg_attr(
                verus_keep_ghost,
                verus_spec(
                    invariant change_count == progression_packet_iterator_view(self).changes.len(),
                        self.default.is_none(),
                        self.window_index < change_count,
                        self.window_index == initial_window_index,
                        record == progression_packet_iterator_view(self).changes[self.window_index as int],
                        crate::specs::part1_progression_iterator_next(progression_packet_iterator_view(old(self)))
                            == crate::specs::part1_progression_windows_next(progression_packet_iterator_view(self)),
                    decreases self.window_candidates - self.window_candidate,
                )
            )]
            while self.window_candidate < self.window_candidates {
                #[cfg(verus_keep_ghost)]
                proof! { reveal(crate::specs::part1_progression_windows_next); }
                if let Some(coordinate) = self.candidate_step(record)? {
                    return Ok(Some(coordinate));
                }
            }
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_progression_windows_next); }
            self.next_window()?;
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_progression_windows_next); }
        if self.emitted != self.grid.packet_count {
            return Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange,
            ));
        }
        Ok(None)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, progression_packet_iterator_view(final(self))) ==
            crate::specs::part1_progression_candidate_step(progression_packet_iterator_view(old(self)), record),
    ))]
    fn candidate_step(
        &mut self,
        record: ProgressionChange,
    ) -> Result<Option<PacketCoordinate>, DecodeError> {
        let candidate = self.window_candidate;
        self.window_candidate = match self.window_candidate.checked_add(1) {
            Some(candidate) => candidate,
            None => return Err(packet_arithmetic_overflow()),
        };
        let coordinate = decode_window_candidate(self.grid, record, candidate)?;
        if coordinate.precinct
            >= self
                .grid
                .precinct_count(coordinate.component, coordinate.resolution)?
        {
            return Ok(None);
        }
        let already_emitted =
            progression_prior_contains(self.changes, self.window_index, coordinate)?;
        if !crate::refinement::progression_emit_allowed(already_emitted) {
            return Ok(None);
        }
        self.emitted = match self.emitted.checked_add(1) {
            Some(emitted) => emitted,
            None => return Err(packet_arithmetic_overflow()),
        };
        if self.emitted > self.grid.packet_count {
            return Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange,
            ));
        }
        Ok(Some(coordinate))
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, progression_packet_iterator_view(final(self))) ==
            crate::specs::part1_progression_next_window(progression_packet_iterator_view(old(self))),
    ))]
    fn next_window(&mut self) -> Result<(), DecodeError> {
        self.window_index = match self.window_index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        self.window_candidate = 0;
        self.window_candidates = match self.changes.records().get(self.window_index) {
            Some(next) => window_candidate_count(self.grid, *next)?,
            None => 0,
        };
        Ok(())
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_progression_prior_contains(
        crate::codestream::progression_changes_view(changes),end,0,coordinate),
))]
fn progression_prior_contains(
    changes: &ProgressionChanges,
    end: usize,
    coordinate: PacketCoordinate,
) -> Result<bool, DecodeError> {
    let mut prior = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_progression_prior_contains); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
            invariant prior <= end,
                crate::specs::part1_progression_prior_contains(crate::codestream::progression_changes_view(changes),
                    end,0,coordinate)
                == crate::specs::part1_progression_prior_contains(crate::codestream::progression_changes_view(changes),
                    end,prior,coordinate),
            decreases end-prior,
        ))]
    while prior < end {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_progression_prior_contains); }
        let prior_record = match changes.records().get(prior) {
            Some(record) => *record,
            None => {
                return Err(packet_reader_error(
                    0,
                    MalformedKind::InvalidProgressionOrderChange,
                ));
            }
        };
        if prior_record.contains(
            coordinate.layer,
            coordinate.resolution,
            coordinate.component,
        ) {
            return Ok(true);
        }
        prior = match prior.checked_add(1) {
            Some(prior) => prior,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_progression_prior_contains); }
    Ok(false)
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_window_count(packet_grid_view(grid), record),
))]
fn window_candidate_count(
    grid: &PacketGrid,
    record: ProgressionChange,
) -> Result<u64, DecodeError> {
    let resolutions = match record.resolution_end.checked_sub(record.resolution_start) {
        Some(count) => count,
        None => {
            return Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange,
            ));
        }
    };
    let first = match u64::from(record.layer_end).checked_mul(u64::from(resolutions)) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    let second = match first.checked_mul(u64::from(
        record.component_end.saturating_sub(record.component_start),
    )) {
        Some(count) => count,
        None => return Err(packet_arithmetic_overflow()),
    };
    match second.checked_mul(u64::from(grid.maximum_precincts_per_resolution)) {
        Some(count) => Ok(count),
        None => Err(packet_arithmetic_overflow()),
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_window_candidate(packet_grid_view(grid), record, candidate),
))]
fn decode_window_candidate(
    grid: &PacketGrid,
    record: ProgressionChange,
    candidate: u64,
) -> Result<PacketCoordinate, DecodeError> {
    let layers = u64::from(record.layer_end);
    let resolutions = u64::from(
        match record.resolution_end.checked_sub(record.resolution_start) {
            Some(count) => count,
            None => {
                return Err(packet_reader_error(
                    0,
                    MalformedKind::InvalidProgressionOrderChange,
                ));
            }
        },
    );
    let components = u64::from(
        match record.component_end.checked_sub(record.component_start) {
            Some(count) => count,
            None => {
                return Err(packet_reader_error(
                    0,
                    MalformedKind::InvalidProgressionOrderChange,
                ));
            }
        },
    );
    let precincts = u64::from(grid.maximum_precincts_per_resolution);
    let (layer, resolution, component, precinct) = match record.progression_order {
        ProgressionOrder::Lrcp => {
            let values = unravel(candidate, [layers, resolutions, components, precincts])?;
            (values[0], values[1], values[2], values[3])
        }
        ProgressionOrder::Rlcp => {
            let values = unravel(candidate, [resolutions, layers, components, precincts])?;
            (values[1], values[0], values[2], values[3])
        }
        ProgressionOrder::Rpcl => {
            let values = unravel(candidate, [resolutions, precincts, components, layers])?;
            (values[3], values[0], values[2], values[1])
        }
        ProgressionOrder::Pcrl => {
            let values = unravel(candidate, [precincts, components, resolutions, layers])?;
            (values[3], values[2], values[1], values[0])
        }
        ProgressionOrder::Cprl => {
            let values = unravel(candidate, [components, precincts, resolutions, layers])?;
            (values[3], values[2], values[0], values[1])
        }
    };
    Ok(PacketCoordinate {
        layer: match u16::try_from(layer) {
            Ok(value) => value,
            Err(_) => return Err(packet_arithmetic_overflow()),
        },
        resolution: match u8::try_from(resolution) {
            Err(_) => return Err(packet_arithmetic_overflow()),
            Ok(value) => match value.checked_add(record.resolution_start) {
                Some(value) => value,
                None => return Err(packet_arithmetic_overflow()),
            },
        },
        component: match u16::try_from(component) {
            Err(_) => return Err(packet_arithmetic_overflow()),
            Ok(value) => match value.checked_add(record.component_start) {
                Some(value) => value,
                None => return Err(packet_arithmetic_overflow()),
            },
        },
        precinct: match u32::try_from(precinct) {
            Ok(value) => value,
            Err(_) => return Err(packet_arithmetic_overflow()),
        },
    })
}
#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_unravel_outcome(result) == crate::specs::part1_packet_unravel(index, dimensions@),
))]
fn unravel(mut index: u64, dimensions: [u64; 4]) -> Result<[u64; 4], DecodeError> {
    if dimensions[0] == 0 || dimensions[1] == 0 || dimensions[2] == 0 || dimensions[3] == 0 {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    let third = crate::refinement::progression_digit(index, dimensions[3]);
    index = crate::refinement::progression_advance(index, dimensions[3]);
    let second = crate::refinement::progression_digit(index, dimensions[2]);
    index = crate::refinement::progression_advance(index, dimensions[2]);
    let first = crate::refinement::progression_digit(index, dimensions[1]);
    index = crate::refinement::progression_advance(index, dimensions[1]);
    if index >= dimensions[0] {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    Ok([index, first, second, third])
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct CodeBlockPacketState {
    included: bool,
    zero_bitplanes: Option<u16>,
    lblock: u8,
    total_passes: u32,
    high_throughput: Option<bool>,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn code_block_packet_state_view(state: &CodeBlockPacketState) -> crate::specs::Part1CodeBlockPacketState {
        crate::specs::Part1CodeBlockPacketState {
            included: state.included, zero_bitplanes: state.zero_bitplanes, lblock: state.lblock,
            total_passes: state.total_passes, high_throughput: state.high_throughput,
        }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures code_block_packet_state_view(&result) == crate::specs::part1_code_block_packet_initial(),
))]
pub(crate) const fn code_block_packet_state_new() -> CodeBlockPacketState {
    CodeBlockPacketState {
        included: false,
        zero_bitplanes: None,
        lblock: 3,
        total_passes: 0,
        high_throughput: None,
    }
}

impl CodeBlockPacketState {
    pub const fn new() -> Self {
        code_block_packet_state_new()
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == code_block_packet_state_view(self).included,))]
    pub const fn included(&self) -> bool {
        self.included
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == code_block_packet_state_view(self).zero_bitplanes,))]
    pub const fn zero_bitplanes(&self) -> Option<u16> {
        self.zero_bitplanes
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == code_block_packet_state_view(self).lblock,))]
    pub const fn lblock(&self) -> u8 {
        self.lblock
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == code_block_packet_state_view(self).total_passes,))]
    pub const fn total_passes(&self) -> u32 {
        self.total_passes
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == code_block_packet_state_view(self).high_throughput,))]
    pub const fn high_throughput(&self) -> Option<bool> {
        self.high_throughput
    }
}

impl Default for CodeBlockPacketState {
    fn default() -> Self {
        code_block_packet_state_new()
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct CodeBlockContribution {
    pub first_inclusion: bool,
    pub zero_bitplanes: u16,
    pub new_passes: u8,
    pub data_length: u32,
    pub high_throughput: bool,
    segment_count: u8,
    segment_passes: [u8; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
    segment_lengths: [u32; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn code_block_contribution_view(contribution: &CodeBlockContribution) -> crate::specs::Part1CodeBlockContribution {
        crate::specs::Part1CodeBlockContribution {
            first_inclusion: contribution.first_inclusion,
            zero_bitplanes: contribution.zero_bitplanes,
            new_passes: contribution.new_passes,
            data_length: contribution.data_length,
            high_throughput: contribution.high_throughput,
            segment_count: contribution.segment_count,
            segment_passes: contribution.segment_passes@,
            segment_lengths: contribution.segment_lengths@,
        }
    }

    pub open spec fn code_block_contribution_option_view(contribution: Option<CodeBlockContribution>)
        -> Option<crate::specs::Part1CodeBlockContribution>
    {
        match contribution { None => None, Some(value) => Some(code_block_contribution_view(&value)) }
    }

    pub open spec fn code_block_header_outcome(result: Result<Option<CodeBlockContribution>, DecodeError>)
        -> Result<Option<crate::specs::Part1CodeBlockContribution>, DecodeError>
    {
        match result {
            Err(error) => Err(error),
            Ok(contribution) => Ok(code_block_contribution_option_view(contribution)),
        }
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct CodeBlockSegmentContribution {
    pub passes: u8,
    pub data_length: u32,
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct CodeBlockBodyDecode {
    pub segments: u8,
    pub passes: u32,
    pub bytes: u32,
}

#[derive(Clone, Copy)]
pub(crate) struct HtBodyProgress {
    pub segment_index: u8,
    pub offset: usize,
    pub decoded_passes: u32,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn ht_body_progress_view(progress: &HtBodyProgress) -> crate::specs::HtPacketBodyProgress {
        crate::specs::HtPacketBodyProgress {
            segment_index: progress.segment_index,
            offset: progress.offset,
            decoded_passes: progress.decoded_passes,
        }
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct PacketBodyDecode {
    pub present: bool,
    pub code_blocks: u32,
    pub contributions: u32,
    pub segments: u32,
    pub passes: u32,
    pub header_bytes: u32,
    pub body_bytes: u32,
    pub bytes_consumed: u32,
}

pub struct PacketCodeBlockExecution<'a> {
    pub states: &'a mut [CodeBlockPacketState],
    pub inclusion_tree: &'a mut TagTree,
    pub zero_bitplane_tree: &'a mut TagTree,
    pub contexts: &'a [CodeBlockPacketContext],
    pub decoders: &'a mut [Tier1CodeBlockDecoder],
}

pub struct PacketPrecinctDecoder {
    component: u16,
    resolution: u8,
    precinct: u32,
    states: Vec<CodeBlockPacketState>,
    contexts: Vec<CodeBlockPacketContext>,
    decoders: Vec<Tier1CodeBlockDecoder>,
    subbands: Vec<PacketSubbandState>,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_precinct_decoders(value: &PacketPrecinctDecoder) -> Seq<Tier1CodeBlockDecoder> {
        value.decoders@
    }

    pub proof fn packet_precinct_decoder_states(value: &PacketPrecinctDecoder)
        ensures packet_precinct_view(value).decoders
            == packet_precinct_decoders(value).map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
    {
        reveal(packet_precinct_view);
        reveal(packet_precinct_decoders);
    }

    pub open spec fn packet_decoder_outcome(result: Result<&Tier1CodeBlockDecoder, DecodeError>)
        -> Result<Tier1CodeBlockDecoder, DecodeError>
    {
        match result { Ok(value) => Ok(*value), Err(error) => Err(error) }
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct PacketPrecinctGeometry {
    pub component: u16,
    pub resolution: u8,
    pub precinct: u32,
    pub code_blocks_across: u32,
    pub code_blocks_down: u32,
    pub maximum_zero_bitplanes: u16,
}

pub struct PacketSubbandExecution {
    pub orientation: SubbandOrientation,
    pub code_blocks_across: u32,
    pub code_blocks_down: u32,
    pub maximum_zero_bitplanes: u16,
    pub decoders: Vec<Tier1CodeBlockDecoder>,
}

struct PacketSubbandState {
    orientation: SubbandOrientation,
    first_decoder: usize,
    decoder_count: usize,
    code_blocks_across: u32,
    code_blocks_down: u32,
    inclusion_tree: TagTree,
    zero_bitplane_tree: TagTree,
}

impl Clone for PacketSubbandState {
    #[cfg_attr(verus_keep_ghost,verus_spec(result =>
        ensures packet_subband_view(&result)==packet_subband_view(self),
    ))]
    fn clone(&self) -> Self {
        Self {
            orientation: self.orientation,
            first_decoder: self.first_decoder,
            decoder_count: self.decoder_count,
            code_blocks_across: self.code_blocks_across,
            code_blocks_down: self.code_blocks_down,
            inclusion_tree: self.inclusion_tree.clone(),
            zero_bitplane_tree: self.zero_bitplane_tree.clone(),
        }
    }
}

#[derive(Clone, Copy)]
struct PrecinctHeaderParameters {
    layer: u16,
    style: Tier1CodingStyle,
}

#[derive(Clone, Copy)]
struct PrecinctHeaderProgress {
    subband_index: usize,
    local_index: usize,
    contribution_count: u32,
}

#[derive(Clone, Copy)]
struct PrecinctPayloadParameters {
    error_offset: usize,
    packed_offset: usize,
    expected_packet_length: Option<u32>,
    expected_sop_sequence: u16,
    style: Tier1CodingStyle,
    sop: bool,
    eph: bool,
    packed: bool,
    decode_tier1: bool,
}

struct PrecinctPayloadReader<'a> {
    reader: PacketBitReader<'a>,
    packet_data: &'a [u8],
    present: bool,
    sop_bytes: usize,
}

struct PrecinctPayloadHeader<'a> {
    prefix: PrecinctPayloadReader<'a>,
    contributions: Vec<Option<CodeBlockContribution>>,
    contribution_count: u32,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn precinct_payload_header_view(value: PrecinctPayloadHeader<'_>)
        -> (crate::specs::Part1PrecinctPayloadReader, Seq<Option<crate::specs::Part1CodeBlockContribution>>, u32) {
        (precinct_payload_reader_view(value.prefix),
            value.contributions@.map_values(|value: Option<CodeBlockContribution>| code_block_contribution_option_view(value)),
            value.contribution_count)
    }

    pub closed spec fn precinct_payload_reader_view(value: PrecinctPayloadReader<'_>) -> crate::specs::Part1PrecinctPayloadReader {
        crate::specs::Part1PrecinctPayloadReader {
            reader: packet_bit_reader_view(&value.reader), packet_data: value.packet_data@,
            present: value.present, sop_bytes: value.sop_bytes,
        }
    }

    pub open spec fn precinct_payload_reader_outcome(value: Result<PrecinctPayloadReader<'_>, DecodeError>)
        -> Result<crate::specs::Part1PrecinctPayloadReader, DecodeError> {
        match value { Ok(reader) => Ok(precinct_payload_reader_view(reader)), Err(error) => Err(error) }
    }

    pub closed spec fn packet_subband_view(value: &PacketSubbandState) -> crate::specs::Part1PacketSubbandState {
        crate::specs::Part1PacketSubbandState {
            orientation: value.orientation, first_decoder: value.first_decoder, decoder_count: value.decoder_count,
            code_blocks_across: value.code_blocks_across, code_blocks_down: value.code_blocks_down,
            inclusion_tree: tag_tree_view(&value.inclusion_tree), zero_bitplane_tree: tag_tree_view(&value.zero_bitplane_tree),
        }
    }

    pub closed spec fn packet_precinct_view(value: &PacketPrecinctDecoder) -> crate::specs::Part1PacketPrecinctState {
        crate::specs::Part1PacketPrecinctState {
            component: value.component, resolution: value.resolution, precinct: value.precinct,
            states: value.states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state)),
            contexts: value.contexts@,
            decoders: value.decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
            subbands: value.subbands@.map_values(|subband: PacketSubbandState| packet_subband_view(&subband)),
        }
    }

    pub closed spec fn packet_execution_view(value: &PacketSubbandExecution) -> crate::specs::Part2PacketSubbandExecution {
        crate::specs::Part2PacketSubbandExecution {
            orientation: value.orientation, across: value.code_blocks_across, down: value.code_blocks_down,
            maximum_zero: value.maximum_zero_bitplanes,
            decoders: value.decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
        }
    }

    pub proof fn packet_execution_known_fields(value: &PacketSubbandExecution)
        ensures packet_execution_view(value) == (crate::specs::Part2PacketSubbandExecution {
            orientation: value.orientation, across: value.code_blocks_across, down: value.code_blocks_down,
            maximum_zero: value.maximum_zero_bitplanes,
            decoders: value.decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
        }),
    {
        reveal(packet_execution_view);
    }

    pub open spec fn packet_executions_view(values: Seq<PacketSubbandExecution>) -> Seq<crate::specs::Part2PacketSubbandExecution> {
        Seq::new(values.len(), |index: int| packet_execution_view(&values[index]))
    }

    pub closed spec fn precinct_initialization_view(
        coordinate: (u16, u8, u32), states: Seq<CodeBlockPacketState>, contexts: Seq<CodeBlockPacketContext>,
        decoders: Seq<Tier1CodeBlockDecoder>, subbands: Seq<PacketSubbandState>,
    ) -> crate::specs::Part1PacketPrecinctState {
        crate::specs::Part1PacketPrecinctState {
            component: coordinate.0, resolution: coordinate.1, precinct: coordinate.2,
            states: states.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state)),
            contexts, decoders: decoders.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
            subbands: subbands.map_values(|subband: PacketSubbandState| packet_subband_view(&subband)),
        }
    }

    pub open spec fn packet_precinct_outcome(result: Result<PacketPrecinctDecoder, DecodeError>)
        -> Result<crate::specs::Part1PacketPrecinctState, DecodeError>
    {
        match result { Err(error) => Err(error), Ok(value) => Ok(packet_precinct_view(&value)) }
    }

    pub open spec fn precinct_contexts_outcome(
        result: Result<(Vec<CodeBlockPacketState>, Vec<CodeBlockPacketContext>), DecodeError>,
    ) -> Result<(Seq<crate::specs::Part1CodeBlockPacketState>, Seq<CodeBlockPacketContext>), DecodeError> {
        match result {
            Err(error) => Err(error),
            Ok(value) => Ok((value.0@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state)), value.1@)),
        }
    }

    pub open spec fn packet_states_view(values: Seq<CodeBlockPacketState>) -> Seq<crate::specs::Part1CodeBlockPacketState> {
        values.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state))
    }

    pub closed spec fn precinct_payload_parameters_view(value: PrecinctPayloadParameters)
        -> crate::specs::Part1PrecinctPayloadParameters {
        crate::specs::Part1PrecinctPayloadParameters {
            error_offset: value.error_offset, packed_offset: value.packed_offset,
            expected_packet_length: value.expected_packet_length, expected_sop_sequence: value.expected_sop_sequence,
            style: value.style, sop: value.sop, eph: value.eph, packed: value.packed, decode_tier1: value.decode_tier1,
        }
    }

    pub closed spec fn precinct_header_view(
        states: &[CodeBlockPacketState], subbands: &[PacketSubbandState],
        contributions: &[Option<CodeBlockContribution>], reader: &PacketBitReader<'_>,
        progress: &PrecinctHeaderProgress,
    ) -> crate::specs::Part1PrecinctHeaderState {
        crate::specs::Part1PrecinctHeaderState {
            states: states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state)),
            subbands: subbands@.map_values(|subband: PacketSubbandState| packet_subband_view(&subband)),
            contributions: packet_body_contributions_view(contributions),
            reader: packet_bit_reader_view(reader),
            subband_index: progress.subband_index, local_index: progress.local_index,
            contribution_count: progress.contribution_count,
        }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures precinct_contexts_outcome(result) == crate::specs::part2_precinct_contexts(
        packet_states_view(before_states@),
        before_contexts@, count, across, maximum_zero, tier1_style,
    ),
))]
pub(crate) fn prepare_precinct_contexts(
    before_states: Vec<CodeBlockPacketState>,
    before_contexts: Vec<CodeBlockPacketContext>,
    count: usize,
    across: u32,
    maximum_zero: u16,
    tier1_style: Tier1CodingStyle,
) -> Result<(Vec<CodeBlockPacketState>, Vec<CodeBlockPacketContext>), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial_states = before_states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state));
        let ghost initial_contexts = before_contexts@;
    }
    let mut states = before_states;
    let mut contexts = before_contexts;
    let mut local_index = 0_usize;
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant
            local_index <= count,
            local_index as nat <= u32::MAX as nat + 1,
            local_index == 0 || across != 0,
            states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state))
                == initial_states + Seq::new(local_index as nat, |index: int| crate::specs::part1_code_block_packet_initial()),
            contexts@ == initial_contexts + Seq::new(local_index as nat, |index: int| CodeBlockPacketContext {
                leaf_x: if across == 0 { 0u32 } else { (index % across as int) as u32 },
                leaf_y: if across == 0 { 0u32 } else { (index / across as int) as u32 },
                layer: 0, maximum_zero_bitplanes: maximum_zero, tier1_style,
            }),
        decreases count - local_index,
    ))]
    while local_index < count {
        let linear_index = match u32::try_from(local_index) {
            Ok(index) => index,
            Err(_) => return Err(packet_arithmetic_overflow()),
        };
        let state = code_block_packet_state_new();
        #[cfg(verus_keep_ghost)]
        proof_decl! { let ghost previous_states = states@; }
        states.push(state);
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state))
                =~= previous_states.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state))
                    .push(crate::specs::part1_code_block_packet_initial()));
            assert(initial_states + Seq::new(local_index as nat + 1, |index: int| crate::specs::part1_code_block_packet_initial())
                =~= (initial_states + Seq::new(local_index as nat, |index: int| crate::specs::part1_code_block_packet_initial()))
                    .push(crate::specs::part1_code_block_packet_initial()));
        }
        contexts.push(CodeBlockPacketContext {
            leaf_x: linear_index
                .checked_rem(across)
                .ok_or_else(packet_arithmetic_overflow)?,
            leaf_y: linear_index
                .checked_div(across)
                .ok_or_else(packet_arithmetic_overflow)?,
            layer: 0,
            maximum_zero_bitplanes: maximum_zero,
            tier1_style,
        });
        local_index = local_index
            .checked_add(1)
            .ok_or_else(packet_arithmetic_overflow)?;
    }
    Ok((states, contexts))
}

impl PacketPrecinctDecoder {
    pub fn new(
        geometry: PacketPrecinctGeometry,
        tier1_style: Tier1CodingStyle,
        decoders: Vec<Tier1CodeBlockDecoder>,
        limits: &ResourceLimits,
    ) -> Result<Self, DecodeError> {
        Self::new_subbands(
            geometry.component,
            geometry.resolution,
            geometry.precinct,
            tier1_style,
            vec![PacketSubbandExecution {
                orientation: SubbandOrientation::Ll,
                code_blocks_across: geometry.code_blocks_across,
                code_blocks_down: geometry.code_blocks_down,
                maximum_zero_bitplanes: geometry.maximum_zero_bitplanes,
                decoders,
            }],
            limits,
        )
    }

    /// An empty execution list represents a precinct with no nonempty subbands.
    pub fn new_subbands(
        component: u16,
        resolution: u8,
        precinct: u32,
        tier1_style: Tier1CodingStyle,
        executions: Vec<PacketSubbandExecution>,
        limits: &ResourceLimits,
    ) -> Result<Self, DecodeError> {
        packet_precinct_from_subbands(
            component,
            resolution,
            precinct,
            tier1_style,
            executions,
            limits,
        )
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures packet_precinct_outcome(result) == crate::specs::part2_precinct_from_executions(
        component, resolution, precinct, tier1_style, packet_executions_view(before@), limits,
    ),
))]
pub(crate) fn packet_precinct_from_subbands(
    component: u16,
    resolution: u8,
    precinct: u32,
    tier1_style: Tier1CodingStyle,
    before: Vec<PacketSubbandExecution>,
    limits: &ResourceLimits,
) -> Result<PacketPrecinctDecoder, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! { let ghost original = packet_executions_view(before@); }
    let mut executions = before;
    if executions.len() > 3 {
        return Err(invalid_packet_header());
    }
    let mut states = Vec::new();
    let mut contexts = Vec::new();
    let mut decoders = Vec::new();
    let mut subbands = Vec::with_capacity(executions.len());
    let mut execution_index = 0_usize;
    let mut total_code_blocks = 0_u64;
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(original.len() == executions@.len());
        assert(original.len() <= 3);
        reveal(precinct_initialization_view);
        assert(states@.map_values(|state: CodeBlockPacketState| code_block_packet_state_view(&state)) =~= Seq::empty());
        assert(decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)) =~= Seq::empty());
        assert(subbands@.map_values(|subband: PacketSubbandState| packet_subband_view(&subband)) =~= Seq::empty());
        assert(precinct_initialization_view((component, resolution, precinct), states@, contexts@, decoders@, subbands@)
            == crate::specs::Part1PacketPrecinctState {
                component, resolution, precinct, states: Seq::empty(), contexts: Seq::empty(),
                decoders: Seq::empty(), subbands: Seq::empty(),
            });
        reveal(crate::specs::part2_precinct_initialization_run);
    }
    #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant
                    execution_index <= executions.len(),
                    executions@.len() == original.len(),
                    original == packet_executions_view(before@),
                    original.len() <= 3,
                    forall |index: int| execution_index <= index < original.len()
                        ==> #[trigger] packet_execution_view(&executions@[index]) == original[index],
                    crate::specs::part2_precinct_from_executions(component, resolution, precinct, tier1_style, original, limits)
                        == crate::specs::part2_precinct_initialization_run(
                            original, tier1_style, limits, execution_index as nat,
                            precinct_initialization_view((component, resolution, precinct), states@, contexts@, decoders@, subbands@),
                            total_code_blocks,
                        ),
                decreases executions.len() - execution_index,
            )
        )]
    while execution_index < executions.len() {
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost previous_state = precinct_initialization_view(
                (component, resolution, precinct), states@, contexts@, decoders@, subbands@);
            let ghost previous_total = total_code_blocks;
            let ghost row = original[execution_index as int];
        }
        #[cfg(verus_keep_ghost)]
        proof! {
            reveal(crate::specs::part2_precinct_initialization_run);
            reveal(packet_execution_view);
            reveal(precinct_initialization_view);
            assert(packet_execution_view(&executions@[execution_index as int]) == original[execution_index as int]);
        }
        let execution = executions
            .get_mut(execution_index)
            .ok_or_else(invalid_packet_header)?;
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(packet_execution_view(execution) == original[execution_index as int]);
            assert(original[execution_index as int].across == execution.code_blocks_across);
            assert(original[execution_index as int].down == execution.code_blocks_down);
            assert(original[execution_index as int].maximum_zero == execution.maximum_zero_bitplanes);
        }
        if execution.code_blocks_across == 0
            || execution.code_blocks_down == 0
            || execution.maximum_zero_bitplanes == 0
            || execution.maximum_zero_bitplanes > crate::tier1::MAX_TIER1_BITPLANES
        {
            return Err(invalid_packet_header());
        }
        let count = u64::from(execution.code_blocks_across)
            .checked_mul(u64::from(execution.code_blocks_down))
            .ok_or_else(packet_arithmetic_overflow)?;
        total_code_blocks = total_code_blocks
            .checked_add(count)
            .ok_or_else(packet_arithmetic_overflow)?;
        if total_code_blocks > limits.maximum_code_blocks() {
            return Err(DecodeError::LimitExceeded {
                resource: Resource::CodeBlocks,
                limit: limits.maximum_code_blocks(),
                actual: total_code_blocks,
            });
        }
        if total_code_blocks > limits.maximum_work_units() {
            return Err(DecodeError::LimitExceeded {
                resource: Resource::WorkUnits,
                limit: limits.maximum_work_units(),
                actual: total_code_blocks,
            });
        }
        let count = match usize::try_from(count) {
            Ok(count) => count,
            Err(_) => return Err(packet_arithmetic_overflow()),
        };
        if execution.decoders.len() != count {
            return Err(invalid_packet_header());
        }
        let first_decoder = decoders.len();
        let prepared = prepare_precinct_contexts(
            states,
            contexts,
            count,
            execution.code_blocks_across,
            execution.maximum_zero_bitplanes,
            tier1_style,
        )?;
        states = prepared.0;
        contexts = prepared.1;
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost previous_decoders = decoders@;
            let ghost row_decoders = execution.decoders@;
        }
        decoders.append(&mut execution.decoders);
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder))
                =~= previous_decoders.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder))
                    + row_decoders.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)));
        }
        let inclusion_tree = tag_tree_new(
            execution.code_blocks_across,
            execution.code_blocks_down,
            limits,
        )?;
        let zero_bitplane_tree = tag_tree_new(
            execution.code_blocks_across,
            execution.code_blocks_down,
            limits,
        )?;
        let subband = PacketSubbandState {
            orientation: execution.orientation,
            first_decoder,
            decoder_count: count,
            code_blocks_across: execution.code_blocks_across,
            code_blocks_down: execution.code_blocks_down,
            inclusion_tree,
            zero_bitplane_tree,
        };
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost previous_subbands = subbands@;
            let ghost added_subband = packet_subband_view(&subband);
        }
        subbands.push(subband);
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(subbands@.map_values(|value: PacketSubbandState| packet_subband_view(&value))
                =~= previous_subbands.map_values(|value: PacketSubbandState| packet_subband_view(&value)).push(added_subband));
            assert(crate::specs::part2_precinct_execution(previous_state, previous_total, row, tier1_style, limits)
                == Ok((precinct_initialization_view((component, resolution, precinct),
                    states@, contexts@, decoders@, subbands@), total_code_blocks)));
            crate::proofs::production_impl::production_precinct_initialization_step(
                original, tier1_style, limits, execution_index as nat, previous_state, previous_total,
                precinct_initialization_view((component, resolution, precinct),
                    states@, contexts@, decoders@, subbands@), total_code_blocks,
            );
        }
        execution_index = execution_index
            .checked_add(1)
            .ok_or_else(packet_arithmetic_overflow)?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part2_precinct_initialization_run); }
    Ok(PacketPrecinctDecoder {
        component,
        resolution,
        precinct,
        states,
        contexts,
        decoders,
        subbands,
    })
}

impl PacketPrecinctDecoder {
    pub const fn coordinate(&self) -> (u16, u8, u32) {
        (self.component, self.resolution, self.precinct)
    }

    pub fn states(&self) -> &[CodeBlockPacketState] {
        &self.states
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result@ == packet_precinct_decoders(self),
    ))]
    pub fn decoders(&self) -> &[Tier1CodeBlockDecoder] {
        &self.decoders
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result as nat == crate::specs::part1_packet_decoder_count(packet_precinct_decoders(self)),
    ))]
    pub const fn decoder_count(&self) -> usize {
        self.decoders.len()
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures packet_decoder_outcome(result) == crate::specs::part1_packet_precinct_decoder(packet_precinct_decoders(self), index),
    ))]
    pub fn decoder(&self, index: usize) -> Result<&Tier1CodeBlockDecoder, DecodeError> {
        self.decoders.get(index).ok_or_else(invalid_packet_header)
    }

    pub const fn subband_count(&self) -> usize {
        self.subbands.len()
    }

    pub fn subband_orientation(&self, index: usize) -> Result<SubbandOrientation, DecodeError> {
        self.subbands
            .get(index)
            .map(|subband| subband.orientation)
            .ok_or_else(invalid_packet_header)
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct TilePacketDecode {
    pub tile_index: u16,
    pub tile_parts: u32,
    pub packets: u64,
    pub present_packets: u64,
    pub contributions: u64,
    pub segments: u64,
    pub passes: u64,
    pub packet_header_bytes: u64,
    pub packet_body_bytes: u64,
    pub payload_bytes: u64,
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,packet_precinct_vector_view(final(precincts)))==crate::specs::part1_progression_tile_decode(
        tile_parts@,packet_grid_view(grid),packet_precinct_vector_view(old(precincts)),None,limits),
))]
pub fn decode_progression_tile_packets(
    tile_parts: &[TilePartPayload<'_>],
    grid: &PacketGrid,
    precincts: &mut [PacketPrecinctDecoder],
    limits: &ResourceLimits,
) -> Result<TilePacketDecode, DecodeError> {
    decode_progression_tile_packets_selected(tile_parts, grid, precincts, None, limits)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_progression_resolution_levels(first,components,0,0),
))]
fn progression_resolution_levels(
    first: &TilePartPayload<'_>,
    components: u16,
) -> Result<u8, DecodeError> {
    let mut maximum = 0_u8;
    let mut component = 0_u16;
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_resolution_levels);reveal(crate::specs::part1_progression_resolution_levels_owned);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant component<=components,
            crate::specs::part1_progression_resolution_levels(first,components,0,0)
                ==crate::specs::part1_progression_resolution_levels(first,components,component,maximum),
        decreases components-component,
    ))]
    while component < components {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_progression_resolution_levels);reveal(crate::specs::part1_progression_resolution_levels_owned);}
        let style = first.component_coding_styles.style(component)?;
        let levels = match style.decomposition_levels.checked_add(1) {
            Some(levels) => levels,
            None => return Err(packet_arithmetic_overflow()),
        };
        maximum = maximum.max(levels);
        component = match component.checked_add(1) {
            Some(component) => component,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_resolution_levels);reveal(crate::specs::part1_progression_resolution_levels_owned);}
    Ok(maximum)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_progression_selection_check(counts@,available@,0),
))]
fn validate_progression_selection(counts: &[u8], available: &[u8]) -> Result<(), DecodeError> {
    let mut index = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_selection_check);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant index<=counts@.len(),
            crate::specs::part1_progression_selection_check(counts@,available@,0)
                ==crate::specs::part1_progression_selection_check(counts@,available@,index),
        decreases counts@.len()-index,
    ))]
    while index < counts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_progression_selection_check);}
        let count = match counts.get(index) {
            Some(count) => *count,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        let maximum = match available.get(index) {
            Some(count) => *count,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
        };
        if count == 0 || count > maximum {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        index = match index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_selection_check);}
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_progression_layout(tile_parts@,packet_grid_view(grid),packet_selection_view(selection),limits),
        result.is_ok() ==> tile_parts@.len()>0,
))]
fn validate_progression_layout(
    tile_parts: &[TilePartPayload<'_>],
    grid: &PacketGrid,
    selection: Option<&[u8]>,
    limits: &ResourceLimits,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_layout);}
    if tile_parts.is_empty() {
        return Err(packet_reader_error(0, MalformedKind::InvalidTilePart));
    }
    if tile_parts.len() as u64 > u64::from(limits.maximum_tile_parts()) {
        return Err(packet_reader_limit(
            Resource::TileParts,
            u64::from(limits.maximum_tile_parts()),
            tile_parts.len() as u64,
        ));
    }
    let first = match tile_parts.first() {
        Some(first) => first,
        None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
    };
    let maximum = progression_resolution_levels(first, grid.components)?;
    if first.coding_style.layers != grid.layers || maximum != grid.resolutions {
        return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
    }
    if let Some(counts) = selection {
        if counts.len() != usize::from(grid.components) {
            return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle));
        }
        validate_progression_selection(counts, &grid.component_resolutions)?;
    }
    Ok(())
}

struct ProgressionTilePreparation {
    tile_index: u16,
    index: usize,
    payload_bytes: u64,
    packed_payload_bytes: u64,
    declared_packets: u64,
    all_lengths: bool,
    packed: Vec<Vec<u8>>,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn progression_tile_preparation_view(input:&ProgressionTilePreparation)->crate::specs::Part1TilePacketPreparation {
        crate::specs::Part1TilePacketPreparation {
            tile_index:input.tile_index,index:input.index,payload_bytes:input.payload_bytes,
            packed_payload_bytes:input.packed_payload_bytes,declared_packets:input.declared_packets,
            all_lengths:input.all_lengths,packed:input.packed@.map_values(|bytes:Vec<u8>|bytes@),
        }
    }
    pub open spec fn progression_tile_preparation_outcome(value:Result<ProgressionTilePreparation,DecodeError>)
        ->Result<crate::specs::Part1TilePacketPreparation,DecodeError> {
        match value {Ok(input)=>Ok(progression_tile_preparation_view(&input)),Err(error)=>Err(error)}
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures progression_tile_preparation_outcome(result)==crate::specs::part1_progression_payloads(
        tile_parts@,crate::specs::Part1TilePacketPreparation {
            tile_index,index:0,payload_bytes:0,packed_payload_bytes:0,declared_packets:0,all_lengths:true,packed:Seq::empty(),
        },crate::limits::resource_packet_header_byte_limit(limits)),
))]
fn prepare_progression_payloads(
    tile_parts: &[TilePartPayload<'_>],
    tile_index: u16,
    limits: &ResourceLimits,
) -> Result<ProgressionTilePreparation, DecodeError> {
    let mut input = ProgressionTilePreparation {
        tile_index,
        index: 0,
        payload_bytes: 0,
        packed_payload_bytes: 0,
        declared_packets: 0,
        all_lengths: true,
        packed: Vec::with_capacity(tile_parts.len()),
    };
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(input.packed@.map_values(|bytes:Vec<u8>|bytes@) =~= Seq::<Seq<u8>>::empty());
        reveal(crate::specs::part1_progression_payloads);
        reveal(crate::specs::part1_progression_payloads_owned);
    }
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant input.index<=tile_parts@.len(),
            input.tile_index==tile_index,
            crate::specs::part1_progression_payloads(tile_parts@,crate::specs::Part1TilePacketPreparation {
                tile_index,index:0,payload_bytes:0,packed_payload_bytes:0,declared_packets:0,all_lengths:true,packed:Seq::empty(),
            },crate::limits::resource_packet_header_byte_limit(limits))
            ==crate::specs::part1_progression_payloads(tile_parts@,progression_tile_preparation_view(&input),
                crate::limits::resource_packet_header_byte_limit(limits)),
        decreases tile_parts@.len()-input.index,
    ))]
    while input.index < tile_parts.len() {
        #[cfg(verus_keep_ghost)]
        proof_decl! {let ghost prior=progression_tile_preparation_view(&input);}
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_progression_payloads);reveal(crate::specs::part1_progression_payloads_owned);}
        let part = match tile_parts.get(input.index) {
            Some(part) => part,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        let expected = match u8::try_from(input.index) {
            Ok(index) => index,
            Err(_) => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        if part.tile_index != input.tile_index
            || part.tile_part_index != expected
            || (part.tile_part_count != 0 && usize::from(part.tile_part_count) != tile_parts.len())
        {
            return Err(packet_reader_error(0, MalformedKind::InvalidTilePart));
        }
        input.payload_bytes = match input.payload_bytes.checked_add(part.data.len() as u64) {
            Some(total) => total,
            None => return Err(packet_arithmetic_overflow()),
        };
        let packed = part.packed_packet_headers.reassemble(limits)?;
        input.packed_payload_bytes =
            match input.packed_payload_bytes.checked_add(packed.len() as u64) {
                Some(total) => total,
                None => return Err(packet_arithmetic_overflow()),
            };
        if input.packed_payload_bytes > limits.maximum_packet_header_bytes() {
            return Err(packet_reader_limit(
                Resource::PacketHeaderBytes,
                limits.maximum_packet_header_bytes(),
                input.packed_payload_bytes,
            ));
        }
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost prior_packed=input.packed@.map_values(|bytes:Vec<u8>|bytes@);
            let ghost packed_bytes=packed@;
        }
        input.packed.push(packed);
        #[cfg(verus_keep_ghost)]
        proof! {assert(input.packed@.map_values(|bytes:Vec<u8>|bytes@) =~= prior_packed.push(packed_bytes));}
        if part.packet_lengths.is_present() {
            input.declared_packets = match input
                .declared_packets
                .checked_add(part.packet_lengths.packet_count())
            {
                Some(total) => total,
                None => return Err(packet_arithmetic_overflow()),
            };
        } else {
            input.all_lengths = false;
        }
        input.index = match input.index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_payloads);reveal(crate::specs::part1_progression_payloads_owned);}
    Ok(input)
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_precinct_vector_view(values:&[PacketPrecinctDecoder])
        -> Seq<crate::specs::Part1PacketPrecinctState> {
        values@.map_values(|value:PacketPrecinctDecoder|packet_precinct_view(&value))
    }

    pub proof fn packet_precinct_vector_known_fields(values: &[PacketPrecinctDecoder])
        ensures packet_precinct_vector_view(values)
            == values@.map_values(|value: PacketPrecinctDecoder| packet_precinct_view(&value)),
    {
        reveal(packet_precinct_vector_view);
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_progression_precinct_layout(packet_grid_view(grid),packet_precinct_vector_view(precincts)),
))]
fn validate_progression_precinct_layout(
    grid: &PacketGrid,
    precincts: &[PacketPrecinctDecoder],
) -> Result<(), DecodeError> {
    let count = match usize::try_from(grid.total_precinct_count()?) {
        Ok(count) => count,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    if precincts.len() != count {
        return Err(invalid_packet_header());
    }
    let mut index = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_precinct_indices);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant index<=precincts@.len(),
            crate::specs::part1_progression_precinct_layout(packet_grid_view(grid),packet_precinct_vector_view(precincts))
                ==crate::specs::part1_progression_precinct_indices(packet_grid_view(grid),packet_precinct_vector_view(precincts),index),
        decreases precincts@.len()-index,
    ))]
    while index < precincts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_progression_precinct_indices);}
        let precinct = match precincts.get(index) {
            Some(precinct) => precinct,
            None => return Err(invalid_packet_header()),
        };
        let expected =
            grid.precinct_index(precinct.component, precinct.resolution, precinct.precinct)?;
        if expected != index {
            return Err(invalid_packet_header());
        }
        index = match index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_progression_precinct_indices);}
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures progression_tile_preparation_outcome(result)==crate::specs::part1_progression_tile_input(
        tile_parts@,packet_grid_view(grid),packet_precinct_vector_view(precincts),packet_selection_view(selection),limits),
        result.is_ok() ==> tile_parts@.len()>0,
))]
fn prepare_progression_tile_input(
    tile_parts: &[TilePartPayload<'_>],
    grid: &PacketGrid,
    precincts: &[PacketPrecinctDecoder],
    selection: Option<&[u8]>,
    limits: &ResourceLimits,
) -> Result<ProgressionTilePreparation, DecodeError> {
    validate_progression_layout(tile_parts, grid, selection, limits)?;
    let first = match tile_parts.first() {
        Some(first) => first,
        None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
    };
    let input = prepare_progression_payloads(tile_parts, first.tile_index, limits)?;
    if input.all_lengths && input.declared_packets != grid.packet_count {
        return Err(packet_reader_error(0, MalformedKind::InvalidPacketLength));
    }
    validate_progression_precinct_layout(grid, precincts)?;
    Ok(input)
}

struct ProgressionTileParameters<'a, 'data> {
    tile_parts: &'a [TilePartPayload<'data>],
    grid: &'a PacketGrid,
    input: &'a ProgressionTilePreparation,
    selection: Option<&'a [u8]>,
    limits: &'a ResourceLimits,
}

struct ProgressionTileProgress<'a> {
    iterator: ProgressionPacketIterator<'a>,
    length_iterator: crate::codestream::PacketLengthIter<'a>,
    current_tile_part: usize,
    length_tile_part: usize,
    offset: usize,
    packed_offset: usize,
    packets: u64,
    present_packets: u64,
    contributions: u64,
    segments: u64,
    passes: u64,
    packet_header_bytes: u64,
    packet_body_bytes: u64,
    seen: Vec<bool>,
    remaining_packets: u64,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn progression_tile_parameters_view<'a,'data>(value:&ProgressionTileParameters<'a,'data>)
        ->crate::specs::Part1TilePacketParameters {
        crate::specs::Part1TilePacketParameters {
            parts:crate::codestream::tile_parts_owned_view(value.tile_parts@),grid:packet_grid_view(value.grid),input:progression_tile_preparation_view(value.input),
            selection:packet_selection_view(value.selection),
            caps:crate::specs::Part1TilePacketCaps {
                work:crate::limits::resource_work_limit(value.limits),
                header:crate::limits::resource_packet_header_byte_limit(value.limits),
                blocks:crate::limits::resource_code_block_limit(value.limits),
                passes:crate::limits::resource_code_block_pass_limit(value.limits),
                bytes:crate::limits::resource_code_block_byte_limit(value.limits),
                input:crate::limits::resource_input_byte_limit(value.limits),
            },
        }
    }
    pub closed spec fn progression_tile_progress_view(value:&ProgressionTileProgress<'_>)->crate::specs::Part1TilePacketProgress {
        crate::specs::Part1TilePacketProgress {
            iterator:progression_packet_iterator_view(&value.iterator),
            length_iterator:crate::codestream::packet_length_iter_view(&value.length_iterator),
            current_tile_part:value.current_tile_part,length_tile_part:value.length_tile_part,
            offset:value.offset,packed_offset:value.packed_offset,packets:value.packets,present_packets:value.present_packets,
            contributions:value.contributions,segments:value.segments,passes:value.passes,
            packet_header_bytes:value.packet_header_bytes,packet_body_bytes:value.packet_body_bytes,
            seen:value.seen@,remaining_packets:value.remaining_packets,
        }
    }
    pub open spec fn progression_tile_progress_outcome(value:Result<ProgressionTileProgress<'_>,DecodeError>)
        ->Result<crate::specs::Part1TilePacketProgress,DecodeError> {
        match value {Ok(progress)=>Ok(progression_tile_progress_view(&progress)),Err(error)=>Err(error)}
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures progression_tile_progress_outcome(result)==crate::specs::part1_tile_progress_initial(progression_tile_parameters_view(params)),
))]
fn progression_tile_progress_new<'a, 'data>(
    params: &ProgressionTileParameters<'a, 'data>,
) -> Result<ProgressionTileProgress<'a>, DecodeError> {
    let first = match params.tile_parts.first() {
        Some(first) => first,
        None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
    };
    let iterator = progression_packet_iterator_new(
        params.grid,
        first.coding_style.progression_order,
        &first.progression_changes,
        params.limits,
    )?;
    let length_iterator = first.packet_lengths.iter();
    let seen_length = match usize::try_from(params.grid.packet_count) {
        Ok(length) => length,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    let seen = vec![false; seen_length];
    #[cfg(verus_keep_ghost)]
    proof! {assert(seen@ =~= Seq::new(params.grid.packet_count as nat,|i:int|false));}
    Ok(ProgressionTileProgress {
        iterator,
        length_iterator,
        current_tile_part: 0,
        length_tile_part: 0,
        offset: 0,
        packed_offset: 0,
        packets: 0,
        present_packets: 0,
        contributions: 0,
        segments: 0,
        passes: 0,
        packet_header_bytes: 0,
        packet_body_bytes: 0,
        seen,
        remaining_packets: params.limits.maximum_work_units(),
    })
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_progress_view(final(p)))==crate::specs::part1_tile_boundary(
        progression_tile_parameters_view(params),progression_tile_progress_view(old(p))),
))]
fn advance_progression_tile_part<'a, 'data>(
    params: &ProgressionTileParameters<'a, 'data>,
    p: &mut ProgressionTileProgress<'a>,
) -> Result<(bool, bool), DecodeError> {
    let previous = p.current_tile_part;
    scan_progression_tile_boundary(params, p)?;
    if p.current_tile_part != previous {
        let Some(next) = params.tile_parts.get(p.current_tile_part) else {
            return Ok((true, false));
        };
        p.iterator = progression_packet_iterator_new(
            params.grid,
            next.coding_style.progression_order,
            &next.progression_changes,
            params.limits,
        )?;
        Ok((true, true))
    } else {
        Ok((false, true))
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_progress_view(final(p)))==crate::specs::part1_tile_boundary_scan(
        progression_tile_parameters_view(params),progression_tile_progress_view(old(p))),
        progression_tile_progress_view(final(p))==crate::specs::part1_tile_boundary_frame(
            progression_tile_progress_view(old(p)),progression_tile_progress_view(final(p))),
))]
fn scan_progression_tile_boundary<'a, 'data>(
    params: &ProgressionTileParameters<'a, 'data>,
    p: &mut ProgressionTileProgress<'a>,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {let ghost initial=progression_tile_progress_view(p);}
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_tile_boundary_scan);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant
            progression_tile_progress_view(p)==crate::specs::part1_tile_boundary_frame(
                progression_tile_progress_view(old(p)),progression_tile_progress_view(p)),
            crate::specs::part1_tile_boundary_scan(progression_tile_parameters_view(params),progression_tile_progress_view(old(p)))
                ==crate::specs::part1_tile_boundary_scan(progression_tile_parameters_view(params),progression_tile_progress_view(p)),
        decreases params.tile_parts@.len()-p.current_tile_part,
    ))]
    while p.current_tile_part < params.tile_parts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_tile_boundary_scan);}
        let part = match params.tile_parts.get(p.current_tile_part) {
            Some(part) => part,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        let packed = match params.input.packed.get(p.current_tile_part) {
            Some(packed) => packed,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        if p.offset < part.data.len() || p.packed_offset < packed.len() {
            return Ok(());
        }
        if p.offset != part.data.len() || p.packed_offset != packed.len() {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
        if part.packet_lengths.is_present()
            && p.length_tile_part == p.current_tile_part
            && p.length_iterator.next_length()?.is_some()
        {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::InvalidPacketLength,
            ));
        }
        p.current_tile_part = match p.current_tile_part.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        p.offset = 0;
        p.packed_offset = 0;
    }
    #[cfg(verus_keep_ghost)]
    proof! {
        reveal(crate::specs::part1_tile_boundary_scan);
        assert((Ok(()),progression_tile_progress_view(p))==
            crate::specs::part1_tile_boundary_scan(progression_tile_parameters_view(params),initial));
    }
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result, final(contexts)@) == crate::specs::part1_packet_context_layers(old(contexts)@, layer),
        result==Ok(()),
        final(contexts)@==old(contexts)@.map_values(|context:CodeBlockPacketContext|
            crate::specs::part1_packet_context_layer(context,layer)),
))]
fn set_progression_context_layer(
    contexts: &mut [CodeBlockPacketContext],
    layer: u16,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {let ghost initial=contexts@;}
    let mut index = 0_usize;
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant index<=contexts@.len(),contexts@.len()==initial.len(),
            forall|i:int|0<=i<contexts@.len() ==> contexts@[i]==if i<index {
                crate::specs::part1_packet_context_layer(initial[i],layer)
            }else{initial[i]},
        decreases contexts@.len()-index,
    ))]
    while index < contexts.len() {
        {
            let context = match contexts.get_mut(index) {
                Some(context) => context,
                None => return Err(invalid_packet_header()),
            };
            context.layer = layer;
        }
        index = match index.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {assert(contexts@ =~= initial.map_values(|context:CodeBlockPacketContext|crate::specs::part1_packet_context_layer(context,layer)));}
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,packet_precinct_view(final(precinct)))==crate::specs::part1_tile_precinct_packet(
        progression_tile_parameters_view(params),*part,progression_tile_progress_view(p),coordinate,expected,
        packet_precinct_view(old(precinct))),
))]
fn decode_progression_precinct_packet(
    params: &ProgressionTileParameters<'_, '_>,
    part: &TilePartPayload<'_>,
    p: &ProgressionTileProgress<'_>,
    coordinate: PacketCoordinate,
    expected: Option<u32>,
    precinct: &mut PacketPrecinctDecoder,
) -> Result<(PacketBodyDecode, usize, usize), DecodeError> {
    set_progression_context_layer(&mut precinct.contexts, coordinate.layer)?;
    let packed = match params.input.packed.get(p.current_tile_part) {
        Some(packed) => packed,
        None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
    };
    let decode = match params.selection {
        Some(counts) => {
            coordinate.resolution
                < *match counts.get(usize::from(coordinate.component)) {
                    Some(count) => count,
                    None => return Err(packet_reader_error(0, MalformedKind::InvalidCodingStyle)),
                }
        }
        None => true,
    };
    let word = p.packets;
    #[cfg(verus_keep_ghost)]
    proof! {assert(word & 65535u64 <= 65535u64) by(bit_vector);}
    let sequence = match u16::try_from(word & u64::from(u16::MAX)) {
        Ok(sequence) => sequence,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    decode_precinct_packet(
        part,
        p.offset,
        packed,
        p.packed_offset,
        expected,
        sequence,
        precinct,
        decode,
        params.limits,
    )
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn progression_tile_execution_view(precincts:&[PacketPrecinctDecoder],p:&ProgressionTileProgress<'_>)
        ->crate::specs::Part1TilePacketExecution {
        crate::specs::Part1TilePacketExecution {progress:progression_tile_progress_view(p),precincts:packet_precinct_vector_view(precincts)}
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_execution_view(final(precincts),final(p)))==crate::specs::part1_tile_packet(
        progression_tile_parameters_view(params),progression_tile_execution_view(old(precincts),old(p)),coordinate),
))]
fn execute_progression_packet<'a, 'data>(
    params: &ProgressionTileParameters<'a, 'data>,
    precincts: &mut [PacketPrecinctDecoder],
    p: &mut ProgressionTileProgress<'a>,
    coordinate: PacketCoordinate,
) -> Result<(), DecodeError> {
    let part = match params.tile_parts.get(p.current_tile_part) {
        Some(part) => part,
        None => {
            return Err(DecodeError::MalformedInput {
                offset: params.input.payload_bytes,
                kind: MalformedKind::Truncated,
            });
        }
    };
    if p.length_tile_part != p.current_tile_part {
        p.length_iterator = part.packet_lengths.iter();
        p.length_tile_part = p.current_tile_part;
    }
    let expected = if part.packet_lengths.is_present() {
        Some(match p.length_iterator.next_length()? {
            Some(length) => length,
            None => {
                return Err(packet_reader_error(
                    p.offset,
                    MalformedKind::InvalidPacketLength,
                ));
            }
        })
    } else {
        None
    };
    let index = params.grid.precinct_index(
        coordinate.component,
        coordinate.resolution,
        coordinate.precinct,
    )?;
    let product = match index.checked_mul(usize::from(params.grid.layers)) {
        Some(product) => product,
        None => return Err(packet_arithmetic_overflow()),
    };
    let seen_index = match product.checked_add(usize::from(coordinate.layer)) {
        Some(index) => index,
        None => return Err(packet_arithmetic_overflow()),
    };
    let seen = match p.seen.get(seen_index) {
        Some(seen) => *seen,
        None => {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::InvalidPacketHeader,
            ));
        }
    };
    if !crate::refinement::progression_emit_allowed(seen) {
        return Ok(());
    }
    if index >= precincts.len() {
        return Err(packet_reader_error(
            p.offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost prior_native=precincts@;
        let ghost prior=packet_precinct_vector_view(precincts);
        let ghost packet_expected=crate::specs::part1_tile_precinct_packet(
            progression_tile_parameters_view(params),*part,progression_tile_progress_view(p),coordinate,expected,prior[index as int]);
    }
    let result = {
        let precinct = &mut precincts[index];
        decode_progression_precinct_packet(params, part, p, coordinate, expected, precinct)
    };
    #[cfg(verus_keep_ghost)]
    proof! {
        assert forall|i:int|0<=i<precincts@.len() && i!=index as int implies precincts@[i]==prior_native[i] by {}
        assert(packet_precinct_vector_view(precincts) =~= prior.update(index as int,packet_expected.1));
        assert(result==packet_expected.0);
    }
    let (decoded, tile_bytes, packed_bytes) = result?;
    account_progression_packet(p, decoded, tile_bytes, packed_bytes, expected, seen_index)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_progress_view(final(p)))==crate::specs::part1_tile_account(
        progression_tile_progress_view(old(p)),decoded,tile_bytes,packed_bytes,expected,seen_index),
))]
fn account_progression_packet(
    p: &mut ProgressionTileProgress<'_>,
    decoded: PacketBodyDecode,
    tile_bytes: usize,
    packed_bytes: usize,
    expected: Option<u32>,
    seen_index: usize,
) -> Result<(), DecodeError> {
    if seen_index >= p.seen.len() {
        return Err(packet_reader_error(
            p.offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    if decoded.bytes_consumed == 0 {
        return Err(packet_reader_error(
            p.offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    match expected {
        Some(expected) if decoded.bytes_consumed != expected => {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::InvalidPacketLength,
            ));
        }
        _ => {}
    }
    p.offset = match p.offset.checked_add(tile_bytes) {
        Some(offset) => offset,
        None => {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    p.packed_offset = match p.packed_offset.checked_add(packed_bytes) {
        Some(offset) => offset,
        None => {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    p.packets = match p.packets.checked_add(1) {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    #[cfg(verus_keep_ghost)]
    proof_decl! {let ghost prior_seen=p.seen@;}
    p.seen[seen_index] = true;
    #[cfg(verus_keep_ghost)]
    proof! {assert(p.seen@ =~= prior_seen.update(seen_index as int,true));}
    let present = if decoded.present { 1_u64 } else { 0_u64 };
    p.present_packets = match p.present_packets.checked_add(present) {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    p.contributions = match p
        .contributions
        .checked_add(u64::from(decoded.contributions))
    {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    p.segments = match p.segments.checked_add(u64::from(decoded.segments)) {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    p.passes = match p.passes.checked_add(u64::from(decoded.passes)) {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    p.packet_header_bytes = match p
        .packet_header_bytes
        .checked_add(u64::from(decoded.header_bytes))
    {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    p.packet_body_bytes = match p
        .packet_body_bytes
        .checked_add(u64::from(decoded.body_bytes))
    {
        Some(total) => total,
        None => return Err(packet_arithmetic_overflow()),
    };
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_progress_view(final(p)))==crate::specs::part1_tile_finish(
        progression_tile_parameters_view(params),progression_tile_progress_view(old(p))),
))]
fn finish_progression_tile_packets(
    params: &ProgressionTileParameters<'_, '_>,
    p: &mut ProgressionTileProgress<'_>,
) -> Result<TilePacketDecode, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_tile_finish_scan);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant crate::specs::part1_tile_finish_scan(progression_tile_parameters_view(params),progression_tile_progress_view(old(p)))
            ==crate::specs::part1_tile_finish_scan(progression_tile_parameters_view(params),progression_tile_progress_view(p)),
        decreases params.tile_parts@.len()-p.current_tile_part,
    ))]
    while p.current_tile_part < params.tile_parts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_tile_finish_scan);}
        let part = match params.tile_parts.get(p.current_tile_part) {
            Some(part) => part,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        let packed = match params.input.packed.get(p.current_tile_part) {
            Some(packed) => packed,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTilePart)),
        };
        if p.offset != part.data.len() || p.packed_offset != packed.len() {
            return Err(packet_reader_error(p.offset, MalformedKind::TrailingData));
        }
        if part.packet_lengths.is_present()
            && p.length_tile_part == p.current_tile_part
            && p.length_iterator.next_length()?.is_some()
        {
            return Err(packet_reader_error(
                p.offset,
                MalformedKind::InvalidPacketLength,
            ));
        }
        p.current_tile_part = match p.current_tile_part.checked_add(1) {
            Some(index) => index,
            None => return Err(packet_arithmetic_overflow()),
        };
        p.offset = 0;
        p.packed_offset = 0;
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_tile_finish_scan);}
    if p.packets != params.grid.packet_count {
        return Err(DecodeError::MalformedInput {
            offset: params.input.payload_bytes,
            kind: MalformedKind::Truncated,
        });
    }
    let tile_parts = match u32::try_from(params.tile_parts.len()) {
        Ok(count) => count,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    Ok(TilePacketDecode {
        tile_index: params.input.tile_index,
        tile_parts,
        packets: p.packets,
        present_packets: p.present_packets,
        contributions: p.contributions,
        segments: p.segments,
        passes: p.passes,
        packet_header_bytes: p.packet_header_bytes,
        packet_body_bytes: p.packet_body_bytes,
        payload_bytes: params.input.payload_bytes,
    })
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,packet_precinct_vector_view(final(precincts)))==crate::specs::part1_progression_tile_decode(
        tile_parts@,packet_grid_view(grid),packet_precinct_vector_view(old(precincts)),packet_selection_view(maximum_resolution_counts),limits),
))]
pub(crate) fn decode_progression_tile_packets_selected(
    tile_parts: &[TilePartPayload<'_>],
    grid: &PacketGrid,
    precincts: &mut [PacketPrecinctDecoder],
    maximum_resolution_counts: Option<&[u8]>,
    limits: &ResourceLimits,
) -> Result<TilePacketDecode, DecodeError> {
    let input = prepare_progression_tile_input(
        tile_parts,
        grid,
        precincts,
        maximum_resolution_counts,
        limits,
    )?;
    let params = ProgressionTileParameters {
        tile_parts,
        grid,
        input: &input,
        selection: maximum_resolution_counts,
        limits,
    };
    let mut progress = progression_tile_progress_new(&params)?;
    run_progression_tile_packets(&params, precincts, &mut progress)?;
    finish_progression_tile_packets(&params, &mut progress)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,progression_tile_execution_view(final(precincts),final(p)))==crate::specs::part1_tile_run(
        progression_tile_parameters_view(params),progression_tile_execution_view(old(precincts),old(p))),
))]
fn run_progression_tile_packets<'a, 'data>(
    params: &ProgressionTileParameters<'a, 'data>,
    precincts: &mut [PacketPrecinctDecoder],
    p: &mut ProgressionTileProgress<'a>,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_tile_run);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant crate::specs::part1_tile_run(progression_tile_parameters_view(params),
            progression_tile_execution_view(old(precincts),old(p)))
            ==crate::specs::part1_tile_run(progression_tile_parameters_view(params),progression_tile_execution_view(precincts,p)),
        decreases p.remaining_packets,
    ))]
    loop {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_tile_run);}
        let coordinate = match p.iterator.next_packet()? {
            Some(coordinate) => coordinate,
            None => return Ok(()),
        };
        if p.remaining_packets == 0 {
            return Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange,
            ));
        }
        p.remaining_packets -= 1;
        let (changed, more) = advance_progression_tile_part(params, p)?;
        if changed {
            if more {
                continue;
            } else {
                return Ok(());
            }
        }
        execute_progression_packet(params, precincts, p, coordinate)?;
    }
}

#[derive(Clone, Copy)]
struct PacketBodyPreflight {
    index: usize,
    end: usize,
}

#[derive(Clone, Copy)]
struct PacketBodyExecutionProgress {
    index: usize,
    offset: usize,
    segments: u32,
    passes: u32,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn packet_body_contributions_view(values: &[Option<CodeBlockContribution>])
        -> Seq<Option<crate::specs::Part1CodeBlockContribution>>
    {
        values@.map_values(|value: Option<CodeBlockContribution>| code_block_contribution_option_view(value))
    }

    pub closed spec fn packet_body_preflight_view(value: &PacketBodyPreflight)
        -> crate::specs::Part1PacketBodyPreflight
    {
        crate::specs::Part1PacketBodyPreflight { index: value.index, end: value.end }
    }

    pub closed spec fn packet_body_execution_view(
        decoders: &[Tier1CodeBlockDecoder], progress: &PacketBodyExecutionProgress,
    ) -> crate::specs::Part1PacketBodyExecution {
        crate::specs::Part1PacketBodyExecution {
            decoders: decoders@.map_values(|decoder: Tier1CodeBlockDecoder| crate::tier1::tier1_decoder_state(&decoder)),
            index: progress.index, offset: progress.offset, segments: progress.segments, passes: progress.passes,
        }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_body_preflight_view(final(progress))) == crate::specs::part1_packet_body_preflight_at(
        packet_body_preflight_view(old(progress)), packet_body_contributions_view(contributions), data@, error_offsets.0,error_offsets.1),
        error_offsets.1==0 ==> (result,packet_body_preflight_view(final(progress)))==crate::specs::part1_packet_body_preflight(
            packet_body_preflight_view(old(progress)),packet_body_contributions_view(contributions),data@,error_offsets.0),
))]
fn preflight_packet_body_ranges(
    contributions: &[Option<CodeBlockContribution>],
    data: &[u8],
    progress: &mut PacketBodyPreflight,
    error_offsets: (usize, usize),
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial=packet_body_preflight_view(progress);
        let ghost expected=crate::specs::part1_packet_body_preflight_at(initial,packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1);
    }
    #[cfg(verus_keep_ghost)]
    proof! {assert(initial==packet_body_preflight_view(old(progress)));}
    let error_offset = error_offsets.0;
    let local_offset = error_offsets.1;
    let slots = contributions.len();
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_packet_body_preflight); reveal(crate::specs::part1_packet_body_preflight_at); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant
            slots == contributions.len(),
            initial==packet_body_preflight_view(old(progress)),
            expected==crate::specs::part1_packet_body_preflight_at(initial,
                packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1),
            error_offset==error_offsets.0,local_offset==error_offsets.1,
            expected == crate::specs::part1_packet_body_preflight_at(packet_body_preflight_view(progress),
                packet_body_contributions_view(contributions), data@, error_offsets.0,error_offsets.1),
        decreases slots as int - progress.index as int,
    ))]
    while progress.index < slots {
        #[cfg(verus_keep_ghost)]
        proof_decl! {let ghost prior=packet_body_preflight_view(progress);}
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_body_preflight); reveal(crate::specs::part1_packet_body_preflight_at); }
        if let Some(contribution) = contributions[progress.index] {
            #[cfg(verus_keep_ghost)]
            proof! {
                assert(packet_body_contributions_view(contributions)[prior.index as int]==
                    Some(code_block_contribution_view(&contribution)));
            }
            let length = match usize::try_from(contribution.data_length) {
                Ok(length) => length,
                Err(_) => {
                    return Err(packet_reader_error(
                        local_offset,
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
            progress.end = match progress.end.checked_add(length) {
                Some(end) => end,
                None => {
                    let error =
                        packet_reader_error(local_offset, MalformedKind::ArithmeticOverflow);
                    #[cfg(verus_keep_ghost)]
                    proof! {
                        assert(packet_body_preflight_view(progress)==prior);
                        assert(crate::specs::part1_packet_body_preflight_at(prior,
                            packet_body_contributions_view(contributions),data@,error_offset,local_offset)
                            ==(Err(crate::specs::part1_packet_reader_error(local_offset,MalformedKind::ArithmeticOverflow)),prior));
                        assert(expected==(Err(error),packet_body_preflight_view(progress)));
                        assert(crate::specs::part1_packet_body_preflight_at(packet_body_preflight_view(old(progress)),
                            packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1)==expected);
                    }
                    return Err(error);
                }
            };
            if progress.end > data.len() {
                let error = packet_reader_error(error_offset, MalformedKind::Truncated);
                #[cfg(verus_keep_ghost)]
                proof! {
                    assert(crate::specs::part1_packet_body_preflight_at(prior,
                        packet_body_contributions_view(contributions),data@,error_offset,local_offset)
                        ==(Err(crate::specs::part1_packet_reader_error(error_offset,MalformedKind::Truncated)),packet_body_preflight_view(progress)));
                    assert(expected==(Err(error),packet_body_preflight_view(progress)));
                    assert(crate::specs::part1_packet_body_preflight_at(packet_body_preflight_view(old(progress)),
                        packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1)==expected);
                }
                return Err(error);
            }
        }
        progress.index = match progress.index.checked_add(1) {
            Some(index) => index,
            None => {
                return Err(packet_reader_error(
                    local_offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_packet_body_preflight); reveal(crate::specs::part1_packet_body_preflight_at); }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_body_execution_view(final(decoders), final(progress)))
        == crate::specs::part1_packet_body_execute_at(packet_body_execution_view(old(decoders), old(progress)),
            packet_body_contributions_view(contributions), data@, error_offsets.0,error_offsets.1,decode_tier1,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        error_offsets.1==0 ==> (result,packet_body_execution_view(final(decoders),final(progress)))
            ==crate::specs::part1_packet_body_execute(packet_body_execution_view(old(decoders),old(progress)),
                packet_body_contributions_view(contributions),data@,error_offsets.0,decode_tier1,
                crate::limits::resource_code_block_pass_limit(limits),crate::limits::resource_code_block_byte_limit(limits),
                crate::limits::resource_input_byte_limit(limits),crate::limits::resource_work_limit(limits)),
        !decode_tier1 ==> final(decoders)@==old(decoders)@,
))]
fn execute_packet_body_contributions(
    decoders: &mut [Tier1CodeBlockDecoder],
    contributions: &[Option<CodeBlockContribution>],
    data: &[u8],
    progress: &mut PacketBodyExecutionProgress,
    error_offsets: (usize, usize),
    decode_tier1: bool,
    limits: &ResourceLimits,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial=packet_body_execution_view(decoders,progress);
        let ghost expected=crate::specs::part1_packet_body_execute_at(initial,
            packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1,decode_tier1,
            crate::limits::resource_code_block_pass_limit(limits),crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits),crate::limits::resource_work_limit(limits));
    }
    let error_offset = error_offsets.0;
    let local_offset = error_offsets.1;
    let slots = contributions.len();
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_packet_body_execute); reveal(crate::specs::part1_packet_body_execute_at); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant
            slots == contributions.len(),
            !decode_tier1 ==> decoders@==old(decoders)@,
            initial==packet_body_execution_view(old(decoders),old(progress)),
            expected==crate::specs::part1_packet_body_execute_at(initial,
                packet_body_contributions_view(contributions),data@,error_offsets.0,error_offsets.1,decode_tier1,
                crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
                crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
            error_offset==error_offsets.0,local_offset==error_offsets.1,
            expected == crate::specs::part1_packet_body_execute_at(packet_body_execution_view(decoders, progress),
                packet_body_contributions_view(contributions), data@, error_offsets.0,error_offsets.1,decode_tier1,
                crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
                crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        decreases slots as int - progress.index as int,
    ))]
    while progress.index < slots {
        #[cfg(verus_keep_ghost)]
        proof_decl! {let ghost prior=packet_body_execution_view(decoders,progress);}
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_packet_body_execute); reveal(crate::specs::part1_packet_body_execute_at); }
        if let Some(contribution) = contributions[progress.index] {
            let length = match usize::try_from(contribution.data_length) {
                Ok(length) => length,
                Err(_) => {
                    return Err(packet_reader_error(
                        local_offset,
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
            let body_end = match progress.offset.checked_add(length) {
                Some(end) => end,
                None => {
                    return Err(packet_reader_error(
                        local_offset,
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
            let body = data
                .get(progress.offset..body_end)
                .ok_or(DecodeError::MalformedInput {
                    offset: error_offset as u64,
                    kind: MalformedKind::Truncated,
                })?;
            if decode_tier1 {
                #[cfg(verus_keep_ghost)]
                proof_decl! {
                    let ghost prior_decoders = decoders@;
                    let ghost prior_states = packet_body_execution_view(decoders, progress).decoders;
                    let ghost selected_index = progress.index;
                }
                let decoded_result = {
                    let decoder = match decoders.get_mut(progress.index) {
                        Some(decoder) => decoder,
                        None => {
                            return Err(packet_reader_error(
                                local_offset,
                                MalformedKind::InvalidPacketHeader,
                            ));
                        }
                    };
                    decode_code_block_contribution_body(decoder, &contribution, body, limits)
                };
                #[cfg(verus_keep_ghost)]
                proof! {
                    assert(decoders@.len() == prior_decoders.len());
                    assert forall |i: int| 0 <= i < decoders@.len() && i != selected_index as int implies
                        decoders@[i] == prior_decoders[i] by {}
                    assert(packet_body_execution_view(decoders, progress).decoders =~=
                        prior_states.update(selected_index as int,
                            crate::tier1::tier1_decoder_state(&decoders@[selected_index as int])));
                }
                let decoded = decoded_result?;
                progress.segments = match progress.segments.checked_add(u32::from(decoded.segments))
                {
                    Some(total) => total,
                    None => {
                        return Err(packet_reader_error(
                            local_offset,
                            MalformedKind::ArithmeticOverflow,
                        ));
                    }
                };
                progress.passes = match progress.passes.checked_add(decoded.passes) {
                    Some(total) => total,
                    None => {
                        return Err(packet_reader_error(
                            local_offset,
                            MalformedKind::ArithmeticOverflow,
                        ));
                    }
                };
            }
            progress.offset = body_end;
        }
        progress.index = match progress.index.checked_add(1) {
            Some(index) => index,
            None => {
                return Err(packet_reader_error(
                    local_offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_packet_body_execute); reveal(crate::specs::part1_packet_body_execute_at); }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, precinct_header_view(final(states), final(subbands), final(contributions), final(reader), final(progress)))
        == crate::specs::part1_precinct_header_slot(
            precinct_header_view(old(states), old(subbands), old(contributions), old(reader), old(progress)),
            contexts@, parameters.layer, parameters.style),
        result.is_ok() ==> final(progress).local_index as nat == old(progress).local_index as nat + 1,
        final(progress).subband_index == old(progress).subband_index,
        final(states)@.len() == old(states)@.len(),
        final(subbands)@.len() == old(subbands)@.len(),
        final(contributions)@.len() == old(contributions)@.len(),
        result == Ok(()) || result.is_err(),
))]
fn decode_precinct_header_slot(
    states: &mut [CodeBlockPacketState],
    contexts: &[CodeBlockPacketContext],
    subbands: &mut [PacketSubbandState],
    contributions: &mut [Option<CodeBlockContribution>],
    reader: &mut PacketBitReader<'_>,
    parameters: PrecinctHeaderParameters,
    progress: &mut PrecinctHeaderProgress,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_precinct_header_slot); }
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost prior_states = states@;
        let ghost prior_subbands = subbands@;
        let ghost prior = precinct_header_view(states, subbands, contributions, reader, progress);
        let ghost subband_index = progress.subband_index;
    }
    let (header_result, block_index) = {
        let subband = subbands
            .get(progress.subband_index)
            .ok_or_else(invalid_packet_header)?;
        let block_index = subband
            .first_decoder
            .checked_add(progress.local_index)
            .ok_or_else(packet_arithmetic_overflow)?;
        let context = contexts
            .get(block_index)
            .ok_or_else(invalid_packet_header)?;
        let linear_index = match u32::try_from(progress.local_index) {
            Ok(value) => value,
            Err(_) => {
                #[cfg(verus_keep_ghost)]
                proof! { assert(progress.local_index > u32::MAX); }
                return Err(packet_arithmetic_overflow());
            }
        };
        let expected_x = linear_index
            .checked_rem(subband.code_blocks_across)
            .ok_or_else(packet_arithmetic_overflow)?;
        let expected_y = linear_index
            .checked_div(subband.code_blocks_across)
            .ok_or_else(packet_arithmetic_overflow)?;
        if context.layer != parameters.layer
            || context.leaf_x != expected_x
            || context.leaf_y != expected_y
            || !tier1_styles_equal(context.tier1_style, parameters.style)
        {
            return Err(invalid_packet_header());
        }
        let state = states
            .get_mut(block_index)
            .ok_or_else(invalid_packet_header)?;
        let subband = &mut subbands[progress.subband_index];
        let result = decode_code_block_contribution(
            state,
            &mut subband.inclusion_tree,
            &mut subband.zero_bitplane_tree,
            *context,
            reader,
        );
        (result, block_index)
    };
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(states@.len() == prior_states.len());
        assert(subbands@.len() == prior_subbands.len());
        assert forall |i: int| 0 <= i < states@.len() && i != block_index as int implies
            states@[i] == prior_states[i] by {}
        assert forall |i: int| 0 <= i < subbands@.len() && i != subband_index as int implies
            subbands@[i] == prior_subbands[i] by {}
        let after = precinct_header_view(states, subbands, contributions, reader, progress);
        let expected_header = crate::specs::part1_packet_header_decode(
            prior.states[block_index as int],
            prior.subbands[subband_index as int].inclusion_tree,
            prior.subbands[subband_index as int].zero_bitplane_tree,
            contexts@[block_index as int], prior.reader);
        assert(code_block_header_outcome(header_result) == expected_header.0);
        assert(code_block_packet_state_view(&states@[block_index as int]) == expected_header.1);
        assert(packet_subband_view(&subbands@[subband_index as int])
            == crate::specs::Part1PacketSubbandState {
                inclusion_tree: expected_header.2, zero_bitplane_tree: expected_header.3,
                ..prior.subbands[subband_index as int]
            });
        assert(after.reader == expected_header.4);
        assert(after.states =~= prior.states.update(block_index as int,
            code_block_packet_state_view(&states@[block_index as int])));
        assert(after.subbands =~= prior.subbands.update(subband_index as int,
            packet_subband_view(&subbands@[subband_index as int])));
    }
    let contribution = header_result?;
    if contribution.is_some() {
        progress.contribution_count = progress
            .contribution_count
            .checked_add(1)
            .ok_or_else(packet_arithmetic_overflow)?;
    }
    {
        let slot = contributions
            .get_mut(block_index)
            .ok_or_else(invalid_packet_header)?;
        *slot = contribution;
    }
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(packet_body_contributions_view(contributions) =~=
            prior.contributions.update(block_index as int, code_block_contribution_option_view(contribution)));
    }
    progress.local_index = progress
        .local_index
        .checked_add(1)
        .ok_or_else(packet_arithmetic_overflow)?;
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, precinct_header_view(final(states), final(subbands), final(contributions), final(reader), final(progress)))
        == crate::specs::part1_precinct_header_members(
            precinct_header_view(old(states), old(subbands), old(contributions), old(reader), old(progress)),
            contexts@, parameters.0.layer, parameters.0.style, parameters.1),
        final(progress).subband_index == old(progress).subband_index,
        final(states)@.len() == old(states)@.len(),
        final(subbands)@.len() == old(subbands)@.len(),
        final(contributions)@.len() == old(contributions)@.len(),
        result == Ok(()) || result.is_err(),
))]
fn decode_precinct_header_members(
    states: &mut [CodeBlockPacketState],
    contexts: &[CodeBlockPacketContext],
    subbands: &mut [PacketSubbandState],
    contributions: &mut [Option<CodeBlockContribution>],
    reader: &mut PacketBitReader<'_>,
    parameters: (PrecinctHeaderParameters, usize),
    progress: &mut PrecinctHeaderProgress,
) -> Result<(), DecodeError> {
    let decoder_count = parameters.1;
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_precinct_header_members_run); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant
            decoder_count == parameters.1,
            progress.subband_index == old(progress).subband_index,
            states@.len() == old(states)@.len(),
            subbands@.len() == old(subbands)@.len(),
            contributions@.len() == old(contributions)@.len(),
            crate::specs::part1_precinct_header_members(
                precinct_header_view(old(states), old(subbands), old(contributions), old(reader), old(progress)),
                contexts@, parameters.0.layer, parameters.0.style, decoder_count)
            == crate::specs::part1_precinct_header_members_run(
                precinct_header_view(states, subbands, contributions, reader, progress),
                contexts@, parameters.0.layer, parameters.0.style,
                if progress.local_index >= decoder_count { 0 }
                else { (decoder_count - progress.local_index) as nat }),
        decreases decoder_count as int - progress.local_index as int,
    ))]
    while progress.local_index < decoder_count {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_precinct_header_members_run); }
        decode_precinct_header_slot(
            states,
            contexts,
            subbands,
            contributions,
            reader,
            parameters.0,
            progress,
        )?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_precinct_header_members_run); }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, precinct_header_view(final(states), final(subbands), final(contributions), final(reader), final(progress)))
        == crate::specs::part1_precinct_headers(
            precinct_header_view(old(states), old(subbands), old(contributions), old(reader), old(progress)),
            contexts@, parameters.layer, parameters.style),
))]
fn decode_precinct_contribution_headers(
    states: &mut [CodeBlockPacketState],
    contexts: &[CodeBlockPacketContext],
    subbands: &mut [PacketSubbandState],
    contributions: &mut [Option<CodeBlockContribution>],
    reader: &mut PacketBitReader<'_>,
    parameters: PrecinctHeaderParameters,
    progress: &mut PrecinctHeaderProgress,
) -> Result<(), DecodeError> {
    let subband_count = subbands.len();
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_precinct_headers_run); }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant
            subband_count == subbands.len(),
            crate::specs::part1_precinct_headers(
                precinct_header_view(old(states), old(subbands), old(contributions), old(reader), old(progress)),
                contexts@, parameters.layer, parameters.style)
            == crate::specs::part1_precinct_headers_run(
                precinct_header_view(states, subbands, contributions, reader, progress),
                contexts@, parameters.layer, parameters.style,
                if progress.subband_index >= subband_count { 0 }
                else { (subband_count - progress.subband_index) as nat }),
        decreases subband_count as int - progress.subband_index as int,
    ))]
    while progress.subband_index < subband_count {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_precinct_headers_run); }
        let decoder_count = {
            let subband = subbands
                .get(progress.subband_index)
                .ok_or_else(invalid_packet_header)?;
            let count = u64::from(subband.code_blocks_across)
                .checked_mul(u64::from(subband.code_blocks_down))
                .ok_or_else(packet_arithmetic_overflow)?;
            let expected_count = match usize::try_from(count) {
                Ok(value) => value,
                Err(_) => {
                    #[cfg(verus_keep_ghost)]
                    proof! { assert(count > usize::MAX); }
                    return Err(packet_arithmetic_overflow());
                }
            };
            if expected_count != subband.decoder_count
                || subband.inclusion_tree.leaf_count()? != expected_count as u64
                || subband.zero_bitplane_tree.leaf_count()? != expected_count as u64
            {
                return Err(invalid_packet_header());
            }
            subband.decoder_count
        };
        progress.local_index = 0;
        decode_precinct_header_members(
            states,
            contexts,
            subbands,
            contributions,
            reader,
            (parameters, decoder_count),
            progress,
        )?;
        progress.subband_index = progress
            .subband_index
            .checked_add(1)
            .ok_or_else(packet_arithmetic_overflow)?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_precinct_headers_run); }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_precinct_view(final(precinct))) == crate::specs::part1_precinct_packet(
        packet_precinct_view(old(precinct)), tile_part, offset, packed_headers@, packed_offset,
        expected_packet_length, expected_sop_sequence, decode_tier1,
        crate::limits::resource_code_block_limit(limits), crate::limits::resource_packet_header_byte_limit(limits),
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        !decode_tier1 ==> final(precinct).decoders@==old(precinct).decoders@,
        (final(precinct).component,final(precinct).resolution,final(precinct).precinct)
            ==(old(precinct).component,old(precinct).resolution,old(precinct).precinct),
))]
fn decode_precinct_packet(
    tile_part: &TilePartPayload<'_>,
    offset: usize,
    packed_headers: &[u8],
    packed_offset: usize,
    expected_packet_length: Option<u32>,
    expected_sop_sequence: u16,
    precinct: &mut PacketPrecinctDecoder,
    decode_tier1: bool,
    limits: &ResourceLimits,
) -> Result<(PacketBodyDecode, usize, usize), DecodeError> {
    let component = precinct.component;
    if precinct.states.len() != precinct.contexts.len()
        || precinct.states.len() != precinct.decoders.len()
        || precinct.states.is_empty() != precinct.subbands.is_empty()
    {
        return Err(invalid_packet_header());
    }
    let code_blocks = precinct.states.len() as u64;
    if code_blocks > limits.maximum_code_blocks() {
        return Err(packet_reader_limit(
            Resource::CodeBlocks,
            limits.maximum_code_blocks(),
            code_blocks,
        ));
    }
    if code_blocks > limits.maximum_work_units() {
        return Err(packet_reader_limit(
            Resource::WorkUnits,
            limits.maximum_work_units(),
            code_blocks,
        ));
    }
    let data = match tile_part.data.get(offset..) {
        Some(data) => data,
        None => {
            return Err(packet_reader_error(
                offset,
                MalformedKind::InvalidPacketLength,
            ));
        }
    };
    let tier1_style = tile_part
        .component_coding_styles
        .style(component)?
        .tier1_coding_style()?;
    #[cfg(verus_keep_ghost)]
    proof! { crate::codestream::coding_style_known_packet_markers(&tile_part.coding_style); }
    decode_precinct_packet_payload(
        data,
        packed_headers,
        PrecinctPayloadParameters {
            error_offset: offset,
            packed_offset,
            expected_packet_length,
            expected_sop_sequence,
            style: tier1_style,
            sop: tile_part.coding_style.sop_markers,
            eph: tile_part.coding_style.eph_markers,
            packed: tile_part.packed_packet_headers.is_present(),
            decode_tier1,
        },
        precinct,
        limits,
    )
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures precinct_payload_reader_outcome(result) == crate::specs::part1_precinct_payload_prefix(
        data@, packed_headers@, precinct_payload_parameters_view(parameters),
        crate::limits::resource_packet_header_byte_limit(limits),
        crate::limits::resource_work_limit(limits)),
))]
fn decode_precinct_packet_payload_prefix<'a>(
    data: &'a [u8],
    packed_headers: &'a [u8],
    parameters: PrecinctPayloadParameters,
    limits: &ResourceLimits,
) -> Result<PrecinctPayloadReader<'a>, DecodeError> {
    let offset = parameters.error_offset;
    let packed_offset = parameters.packed_offset;
    let expected_sop_sequence = parameters.expected_sop_sequence;
    let mut tile_offset = 0_usize;
    if parameters.sop {
        let marker = match data.get(0..2) {
            Some(marker) => marker,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        let marker_length = match data.get(2..4) {
            Some(marker) => marker,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        if !crate::refinement::sop_valid(marker[0], marker[1], marker_length[0], marker_length[1]) {
            return Err(invalid_packet_header());
        }
        let sequence = match data.get(4..6) {
            Some(sequence) => sequence,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        let sequence_number = crate::refinement::sop_sequence(sequence[0], sequence[1]);
        if sequence_number != expected_sop_sequence {
            return Err(invalid_packet_header());
        }
        tile_offset = 6;
    }
    let packed = parameters.packed;
    let packet_data = if packed {
        match packed_headers.get(packed_offset..) {
            Some(data) => data,
            None => return Err(packet_reader_error(packed_offset, MalformedKind::Truncated)),
        }
    } else {
        match data.get(tile_offset..) {
            Some(data) => data,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        }
    };
    let mut reader = packet_reader_prefix(packet_data, limits);
    let packet_present = reader.read_bit()?;
    Ok(PrecinctPayloadReader {
        reader,
        packet_data,
        present: packet_present,
        sop_bytes: tile_offset,
    })
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_precinct_view(final(precinct))) == crate::specs::part1_precinct_payload(
        packet_precinct_view(old(precinct)), data@, packed_headers@, precinct_payload_parameters_view(parameters),
        crate::limits::resource_packet_header_byte_limit(limits),
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        !parameters.decode_tier1 ==> final(precinct).decoders@==old(precinct).decoders@,
        (final(precinct).component,final(precinct).resolution,final(precinct).precinct)
            ==(old(precinct).component,old(precinct).resolution,old(precinct).precinct),
))]
fn decode_precinct_packet_payload(
    data: &[u8],
    packed_headers: &[u8],
    parameters: PrecinctPayloadParameters,
    precinct: &mut PacketPrecinctDecoder,
    limits: &ResourceLimits,
) -> Result<(PacketBodyDecode, usize, usize), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! { let ghost initial_precinct = packet_precinct_view(precinct); }
    #[cfg(verus_keep_ghost)]
    proof! {
        reveal(crate::specs::part1_precinct_payload_headers);
    }
    let tier1_style = parameters.style;
    let prefix = decode_precinct_packet_payload_prefix(data, packed_headers, parameters, limits)?;
    #[cfg(verus_keep_ghost)]
    proof_decl! { let ghost initial_reader = precinct_payload_reader_view(prefix); }
    let mut reader = prefix.reader;
    let packet_data = prefix.packet_data;
    let packet_present = prefix.present;
    let mut contributions = vec![None; precinct.states.len()];
    let mut contribution_count = 0_u32;
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(contributions@.map_values(|value: Option<CodeBlockContribution>| code_block_contribution_option_view(value)) =~=
            Seq::new(initial_precinct.states.len(), |i: int| None));
    }
    if packet_present && !precinct.contexts.is_empty() {
        let layer = precinct
            .contexts
            .first()
            .ok_or_else(invalid_packet_header)?
            .layer;
        let mut progress = PrecinctHeaderProgress {
            subband_index: 0,
            local_index: 0,
            contribution_count,
        };
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost expected_headers = crate::specs::part1_precinct_headers(
                crate::specs::Part1PrecinctHeaderState {
                    states: initial_precinct.states, subbands: initial_precinct.subbands,
                    contributions: contributions@.map_values(|value: Option<CodeBlockContribution>| code_block_contribution_option_view(value)),
                    reader: packet_bit_reader_view(&reader), subband_index: 0, local_index: 0, contribution_count: 0,
                },
                precinct.contexts@, layer, tier1_style);
        }
        let header_result = decode_precinct_contribution_headers(
            &mut precinct.states,
            &precinct.contexts,
            &mut precinct.subbands,
            &mut contributions,
            &mut reader,
            PrecinctHeaderParameters {
                layer,
                style: tier1_style,
            },
            &mut progress,
        );
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(header_result == expected_headers.0);
            assert(packet_precinct_view(precinct).states == expected_headers.1.states);
            assert(packet_precinct_view(precinct).subbands == expected_headers.1.subbands);
            assert(packet_bit_reader_view(&reader) == expected_headers.1.reader);
            assert(contributions@.map_values(|value: Option<CodeBlockContribution>| code_block_contribution_option_view(value))
                == expected_headers.1.contributions);
            assert(progress.contribution_count == expected_headers.1.contribution_count);
            assert(packet_precinct_view(precinct) == crate::specs::Part1PacketPrecinctState {
                states: expected_headers.1.states, subbands: expected_headers.1.subbands, ..initial_precinct
            });
        }
        header_result?;
        contribution_count = progress.contribution_count;
    }
    decode_precinct_packet_payload_after_headers(
        data,
        parameters,
        PrecinctPayloadHeader {
            prefix: PrecinctPayloadReader {
                reader,
                packet_data,
                present: packet_present,
                sop_bytes: prefix.sop_bytes,
            },
            contributions,
            contribution_count,
        },
        precinct,
        limits,
    )
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_precinct_view(final(precinct))) == crate::specs::part1_precinct_payload_after_headers(
        packet_precinct_view(old(precinct)), precinct_payload_parameters_view(parameters), data@,
        precinct_payload_header_view(header).0.packet_data, precinct_payload_header_view(header).0.reader,
        precinct_payload_header_view(header).1, precinct_payload_header_view(header).2,
        precinct_payload_header_view(header).0.present, precinct_payload_header_view(header).0.sop_bytes,
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        !parameters.decode_tier1 ==> final(precinct).decoders@==old(precinct).decoders@,
        (final(precinct).component,final(precinct).resolution,final(precinct).precinct)
            ==(old(precinct).component,old(precinct).resolution,old(precinct).precinct),
))]
fn decode_precinct_packet_payload_after_headers(
    data: &[u8],
    parameters: PrecinctPayloadParameters,
    header: PrecinctPayloadHeader<'_>,
    precinct: &mut PacketPrecinctDecoder,
    limits: &ResourceLimits,
) -> Result<(PacketBodyDecode, usize, usize), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {
        reveal(crate::specs::part1_precinct_payload_after_headers);
        reveal(crate::specs::part1_precinct_payload_body);
    }
    let code_blocks = precinct.states.len() as u64;
    let offset = parameters.error_offset;
    let expected_packet_length = parameters.expected_packet_length;
    let decode_tier1 = parameters.decode_tier1;
    let mut reader = header.prefix.reader;
    let packet_data = header.prefix.packet_data;
    let packet_present = header.prefix.present;
    let mut tile_offset = header.prefix.sop_bytes;
    let mut packed_bytes_consumed = 0_usize;
    let packed = parameters.packed;
    let contributions = header.contributions;
    let contribution_count = header.contribution_count;
    reader.align_to_byte();
    let header_bytes = reader.bytes_consumed();
    if packed {
        packed_bytes_consumed = header_bytes;
    } else {
        tile_offset = match tile_offset.checked_add(header_bytes) {
            Some(offset) => offset,
            None => return Err(packet_arithmetic_overflow()),
        };
    }
    if parameters.eph {
        let marker_start = header_bytes;
        let marker_end = match marker_start.checked_add(2) {
            Some(end) => end,
            None => return Err(packet_arithmetic_overflow()),
        };
        let marker = match packet_data.get(marker_start..marker_end) {
            Some(marker) => marker,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        if !crate::refinement::eph_valid(marker[0], marker[1]) {
            return Err(invalid_packet_header());
        }
        if packed {
            packed_bytes_consumed = marker_end;
        } else {
            tile_offset = match tile_offset.checked_add(2) {
                Some(offset) => offset,
                None => return Err(packet_arithmetic_overflow()),
            };
        }
    }
    let body_start = tile_offset;
    let mut preflight = PacketBodyPreflight {
        index: 0,
        end: tile_offset,
    };
    preflight_packet_body_ranges(&contributions, data, &mut preflight, (offset, 0))?;
    tile_offset = preflight.end;
    let mut execution = PacketBodyExecutionProgress {
        index: 0,
        offset: body_start,
        segments: 0,
        passes: 0,
    };
    execute_packet_body_contributions(
        &mut precinct.decoders,
        &contributions,
        data,
        &mut execution,
        (offset, 0),
        decode_tier1,
        limits,
    )?;
    let body_bytes = match tile_offset.checked_sub(body_start) {
        Some(bytes) => bytes,
        None => return Err(packet_arithmetic_overflow()),
    };
    if tile_offset > usize::MAX - packed_bytes_consumed {
        return Err(packet_arithmetic_overflow());
    }
    let logical_bytes = crate::refinement::packet_logical_bytes(tile_offset, packed_bytes_consumed);
    let packet_length_matches = match expected_packet_length {
        Some(expected) => {
            let expected = match usize::try_from(expected) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            };
            crate::refinement::packet_length_matches(logical_bytes, expected)
        }
        None => true,
    };
    if !packet_length_matches {
        return Err(packet_reader_error(
            offset,
            MalformedKind::InvalidPacketLength,
        ));
    }
    Ok((
        PacketBodyDecode {
            present: packet_present,
            code_blocks: match u32::try_from(code_blocks) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            contributions: contribution_count,
            segments: execution.segments,
            passes: execution.passes,
            header_bytes: match u32::try_from(header_bytes) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            body_bytes: match u32::try_from(body_bytes) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
            bytes_consumed: match u32::try_from(logical_bytes) {
                Ok(value) => value,
                Err(_) => return Err(packet_arithmetic_overflow()),
            },
        },
        tile_offset,
        packed_bytes_consumed,
    ))
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn multi_packet_state_view(
        states:&[CodeBlockPacketState],inclusion:&TagTree,zero:&TagTree,contexts:&[CodeBlockPacketContext],
        decoders:&[Tier1CodeBlockDecoder],
    )->crate::specs::Part1MultiPacketState {
        crate::specs::Part1MultiPacketState {
            states:states@.map_values(|state:CodeBlockPacketState|code_block_packet_state_view(&state)),
            inclusion:tag_tree_view(inclusion),zero:tag_tree_view(zero),contexts:contexts@,
            decoders:decoders@.map_values(|decoder:Tier1CodeBlockDecoder|crate::tier1::tier1_decoder_state(&decoder)),
        }
    }
}

struct MultiPacketParameters<'a, 'data> {
    part: &'a TilePartPayload<'data>,
    offset: usize,
    limits: &'a ResourceLimits,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub open spec fn multi_admission_outcome(value:Result<&[u8],DecodeError>)
        ->Result<Seq<u8>,DecodeError> {
        match value {Ok(value)=>Ok(value@),Err(error)=>Err(error)}
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_multi_contexts(contexts@,style,layer,width,0,offset),
))]
fn validate_multi_packet_contexts(
    contexts: &[CodeBlockPacketContext],
    style: Tier1CodingStyle,
    layer: u16,
    width: u32,
    offset: usize,
) -> Result<(), DecodeError> {
    let mut index = 0_usize;
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_multi_contexts);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant index<=contexts@.len(),
            crate::specs::part1_multi_contexts(contexts@,style,layer,width,0,offset)
                ==crate::specs::part1_multi_contexts(contexts@,style,layer,width,index,offset),
        decreases contexts@.len()-index,
    ))]
    while index < contexts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_multi_contexts);}
        let context = match contexts.get(index) {
            Some(context) => context,
            None => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::InvalidPacketHeader,
                ));
            }
        };
        let linear = match u32::try_from(index) {
            Ok(index) => index,
            Err(_) => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        let x = match linear.checked_rem(width) {
            Some(x) => x,
            None => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        let y = match linear.checked_div(width) {
            Some(y) => y,
            None => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        if context.layer != layer
            || context.leaf_x != x
            || context.leaf_y != y
            || !tier1_styles_equal(context.tier1_style, style)
        {
            return Err(packet_reader_error(
                offset,
                MalformedKind::InvalidPacketHeader,
            ));
        }
        index = match index.checked_add(1) {
            Some(index) => index,
            None => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_multi_contexts);}
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures multi_admission_outcome(result)==crate::specs::part1_multi_packet_admission(
        multi_packet_state_view(states,inclusion,zero,contexts,decoders),params.part,params.offset,
        crate::limits::resource_code_block_limit(params.limits),crate::limits::resource_work_limit(params.limits)),
))]
fn validate_multi_packet_input<'a, 'data>(
    params: &MultiPacketParameters<'a, 'data>,
    states: &[CodeBlockPacketState],
    inclusion: &TagTree,
    zero: &TagTree,
    contexts: &[CodeBlockPacketContext],
    decoders: &[Tier1CodeBlockDecoder],
) -> Result<&'a [u8], DecodeError> {
    let offset = params.offset;
    if states.is_empty() || states.len() != contexts.len() || states.len() != decoders.len() {
        return Err(packet_reader_error(
            offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let count = states.len() as u64;
    if count > params.limits.maximum_code_blocks() {
        return Err(packet_reader_limit(
            Resource::CodeBlocks,
            params.limits.maximum_code_blocks(),
            count,
        ));
    }
    if count > params.limits.maximum_work_units() {
        return Err(packet_reader_limit(
            Resource::WorkUnits,
            params.limits.maximum_work_units(),
            count,
        ));
    }
    let leaves = match inclusion.levels.first() {
        Some(leaves) => leaves,
        None => return Err(packet_reader_error(offset, MalformedKind::InvalidTagTree)),
    };
    let zleaves = match zero.levels.first() {
        Some(leaves) => leaves,
        None => return Err(packet_reader_error(offset, MalformedKind::InvalidTagTree)),
    };
    let width = leaves.width;
    let height = leaves.height;
    if width == 0 || height == 0 {
        return Err(packet_reader_error(offset, MalformedKind::InvalidTagTree));
    }
    if inclusion.leaf_count()? != count
        || zero.leaf_count()? != count
        || width != zleaves.width
        || height != zleaves.height
    {
        return Err(packet_reader_error(offset, MalformedKind::InvalidTagTree));
    }
    let data = match params.part.data.get(offset..) {
        Some(data) => data,
        None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
    };
    let style = params.part.coding_style.tier1_coding_style()?;
    let layer = match contexts.first() {
        Some(context) => context.layer,
        None => {
            return Err(packet_reader_error(
                offset,
                MalformedKind::InvalidPacketHeader,
            ));
        }
    };
    validate_multi_packet_contexts(contexts, style, layer, width, offset)?;
    Ok(data)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures precinct_payload_reader_outcome(result)==crate::specs::part1_multi_packet_prefix(
        data@,sop,offset,crate::limits::resource_packet_header_byte_limit(limits),crate::limits::resource_work_limit(limits)),
))]
fn read_multi_packet_prefix<'a>(
    data: &'a [u8],
    sop: bool,
    offset: usize,
    limits: &ResourceLimits,
) -> Result<PrecinctPayloadReader<'a>, DecodeError> {
    let mut skip = 0_usize;
    if sop {
        let marker = match data.get(0..2) {
            Some(marker) => marker,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        let length = match data.get(2..4) {
            Some(length) => length,
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        };
        if marker[0] != SOP_MARKER[0]
            || marker[1] != SOP_MARKER[1]
            || length[0] != 0
            || length[1] != 4
        {
            return Err(packet_reader_error(
                offset,
                MalformedKind::InvalidPacketHeader,
            ));
        }
        match data.get(4..6) {
            Some(_) => {}
            None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
        }
        skip = 6;
    }
    let packet_data = match data.get(skip..) {
        Some(data) => data,
        None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
    };
    let mut reader = packet_reader_prefix(packet_data, limits);
    let present = reader.read_bit()?;
    Ok(PrecinctPayloadReader {
        reader,
        packet_data,
        present,
        sop_bytes: skip,
    })
}

#[derive(Clone, Copy)]
struct MultiHeaderProgress {
    index: usize,
    count: u32,
}

#[derive(Clone, Copy)]
struct MultiHeaderParameters<'a> {
    contexts: &'a [CodeBlockPacketContext],
    offset: usize,
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn multi_header_view(
        states:&[CodeBlockPacketState],inclusion:&TagTree,zero:&TagTree,contexts:&[CodeBlockPacketContext],
        contributions:&[Option<CodeBlockContribution>],reader:&PacketBitReader<'_>,progress:&MultiHeaderProgress,
    )->crate::specs::Part1MultiPacketHeader {
        crate::specs::Part1MultiPacketHeader {
            states:states@.map_values(|state:CodeBlockPacketState|code_block_packet_state_view(&state)),
            inclusion:tag_tree_view(inclusion),zero:tag_tree_view(zero),contexts:contexts@,
            contributions:packet_body_contributions_view(contributions),reader:packet_bit_reader_view(reader),
            index:progress.index,count:progress.count,
        }
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,multi_header_view(final(states),final(inclusion),final(zero),parameters.contexts,
        final(contributions),final(reader),final(progress)))==crate::specs::part1_multi_header_slot(
            multi_header_view(old(states),old(inclusion),old(zero),parameters.contexts,old(contributions),old(reader),old(progress)),parameters.offset),
        final(states)@.len()==old(states)@.len(),final(contributions)@.len()==old(contributions)@.len(),
))]
fn read_multi_packet_header_slot(
    states: &mut [CodeBlockPacketState],
    inclusion: &mut TagTree,
    zero: &mut TagTree,
    parameters: MultiHeaderParameters<'_>,
    contributions: &mut [Option<CodeBlockContribution>],
    reader: &mut PacketBitReader<'_>,
    progress: &mut MultiHeaderProgress,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial=multi_header_view(states,inclusion,zero,parameters.contexts,contributions,reader,progress);
        let ghost prior_states=states@;
        let ghost index=progress.index;
    }
    let context = match parameters.contexts.get(progress.index) {
        Some(context) => *context,
        None => {
            return Err(packet_reader_error(
                parameters.offset,
                MalformedKind::InvalidPacketHeader,
            ));
        }
    };
    if progress.index >= states.len() {
        return Err(packet_reader_error(
            parameters.offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    #[cfg(verus_keep_ghost)]
    proof_decl! {let ghost header=crate::specs::part1_packet_header_decode(
    initial.states[index as int],initial.inclusion,initial.zero,context,initial.reader);}
    let result = {
        let state = &mut states[progress.index];
        decode_code_block_contribution(state, inclusion, zero, context, reader)
    };
    #[cfg(verus_keep_ghost)]
    proof! {
        assert forall|i:int|0<=i<states@.len() && i!=index as int implies states@[i]==prior_states[i] by {}
        assert(states@.map_values(|state:CodeBlockPacketState|code_block_packet_state_view(&state))
            =~= initial.states.update(index as int,header.1));
    }
    let contribution = result?;
    if contribution.is_some() {
        progress.count = match progress.count.checked_add(1) {
            Some(count) => count,
            None => {
                return Err(packet_reader_error(
                    parameters.offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
    }
    {
        let slot = match contributions.get_mut(progress.index) {
            Some(slot) => slot,
            None => {
                return Err(packet_reader_error(
                    parameters.offset,
                    MalformedKind::InvalidPacketHeader,
                ));
            }
        };
        *slot = contribution;
    }
    #[cfg(verus_keep_ghost)]
    proof! {assert(packet_body_contributions_view(contributions) =~=
    initial.contributions.update(index as int,code_block_contribution_option_view(contribution)));}
    progress.index = match progress.index.checked_add(1) {
        Some(index) => index,
        None => {
            return Err(packet_reader_error(
                parameters.offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    Ok(())
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,multi_header_view(final(states),final(inclusion),final(zero),parameters.contexts,
        final(contributions),final(reader),final(progress)))==crate::specs::part1_multi_headers(
            multi_header_view(old(states),old(inclusion),old(zero),parameters.contexts,old(contributions),old(reader),old(progress)),parameters.offset),
        final(states)@.len()==old(states)@.len(),final(contributions)@.len()==old(contributions)@.len(),
))]
fn read_multi_packet_headers(
    states: &mut [CodeBlockPacketState],
    inclusion: &mut TagTree,
    zero: &mut TagTree,
    parameters: MultiHeaderParameters<'_>,
    contributions: &mut [Option<CodeBlockContribution>],
    reader: &mut PacketBitReader<'_>,
    progress: &mut MultiHeaderProgress,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_multi_headers);}
    #[cfg_attr(verus_keep_ghost,verus_spec(
        invariant states@.len()==old(states)@.len(),contributions@.len()==old(contributions)@.len(),
            crate::specs::part1_multi_headers(multi_header_view(old(states),old(inclusion),old(zero),
                parameters.contexts,old(contributions),old(reader),old(progress)),parameters.offset)
            ==crate::specs::part1_multi_headers(multi_header_view(states,inclusion,zero,parameters.contexts,contributions,reader,progress),parameters.offset),
        decreases parameters.contexts@.len()-progress.index,
    ))]
    while progress.index < parameters.contexts.len() {
        #[cfg(verus_keep_ghost)]
        proof! {reveal(crate::specs::part1_multi_headers);}
        read_multi_packet_header_slot(
            states,
            inclusion,
            zero,
            parameters,
            contributions,
            reader,
            progress,
        )?;
    }
    #[cfg(verus_keep_ghost)]
    proof! {reveal(crate::specs::part1_multi_headers);}
    Ok(())
}

#[derive(Clone, Copy)]
struct MultiPacketLayout {
    blocks: u64,
    present: bool,
    count: u32,
    header: usize,
    start: usize,
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures result==crate::specs::part1_multi_body_start(data@,sop,header,eph,offset),
))]
fn multi_packet_body_start(
    data: &[u8],
    sop: usize,
    header: usize,
    eph: bool,
    offset: usize,
) -> Result<usize, DecodeError> {
    let start = match sop.checked_add(header) {
        Some(start) => start,
        None => {
            return Err(packet_reader_error(
                offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    if !eph {
        return Ok(start);
    }
    let end = match start.checked_add(2) {
        Some(end) => end,
        None => {
            return Err(packet_reader_error(
                offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    let marker = match data.get(start..end) {
        Some(marker) => marker,
        None => return Err(packet_reader_error(offset, MalformedKind::Truncated)),
    };
    if marker[0] != EPH_MARKER[0] || marker[1] != EPH_MARKER[1] {
        return Err(packet_reader_error(
            offset,
            MalformedKind::InvalidPacketHeader,
        ));
    }
    Ok(end)
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,final(decoders)@.map_values(|decoder:Tier1CodeBlockDecoder|crate::tier1::tier1_decoder_state(&decoder)))
        ==crate::specs::part1_multi_body_data(
            old(decoders)@.map_values(|decoder:Tier1CodeBlockDecoder|crate::tier1::tier1_decoder_state(&decoder)),
            layout.blocks,data@,packet_body_contributions_view(contributions),layout.present,layout.count,layout.header,layout.start,params.offset,
            crate::limits::resource_code_block_pass_limit(params.limits),crate::limits::resource_code_block_byte_limit(params.limits),
            crate::limits::resource_input_byte_limit(params.limits),crate::limits::resource_work_limit(params.limits)),
))]
fn decode_multi_packet_body(
    params: &MultiPacketParameters<'_, '_>,
    data: &[u8],
    contributions: &[Option<CodeBlockContribution>],
    layout: MultiPacketLayout,
    decoders: &mut [Tier1CodeBlockDecoder],
) -> Result<PacketBodyDecode, DecodeError> {
    let offset = params.offset;
    let mut preflight = PacketBodyPreflight {
        index: 0,
        end: layout.start,
    };
    preflight_packet_body_ranges(contributions, data, &mut preflight, (offset, offset))?;
    let mut execution = PacketBodyExecutionProgress {
        index: 0,
        offset: layout.start,
        segments: 0,
        passes: 0,
    };
    execute_packet_body_contributions(
        decoders,
        contributions,
        data,
        &mut execution,
        (offset, offset),
        true,
        params.limits,
    )?;
    let bytes = match preflight.end.checked_sub(layout.start) {
        Some(bytes) => bytes,
        None => {
            return Err(packet_reader_error(
                offset,
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    Ok(PacketBodyDecode {
        present: layout.present,
        code_blocks: match u32::try_from(layout.blocks) {
            Ok(n) => n,
            Err(_) => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        },
        contributions: layout.count,
        segments: execution.segments,
        passes: execution.passes,
        header_bytes: match u32::try_from(layout.header) {
            Ok(n) => n,
            Err(_) => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        },
        body_bytes: match u32::try_from(bytes) {
            Ok(n) => n,
            Err(_) => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        },
        bytes_consumed: match u32::try_from(preflight.end) {
            Ok(n) => n,
            Err(_) => {
                return Err(packet_reader_error(
                    offset,
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        },
    })
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,multi_packet_state_view(final(states),final(inclusion),final(zero),contexts,final(decoders)))
        ==crate::specs::part1_multi_payload(multi_packet_state_view(old(states),old(inclusion),old(zero),contexts,old(decoders)),
            data@,crate::codestream::coding_style_packet_markers(&params.part.coding_style).0,
            crate::codestream::coding_style_packet_markers(&params.part.coding_style).1,params.offset,
            crate::limits::resource_packet_header_byte_limit(params.limits),
            crate::limits::resource_code_block_pass_limit(params.limits),crate::limits::resource_code_block_byte_limit(params.limits),
            crate::limits::resource_input_byte_limit(params.limits),crate::limits::resource_work_limit(params.limits)),
        final(states)@.len()==old(states)@.len(),
))]
fn decode_multi_packet_payload(
    params: &MultiPacketParameters<'_, '_>,
    data: &[u8],
    states: &mut [CodeBlockPacketState],
    inclusion: &mut TagTree,
    zero: &mut TagTree,
    contexts: &[CodeBlockPacketContext],
    decoders: &mut [Tier1CodeBlockDecoder],
) -> Result<PacketBodyDecode, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {
        reveal(crate::specs::part1_multi_payload);reveal(crate::specs::part1_multi_body);
        crate::codestream::coding_style_known_packet_markers(&params.part.coding_style);
    }
    let blocks = states.len() as u64;
    let prefix = read_multi_packet_prefix(
        data,
        params.part.coding_style.sop_markers,
        params.offset,
        params.limits,
    )?;
    let present = prefix.present;
    let mut reader = prefix.reader;
    let mut contributions = vec![None; states.len()];
    #[cfg(verus_keep_ghost)]
    proof! {assert(contributions@.map_values(|c:Option<CodeBlockContribution>|code_block_contribution_option_view(c))
    =~= Seq::new(states@.len(),|i:int|None));}
    let mut progress = MultiHeaderProgress { index: 0, count: 0 };
    if present {
        read_multi_packet_headers(
            states,
            inclusion,
            zero,
            MultiHeaderParameters {
                contexts,
                offset: params.offset,
            },
            &mut contributions,
            &mut reader,
            &mut progress,
        )?;
    }
    reader.align_to_byte();
    let header = reader.bytes_consumed();
    let start = multi_packet_body_start(
        data,
        prefix.sop_bytes,
        header,
        params.part.coding_style.eph_markers,
        params.offset,
    )?;
    decode_multi_packet_body(
        params,
        data,
        &contributions,
        MultiPacketLayout {
            blocks,
            present,
            count: progress.count,
            header,
            start,
        },
        decoders,
    )
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,multi_packet_state_view(final(execution.states),final(execution.inclusion_tree),final(execution.zero_bitplane_tree),
        execution.contexts,final(execution.decoders)))==crate::specs::part1_multi_code_block_packet(
            multi_packet_state_view(old(execution.states),old(execution.inclusion_tree),old(execution.zero_bitplane_tree),
                execution.contexts,old(execution.decoders)),tile_part,offset,limits),
))]
pub fn decode_multi_code_block_packet(
    tile_part: &TilePartPayload<'_>,
    offset: usize,
    execution: PacketCodeBlockExecution<'_>,
    limits: &ResourceLimits,
) -> Result<PacketBodyDecode, DecodeError> {
    let states = execution.states;
    let inclusion_tree = execution.inclusion_tree;
    let zero_bitplane_tree = execution.zero_bitplane_tree;
    let contexts = execution.contexts;
    let decoders = execution.decoders;
    let params = MultiPacketParameters {
        part: tile_part,
        offset,
        limits,
    };
    let data = validate_multi_packet_input(
        &params,
        states,
        inclusion_tree,
        zero_bitplane_tree,
        contexts,
        decoders,
    )?;
    decode_multi_packet_payload(
        &params,
        data,
        states,
        inclusion_tree,
        zero_bitplane_tree,
        contexts,
        decoders,
    )
}

#[cfg(verus_keep_ghost)]
verus! {
    pub closed spec fn single_packet_state_view(
        state:&CodeBlockPacketState,inclusion:&TagTree,zero:&TagTree,decoder:&Tier1CodeBlockDecoder,
    )->crate::specs::Part1SinglePacketState {
        crate::specs::Part1SinglePacketState {
            state:code_block_packet_state_view(state),inclusion:tag_tree_view(inclusion),zero:tag_tree_view(zero),
            decoder:crate::tier1::tier1_decoder_state(decoder),
        }
    }
}

#[cfg_attr(verus_keep_ghost,verus_spec(result =>
    ensures (result,single_packet_state_view(final(state),final(inclusion_tree),final(zero_bitplane_tree),final(decoder)))
        ==crate::specs::part1_single_code_block_packet(
            single_packet_state_view(old(state),old(inclusion_tree),old(zero_bitplane_tree),old(decoder)),
            payload@,context,crate::limits::resource_packet_header_byte_limit(limits),
            crate::limits::resource_code_block_pass_limit(limits),crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits),crate::limits::resource_work_limit(limits)),
))]
pub fn decode_single_code_block_packet(
    payload: &[u8],
    state: &mut CodeBlockPacketState,
    inclusion_tree: &mut TagTree,
    zero_bitplane_tree: &mut TagTree,
    context: CodeBlockPacketContext,
    decoder: &mut Tier1CodeBlockDecoder,
    limits: &ResourceLimits,
) -> Result<Option<CodeBlockBodyDecode>, DecodeError> {
    let mut reader = packet_reader_new(payload, limits)?;
    if !reader.read_bit()? {
        reader.align_to_byte();
        if reader.bytes_consumed() != payload.len() {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::TrailingData,
            ));
        }
        return Ok(None);
    }
    let contribution = match decode_code_block_contribution(
        state,
        inclusion_tree,
        zero_bitplane_tree,
        context,
        &mut reader,
    )? {
        Some(contribution) => contribution,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
    };
    reader.align_to_byte();
    let body_offset = reader.bytes_consumed();
    let body = match payload.get(body_offset..) {
        Some(body) => body,
        None => return Err(packet_reader_error(body_offset, MalformedKind::Truncated)),
    };
    Ok(Some(decode_code_block_contribution_body(
        decoder,
        &contribution,
        body,
        limits,
    )?))
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_styles_equal(left, right),
))]
fn tier1_styles_equal(left: Tier1CodingStyle, right: Tier1CodingStyle) -> bool {
    matches!(
        (left.block_coding, right.block_coding),
        (
            crate::tier1::Tier1BlockCoding::Legacy,
            crate::tier1::Tier1BlockCoding::Legacy
        ) | (
            crate::tier1::Tier1BlockCoding::HighThroughput,
            crate::tier1::Tier1BlockCoding::HighThroughput
        ) | (
            crate::tier1::Tier1BlockCoding::Mixed,
            crate::tier1::Tier1BlockCoding::Mixed
        )
    ) && left.selective_arithmetic_coding_bypass == right.selective_arithmetic_coding_bypass
        && left.reset_contexts == right.reset_contexts
        && left.terminate_all_passes == right.terminate_all_passes
        && left.vertical_causal_context == right.vertical_causal_context
        && left.predictable_termination == right.predictable_termination
        && left.segmentation_symbols == right.segmentation_symbols
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_packet_header_error(),
))]
fn invalid_packet_header() -> DecodeError {
    DecodeError::MalformedInput {
        offset: 0,
        kind: MalformedKind::InvalidPacketHeader,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::ht_reader_error(MalformedKind::ArithmeticOverflow),
))]
fn packet_arithmetic_overflow() -> DecodeError {
    DecodeError::MalformedInput {
        offset: 0,
        kind: MalformedKind::ArithmeticOverflow,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::ht_reader_error(MalformedKind::InvalidCodeBlock),
))]
fn packet_invalid_code_block() -> DecodeError {
    DecodeError::MalformedInput {
        offset: 0,
        kind: MalformedKind::InvalidCodeBlock,
    }
}

impl CodeBlockContribution {
    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == code_block_contribution_view(self).segment_count,
    ))]
    pub const fn segment_count(&self) -> u8 {
        self.segment_count
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_code_block_segment(code_block_contribution_view(self), index),
    ))]
    pub fn segment(&self, index: u8) -> Result<CodeBlockSegmentContribution, DecodeError> {
        if index >= self.segment_count {
            return Err(invalid_packet_header());
        }
        let index = usize::from(index);
        if index >= self.segment_passes.len() || index >= self.segment_lengths.len() {
            return Err(invalid_packet_header());
        }
        Ok(CodeBlockSegmentContribution {
            passes: self.segment_passes[index],
            data_length: self.segment_lengths[index],
        })
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_code_block_body_transaction(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        code_block_contribution_view(contribution).high_throughput ==>
        (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::ht_packet_body(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_work_limit(limits)),
        !code_block_contribution_view(contribution).high_throughput ==>
        (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_legacy_code_block_transaction(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
pub fn decode_code_block_contribution_body(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    limits: &ResourceLimits,
) -> Result<CodeBlockBodyDecode, DecodeError> {
    let mut staged = decoder.clone();
    let decoded =
        decode_code_block_contribution_body_staged(&mut staged, contribution, body, limits)?;
    *decoder = staged;
    Ok(decoded)
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_code_block_body_prepare(
        crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@),
))]
fn prepare_code_block_contribution_body(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
) -> Result<(), DecodeError> {
    let declared_length = match usize::try_from(contribution.data_length) {
        Ok(length) => length,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    if !crate::refinement::exact_consumption(body.len(), declared_length) {
        return Err(packet_invalid_code_block());
    }
    if !decoder.accepts_high_throughput_route(contribution.high_throughput) {
        return Err(packet_invalid_code_block());
    }
    decoder.set_zero_bitplanes(contribution.zero_bitplanes)?;
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_code_block_body_staged(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        code_block_contribution_view(contribution).high_throughput ==>
        (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::ht_packet_body_staged(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_work_limit(limits)),
        !code_block_contribution_view(contribution).high_throughput ==>
        (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_legacy_code_block_staged(
            crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
fn decode_code_block_contribution_body_staged(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    limits: &ResourceLimits,
) -> Result<CodeBlockBodyDecode, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_legacy_code_block_staged); }
    prepare_code_block_contribution_body(decoder, contribution, body)?;
    if contribution.high_throughput {
        return decode_ht_contribution_segments(decoder, contribution, body, limits);
    }
    decode_legacy_code_block_contribution_body(decoder, contribution, body, limits)
}

#[cfg(verus_keep_ghost)]
verus! {
    closed spec fn legacy_packet_progress_view(
        decoder: &Tier1CodeBlockDecoder, segment_index: u8, offset: usize, decoded_passes: u32,
    ) -> crate::specs::Part1LegacyPacketProgress {
        crate::specs::Part1LegacyPacketProgress {
            decoder: crate::tier1::tier1_decoder_state(decoder), segment_index, offset, decoded_passes,
        }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::part1_legacy_code_block_body(
        crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
fn decode_legacy_code_block_contribution_body(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    limits: &ResourceLimits,
) -> Result<CodeBlockBodyDecode, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_legacy_code_block_body); }
    let segment_count = contribution.segment_count();
    let mut segment_index = 0_u8;
    let mut offset = 0_usize;
    let mut decoded_passes = 0_u32;
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial = legacy_packet_progress_view(decoder, 0, 0, 0);
        let ghost goal = crate::specs::part1_legacy_code_block_run(initial, code_block_contribution_view(contribution), body@,
            segment_count as nat, crate::limits::resource_code_block_pass_limit(limits),
            crate::limits::resource_code_block_byte_limit(limits), crate::limits::resource_input_byte_limit(limits),
            crate::limits::resource_work_limit(limits));
    }
    #[cfg_attr(
        verus_keep_ghost,
        verus_spec(
            invariant segment_index <= segment_count,
                segment_count == code_block_contribution_view(contribution).segment_count,
                initial == legacy_packet_progress_view(old(decoder), 0, 0, 0),
                goal == crate::specs::part1_legacy_code_block_run(initial, code_block_contribution_view(contribution), body@,
                    segment_count as nat, crate::limits::resource_code_block_pass_limit(limits),
                    crate::limits::resource_code_block_byte_limit(limits), crate::limits::resource_input_byte_limit(limits),
                    crate::limits::resource_work_limit(limits)),
                goal == crate::specs::part1_legacy_code_block_run(
                    legacy_packet_progress_view(decoder, segment_index, offset, decoded_passes),
                    code_block_contribution_view(contribution), body@, (segment_count - segment_index) as nat,
                    crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
                    crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
            decreases segment_count - segment_index,
        )
    )]
    while segment_index < segment_count {
        #[cfg(verus_keep_ghost)]
        proof! {
            reveal(crate::specs::part1_legacy_code_block_body);
            reveal(crate::specs::part1_legacy_code_block_run);
        }
        decode_legacy_code_block_segment(
            decoder,
            contribution,
            body,
            limits,
            &mut segment_index,
            &mut offset,
            &mut decoded_passes,
        )?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_legacy_code_block_run); }
    if !crate::refinement::exact_consumption(offset, body.len())
        || decoded_passes != u32::from(contribution.new_passes)
    {
        return Err(packet_invalid_code_block());
    }
    Ok(CodeBlockBodyDecode {
        segments: contribution.segment_count(),
        passes: decoded_passes,
        bytes: contribution.data_length,
    })
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::ht_packet_body_segments(
        crate::tier1::tier1_decoder_state(old(decoder)), code_block_contribution_view(contribution), body@,
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_work_limit(limits)),
))]
fn decode_ht_contribution_segments(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    limits: &ResourceLimits,
) -> Result<CodeBlockBodyDecode, DecodeError> {
    let segment_count = contribution.segment_count();
    if segment_count == 0 {
        return Err(packet_invalid_code_block());
    }
    let mut progress = HtBodyProgress {
        segment_index: 0,
        offset: 0,
        decoded_passes: 0,
    };
    run_ht_contribution_segments(decoder, contribution, body, &mut progress, limits)?;
    if !crate::refinement::exact_consumption(progress.offset, body.len())
        || progress.decoded_passes != u32::from(contribution.new_passes)
    {
        return Err(packet_invalid_code_block());
    }
    Ok(CodeBlockBodyDecode {
        segments: segment_count,
        passes: progress.decoded_passes,
        bytes: contribution.data_length,
    })
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder)), ht_body_progress_view(final(progress)))
        == crate::specs::ht_packet_body_run(crate::tier1::tier1_decoder_state(old(decoder)),
            code_block_contribution_view(contribution), body@, ht_body_progress_view(old(progress)),
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_work_limit(limits)),
))]
fn run_ht_contribution_segments(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    progress: &mut HtBodyProgress,
    limits: &ResourceLimits,
) -> Result<(), DecodeError> {
    let segment_count = contribution.segment_count();
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::ht_packet_body_run); }
    #[cfg_attr(
        verus_keep_ghost,
        verus_spec(
            invariant
                segment_count == code_block_contribution_view(contribution).segment_count,
                crate::specs::ht_packet_body_run(crate::tier1::tier1_decoder_state(old(decoder)),
                    code_block_contribution_view(contribution), body@, ht_body_progress_view(old(progress)),
                    crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
                    crate::limits::resource_work_limit(limits))
                    == crate::specs::ht_packet_body_run(crate::tier1::tier1_decoder_state(decoder),
                        code_block_contribution_view(contribution), body@, ht_body_progress_view(progress),
                        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
                        crate::limits::resource_work_limit(limits)),
            decreases segment_count as int - progress.segment_index as int,
        )
    )]
    while progress.segment_index < segment_count {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::ht_packet_body_run); }
        let segment = contribution.segment(progress.segment_index)?;
        decode_ht_segment_body(
            decoder,
            segment,
            body,
            &mut progress.offset,
            &mut progress.decoded_passes,
            limits,
        )?;
        progress.segment_index = progress
            .segment_index
            .checked_add(1)
            .ok_or_else(packet_arithmetic_overflow)?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::ht_packet_body_run); }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verifier::spinoff_prover)]
#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder)), *final(offset), *final(decoded_passes))
        == crate::specs::ht_packet_segment_body(crate::tier1::tier1_decoder_state(old(decoder)), segment, body@,
            *old(offset), *old(decoded_passes), crate::limits::resource_code_block_pass_limit(limits),
            crate::limits::resource_code_block_byte_limit(limits), crate::limits::resource_work_limit(limits)),
))]
fn decode_ht_segment_body(
    decoder: &mut Tier1CodeBlockDecoder,
    segment: CodeBlockSegmentContribution,
    body: &[u8],
    offset: &mut usize,
    decoded_passes: &mut u32,
    limits: &ResourceLimits,
) -> Result<(), DecodeError> {
    if segment.passes == 0 || segment.passes > 2 {
        return Err(packet_invalid_code_block());
    }
    let segment_length =
        usize::try_from(segment.data_length).map_err(|_| packet_arithmetic_overflow())?;
    let end = offset
        .checked_add(segment_length)
        .ok_or_else(packet_arithmetic_overflow)?;
    let segment_body = body
        .get(*offset..end)
        .ok_or_else(packet_invalid_code_block)?;
    decode_ht_segment_route(decoder, segment_body, segment.passes, limits)?;
    *decoded_passes = decoded_passes
        .checked_add(u32::from(segment.passes))
        .ok_or_else(packet_arithmetic_overflow)?;
    *offset = end;
    Ok(())
}

#[cfg(test)]
pub(crate) mod ht_route_test_support {
    use super::*;

    pub(crate) fn segment_body(
        decoder: &mut Tier1CodeBlockDecoder,
        passes: u8,
        data_length: u32,
        body: &[u8],
        offset: &mut usize,
        decoded_passes: &mut u32,
        limits: &ResourceLimits,
    ) -> Result<(), DecodeError> {
        decode_ht_segment_body(
            decoder,
            CodeBlockSegmentContribution {
                passes,
                data_length,
            },
            body,
            offset,
            decoded_passes,
            limits,
        )
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, crate::tier1::tier1_decoder_state(final(decoder))) == crate::specs::ht_packet_segment_route(
        crate::tier1::tier1_decoder_state(old(decoder)), body@, passes,
        crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
        crate::limits::resource_work_limit(limits)),
))]
fn decode_ht_segment_route(
    decoder: &mut Tier1CodeBlockDecoder,
    body: &[u8],
    passes: u8,
    limits: &ResourceLimits,
) -> Result<(), DecodeError> {
    if decoder.next_pass().is_multiple_of(3) {
        if passes != 1 {
            return Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodeBlock,
            });
        }
        if body.is_empty() {
            decoder.skip_high_throughput_segment(1, limits)?;
        } else {
            decoder.decode_high_throughput_segments(body, 1, None, 0, limits)?;
        }
    } else if decoder.ht_current_set_has_cleanup() {
        decoder.decode_high_throughput_refinement(body, passes, limits)?;
    } else {
        if !body.is_empty() {
            return Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodeBlock,
            });
        }
        decoder.skip_high_throughput_segment(passes, limits)?;
    }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, legacy_packet_progress_view(final(decoder), *final(segment_index), *final(offset), *final(decoded_passes)))
        == crate::specs::part1_legacy_code_block_segment(
            legacy_packet_progress_view(old(decoder), *old(segment_index), *old(offset), *old(decoded_passes)),
            code_block_contribution_view(contribution), body@,
            crate::limits::resource_code_block_pass_limit(limits), crate::limits::resource_code_block_byte_limit(limits),
            crate::limits::resource_input_byte_limit(limits), crate::limits::resource_work_limit(limits)),
        result.is_ok() ==> *old(segment_index) < code_block_contribution_view(contribution).segment_count
            && *final(segment_index) as nat == *old(segment_index) as nat + 1,
))]
fn decode_legacy_code_block_segment(
    decoder: &mut Tier1CodeBlockDecoder,
    contribution: &CodeBlockContribution,
    body: &[u8],
    limits: &ResourceLimits,
    segment_index: &mut u8,
    offset: &mut usize,
    decoded_passes: &mut u32,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_legacy_code_block_segment); }
    let segment = contribution.segment(*segment_index)?;
    let segment_length = match usize::try_from(segment.data_length) {
        Ok(length) => length,
        Err(_) => return Err(packet_arithmetic_overflow()),
    };
    let end = offset
        .checked_add(segment_length)
        .ok_or_else(packet_arithmetic_overflow)?;
    if end > body.len() {
        return Err(packet_invalid_code_block());
    }
    decoder.decode_legacy_contribution(&body[*offset..end], segment.passes, limits)?;
    *decoded_passes = decoded_passes
        .checked_add(u32::from(segment.passes))
        .ok_or_else(packet_arithmetic_overflow)?;
    *offset = end;
    *segment_index = segment_index
        .checked_add(1)
        .ok_or_else(packet_arithmetic_overflow)?;
    Ok(())
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct CodeBlockPacketContext {
    pub leaf_x: u32,
    pub leaf_y: u32,
    pub layer: u16,
    pub maximum_zero_bitplanes: u16,
    pub tier1_style: Tier1CodingStyle,
}

struct CodeBlockHeaderSegments {
    segment_passes: [u8; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
    segment_lengths: [u32; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
    segment_count: usize,
    accounted_passes: u32,
    data_length: u32,
    routing: Option<bool>,
}

#[cfg(verus_keep_ghost)]
verus! {
    closed spec fn header_segments_view(segments: &CodeBlockHeaderSegments) -> crate::specs::Part1HeaderSegments {
        crate::specs::Part1HeaderSegments {
            segment_passes: segments.segment_passes@, segment_lengths: segments.segment_lengths@,
            segment_count: segments.segment_count, accounted_passes: segments.accounted_passes,
            data_length: segments.data_length, routing: segments.routing,
        }
    }

    #[verifier::inline]
    spec fn header_segments_outcome(result: Result<CodeBlockHeaderSegments, DecodeError>) -> Result<crate::specs::Part1HeaderSegments, DecodeError> {
        match result { Err(error) => Err(error), Ok(segments) => Ok(header_segments_view(&segments)) }
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures header_segments_view(&result) == crate::specs::part1_header_segments_initial(code_block_packet_state_view(state), style),
))]
fn header_segments_new(
    state: &CodeBlockPacketState,
    style: Tier1CodingStyle,
) -> CodeBlockHeaderSegments {
    let segment_passes = [0_u8; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
    let segment_lengths = [0_u32; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
    let segment_count = 0_usize;
    let accounted_passes = 0_u32;
    let data_length = 0_u32;
    let routing = match state.high_throughput {
        Some(selected) => Some(selected),
        None => match style.block_coding {
            crate::tier1::Tier1BlockCoding::Legacy => Some(false),
            crate::tier1::Tier1BlockCoding::HighThroughput => Some(true),
            crate::tier1::Tier1BlockCoding::Mixed if style.force_high_throughput => Some(true),
            crate::tier1::Tier1BlockCoding::Mixed => None,
        },
    };
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(segment_passes@ =~= Seq::new(164, |i: int| 0u8));
        assert(segment_lengths@ =~= Seq::new(164, |i: int| 0u32));
    }
    CodeBlockHeaderSegments {
        segment_passes,
        segment_lengths,
        segment_count,
        accounted_passes,
        data_length,
        routing,
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, code_block_packet_state_view(final(state)), header_segments_view(final(segments)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_segment_length(code_block_packet_state_view(old(state)), header_segments_view(old(segments)),
            packet_bit_reader_view(old(reader)), first_pass, remaining_passes, passes, length_bits),
        final(segments).segment_count == old(segments).segment_count,
        final(segments).accounted_passes == old(segments).accounted_passes,
        final(segments).data_length == old(segments).data_length,
        final(segments).segment_passes@ == old(segments).segment_passes@,
        final(segments).segment_lengths@ == old(segments).segment_lengths@,
        match result { Ok((actual_passes, _)) => actual_passes == passes || actual_passes == remaining_passes, Err(_) => true },
))]
fn read_header_segment_length(
    state: &mut CodeBlockPacketState,
    segments: &mut CodeBlockHeaderSegments,
    reader: &mut PacketBitReader<'_>,
    first_pass: u32,
    remaining_passes: u32,
    passes: u32,
    length_bits: u8,
) -> Result<(u32, u32), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_header_segment_length); }
    let segment_reader_start = *reader;
    let mut segment_length = reader.read_bits(length_bits)?;
    let mut actual_passes = passes;
    if segments.routing.is_none() {
        let legacy_length_bits = state
            .lblock
            .checked_add(floor_log2(remaining_passes))
            .ok_or_else(packet_arithmetic_overflow)?;
        if legacy_length_bits > 32 {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
        let mut legacy_probe = segment_reader_start;
        let legacy_length = legacy_probe.read_bits(legacy_length_bits)?;
        let leading_zero = segment_length != 0
            && length_bits > 0
            && segment_length < (1_u32 << u32::from(length_bits - 1));
        let selects_legacy = crate::refinement::ht_mixed_selects_legacy(
            segment_length,
            legacy_length,
            first_pass.is_multiple_of(3),
            state.lblock > 3,
            leading_zero,
        );
        if selects_legacy {
            if segments.accounted_passes != 0 {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::InvalidPacketHeader,
                ));
            }
            segments.routing = Some(false);
            state.high_throughput = Some(false);
            *reader = legacy_probe;
            actual_passes = remaining_passes;
            segment_length = legacy_length;
        } else if segment_length != 0 {
            segments.routing = Some(true);
            state.high_throughput = Some(true);
        }
    }
    Ok((actual_passes, segment_length))
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, code_block_packet_state_view(final(state)), tag_tree_view(final(inclusion_tree)),
        tag_tree_view(final(zero_bitplane_tree)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_prefix(code_block_packet_state_view(old(state)), tag_tree_view(old(inclusion_tree)),
            tag_tree_view(old(zero_bitplane_tree)), context, packet_bit_reader_view(old(reader))),
))]
fn read_header_prefix(
    state: &mut CodeBlockPacketState,
    inclusion_tree: &mut TagTree,
    zero_bitplane_tree: &mut TagTree,
    context: CodeBlockPacketContext,
    reader: &mut PacketBitReader<'_>,
) -> Result<bool, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! {
        reveal(crate::specs::part1_header_prefix);
    }
    if context.maximum_zero_bitplanes == 0
        || context.maximum_zero_bitplanes > crate::tier1::MAX_TIER1_BITPLANES
    {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let first_inclusion = !state.included;
    let included = if first_inclusion {
        let threshold = match u32::from(context.layer).checked_add(1) {
            Some(value) => value,
            None => {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
        inclusion_tree
            .decode(context.leaf_x, context.leaf_y, threshold, reader)?
            .is_below_threshold
    } else {
        reader.read_bit()?
    };
    if !included {
        return Ok(false);
    }

    if first_inclusion {
        state.included = crate::refinement::packet_next_included(state.included, true);
        read_header_zero_bitplanes(state, zero_bitplane_tree, context, reader)?;
    }
    Ok(true)
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (code_block_header_outcome(result), code_block_packet_state_view(final(state)), tag_tree_view(final(inclusion_tree)),
        tag_tree_view(final(zero_bitplane_tree)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_packet_header_decode(code_block_packet_state_view(old(state)), tag_tree_view(old(inclusion_tree)),
            tag_tree_view(old(zero_bitplane_tree)), context, packet_bit_reader_view(old(reader))),
        result.is_err() ==> code_block_packet_state_view(final(state)) == code_block_packet_state_view(old(state)),
))]
pub fn decode_code_block_contribution(
    state: &mut CodeBlockPacketState,
    inclusion_tree: &mut TagTree,
    zero_bitplane_tree: &mut TagTree,
    context: CodeBlockPacketContext,
    reader: &mut PacketBitReader<'_>,
) -> Result<Option<CodeBlockContribution>, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_packet_header_decode); }
    let mut next_state = *state;
    let first_inclusion = !next_state.included;
    if !read_header_prefix(
        &mut next_state,
        inclusion_tree,
        zero_bitplane_tree,
        context,
        reader,
    )? {
        return Ok(None);
    }
    let new_passes = read_new_passes(reader)?;
    read_header_lblock(&mut next_state, reader)?;
    let segments = read_header_segments(&mut next_state, new_passes, context, reader)?;
    commit_header_contribution(
        state,
        next_state,
        segments,
        first_inclusion,
        new_passes,
        reader,
    )
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (header_segments_outcome(result), code_block_packet_state_view(final(state)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_segments(code_block_packet_state_view(old(state)), packet_bit_reader_view(old(reader)), new_passes, context),
        match result { Ok(segments) => segments.segment_count <= 164, Err(_) => true },
))]
fn read_header_segments(
    state: &mut CodeBlockPacketState,
    new_passes: u8,
    context: CodeBlockPacketContext,
    reader: &mut PacketBitReader<'_>,
) -> Result<CodeBlockHeaderSegments, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_header_segments); }
    let mut segments = header_segments_new(state, context.tier1_style);
    let target_passes = u32::from(new_passes);
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost initial_state = code_block_packet_state_view(state);
        let ghost initial_reader = packet_bit_reader_view(reader);
        let ghost initial_segments = header_segments_view(&segments);
        let ghost goal = crate::specs::part1_header_segments_run(initial_state, initial_segments, initial_reader, new_passes, context, 165);
    }
    #[cfg_attr(
        verus_keep_ghost,
        verus_spec(
            invariant segments.accounted_passes <= target_passes,
                target_passes == new_passes as u32,
                segments.segment_count <= 164,
                initial_state == code_block_packet_state_view(old(state)), initial_reader == packet_bit_reader_view(old(reader)),
                initial_segments == crate::specs::part1_header_segments_initial(initial_state, context.tier1_style),
                goal == crate::specs::part1_header_segments_run(initial_state, initial_segments, initial_reader, new_passes, context, 165),
                goal == crate::specs::part1_header_segments_run(code_block_packet_state_view(state), header_segments_view(&segments),
                    packet_bit_reader_view(reader), new_passes, context, (165 - segments.segment_count) as nat),
            decreases target_passes - segments.accounted_passes,
        )
    )]
    while segments.accounted_passes < target_passes {
        #[cfg(verus_keep_ghost)]
        proof! {
            reveal(crate::specs::part1_header_segments);
            reveal(crate::specs::part1_header_segments_run);
        }
        read_header_segment(state, &mut segments, new_passes, context, reader)?;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_header_segments_run); }
    Ok(segments)
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, code_block_packet_state_view(final(state)), header_segments_view(final(segments)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_segment_step(code_block_packet_state_view(old(state)), header_segments_view(old(segments)),
            packet_bit_reader_view(old(reader)), new_passes, context),
        result.is_ok() ==> final(segments).segment_count == old(segments).segment_count + 1
            && old(segments).segment_count < 164
            && final(segments).accounted_passes > old(segments).accounted_passes
            && final(segments).accounted_passes <= new_passes as u32,
))]
fn read_header_segment(
    state: &mut CodeBlockPacketState,
    segments: &mut CodeBlockHeaderSegments,
    new_passes: u8,
    context: CodeBlockPacketContext,
    reader: &mut PacketBitReader<'_>,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_header_segment_step); }
    if segments.segment_count >= segments.segment_passes.len()
        || segments.segment_count >= segments.segment_lengths.len()
    {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let first_pass = match state.total_passes.checked_add(segments.accounted_passes) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    let remaining_passes = match u32::from(new_passes).checked_sub(segments.accounted_passes) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    let parse_as_ht = segments.routing != Some(false);
    let passes = if parse_as_ht {
        crate::refinement::ht_segment_passes(first_pass % 3, remaining_passes)
    } else {
        context
            .tier1_style
            .segment_passes(first_pass, remaining_passes)
    };
    if passes == 0 || passes > remaining_passes || passes > u32::from(u8::MAX) {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let pass_length_bits = floor_log2(passes);
    let length_bits = match state.lblock.checked_add(pass_length_bits) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    if length_bits > 32 {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let (actual_passes, segment_length) = read_header_segment_length(
        state,
        segments,
        reader,
        first_pass,
        remaining_passes,
        passes,
        length_bits,
    )?;
    // A later layer can finish a buffered entropy segment without adding bytes.
    if segment_length == 0 && segments.routing == Some(false) && first_pass == 0 {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    segments.segment_passes[segments.segment_count] = match u8::try_from(actual_passes) {
        Ok(value) => value,
        Err(_) => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    segments.segment_lengths[segments.segment_count] = segment_length;
    segments.data_length = match segments.data_length.checked_add(segment_length) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    segments.accounted_passes = match segments.accounted_passes.checked_add(actual_passes) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    segments.segment_count = match segments.segment_count.checked_add(1) {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::ArithmeticOverflow,
            ));
        }
    };
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (code_block_header_outcome(result), code_block_packet_state_view(final(state))) == crate::specs::part1_header_commit(
        code_block_packet_state_view(old(state)), code_block_packet_state_view(&next_state), header_segments_view(&segments),
        first_inclusion, new_passes, packet_bit_reader_view(reader)),
))]
fn commit_header_contribution(
    state: &mut CodeBlockPacketState,
    mut next_state: CodeBlockPacketState,
    segments: CodeBlockHeaderSegments,
    first_inclusion: bool,
    new_passes: u8,
    reader: &PacketBitReader<'_>,
) -> Result<Option<CodeBlockContribution>, DecodeError> {
    let CodeBlockHeaderSegments {
        segment_passes,
        segment_lengths,
        segment_count,
        data_length,
        routing,
        ..
    } = segments;
    let added_passes = u32::from(new_passes);
    if next_state.total_passes > u32::MAX - added_passes {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::ArithmeticOverflow,
        ));
    }
    next_state.total_passes =
        crate::refinement::packet_next_passes(next_state.total_passes, added_passes);
    if next_state.total_passes > crate::tier1::MAX_TIER1_PASSES {
        return Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        ));
    }
    let zero_bitplanes = match next_state.zero_bitplanes {
        Some(value) => value,
        None => {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
    };
    next_state.high_throughput = routing;
    *state = next_state;
    Ok(Some(CodeBlockContribution {
        first_inclusion,
        zero_bitplanes,
        new_passes,
        data_length,
        high_throughput: routing != Some(false),
        segment_count: match u8::try_from(segment_count) {
            Ok(value) => value,
            Err(_) => {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        },
        segment_passes,
        segment_lengths,
    }))
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, code_block_packet_state_view(final(state)), tag_tree_view(final(tree)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_zero_loop(code_block_packet_state_view(old(state)), tag_tree_view(old(tree)), context,
            packet_bit_reader_view(old(reader)), 1),
))]
fn read_header_zero_bitplanes(
    state: &mut CodeBlockPacketState,
    tree: &mut TagTree,
    context: CodeBlockPacketContext,
    reader: &mut PacketBitReader<'_>,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost original_state = code_block_packet_state_view(state);
        let ghost original_tree = tag_tree_view(tree);
        let ghost original_reader = packet_bit_reader_view(reader);
    }
    let maximum_zero_bitplanes = u32::from(context.maximum_zero_bitplanes);
    let mut threshold = 1_u32;
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant threshold >= 1,
            maximum_zero_bitplanes == context.maximum_zero_bitplanes as u32,
            original_state == code_block_packet_state_view(old(state)),
            original_tree == tag_tree_view(old(tree)), original_reader == packet_bit_reader_view(old(reader)),
            crate::specs::part1_header_zero_loop(original_state, original_tree, context, original_reader, 1)
                == crate::specs::part1_header_zero_loop(code_block_packet_state_view(state), tag_tree_view(tree), context,
                    packet_bit_reader_view(reader), threshold),
        decreases maximum_zero_bitplanes as int - threshold as int,
    ))]
    loop {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_header_zero_loop); }
        let decoded = tree.decode(context.leaf_x, context.leaf_y, threshold, reader)?;
        if decoded.is_below_threshold {
            let value = match decoded.value {
                Some(value) => value,
                None => {
                    return Err(packet_reader_error(
                        reader.bytes_consumed(),
                        MalformedKind::InvalidTagTree,
                    ));
                }
            };
            let zero_bitplanes = match u16::try_from(value) {
                Ok(value) => value,
                Err(_) => {
                    return Err(packet_reader_error(
                        reader.bytes_consumed(),
                        MalformedKind::InvalidPacketHeader,
                    ));
                }
            };
            if zero_bitplanes >= context.maximum_zero_bitplanes {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::InvalidPacketHeader,
                ));
            }
            state.zero_bitplanes = Some(zero_bitplanes);
            return Ok(());
        }
        if threshold >= maximum_zero_bitplanes {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
        threshold = match threshold.checked_add(1) {
            Some(value) => value,
            None => {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::ArithmeticOverflow,
                ));
            }
        };
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, packet_bit_reader_view(final(reader))) == crate::specs::part1_header_new_passes(packet_bit_reader_view(old(reader))),
))]
fn read_new_passes(reader: &mut PacketBitReader<'_>) -> Result<u8, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_header_new_passes); }
    if !reader.read_bit()? {
        return Ok(1);
    }
    if !reader.read_bit()? {
        return Ok(2);
    }
    let suffix = reader.read_bits(2)?;
    match suffix {
        0 => Ok(3),
        1 => Ok(4),
        2 => Ok(5),
        3 => {
            let extension = reader.read_bits(5)?;
            let passes = if extension == 31 {
                reader.read_bits(7)?.checked_add(37)
            } else {
                extension.checked_add(6)
            };
            let passes = match passes {
                Some(value) => value,
                None => {
                    return Err(packet_reader_error(
                        reader.bytes_consumed(),
                        MalformedKind::ArithmeticOverflow,
                    ));
                }
            };
            match u8::try_from(passes) {
                Ok(value) => Ok(value),
                Err(_) => Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::ArithmeticOverflow,
                )),
            }
        }
        _ => Err(packet_reader_error(
            reader.bytes_consumed(),
            MalformedKind::InvalidPacketHeader,
        )),
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, code_block_packet_state_view(final(state)), packet_bit_reader_view(final(reader)))
        == crate::specs::part1_header_lblock(code_block_packet_state_view(old(state)), packet_bit_reader_view(old(reader)), 32),
))]
fn read_header_lblock(
    state: &mut CodeBlockPacketState,
    reader: &mut PacketBitReader<'_>,
) -> Result<(), DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! {
        let ghost original = code_block_packet_state_view(state);
        let ghost start_reader = packet_bit_reader_view(reader);
    }
    let mut remaining_lblock_increments = 32_u8;
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant remaining_lblock_increments <= 32,
            original == code_block_packet_state_view(old(state)), start_reader == packet_bit_reader_view(old(reader)),
            crate::specs::part1_header_lblock(original, start_reader, 32)
                == crate::specs::part1_header_lblock(code_block_packet_state_view(state), packet_bit_reader_view(reader), remaining_lblock_increments as nat),
        decreases remaining_lblock_increments,
    ))]
    while reader.read_bit()? {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_header_lblock); }
        if remaining_lblock_increments == 0 {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
        remaining_lblock_increments -= 1;
        if state.lblock >= 31 {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
        state.lblock = crate::refinement::packet_next_lblock(state.lblock);
        if state.lblock > 31 {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidPacketHeader,
            ));
        }
    }
    Ok(())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == crate::specs::part1_header_floor_log2(value),
))]
fn floor_log2(value: u32) -> u8 {
    #[cfg(verus_keep_ghost)]
    proof! { vstd::std_specs::bits::axiom_u32_leading_zeros(value); }
    if value != 0 {
        (31 - value.leading_zeros()) as u8
    } else {
        0
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
struct TagTreeNode {
    low: u32,
    value: u32,
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
struct TagTreeLevel {
    offset: usize,
    width: u32,
    height: u32,
}

#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct TagTree {
    levels: Vec<TagTreeLevel>,
    nodes: Vec<TagTreeNode>,
}

#[derive(Clone, Copy)]
struct TagTreePath {
    nodes: [usize; 64],
    length: usize,
}

#[cfg(verus_keep_ghost)]
verus! {
    closed spec fn tag_node_view(node: TagTreeNode) -> crate::specs::Part1TagNode {
        crate::specs::Part1TagNode { low: node.low, value: node.value }
    }

    closed spec fn tag_level_view(level: TagTreeLevel) -> crate::specs::Part1TagLevel {
        crate::specs::Part1TagLevel { offset: level.offset, width: level.width, height: level.height }
    }

    pub closed spec fn tag_tree_view(tree: &TagTree) -> crate::specs::Part1TagTree {
        crate::specs::Part1TagTree {
            levels: tree.levels@.map_values(|level: TagTreeLevel| tag_level_view(level)),
            nodes: tree.nodes@.map_values(|node: TagTreeNode| tag_node_view(node)),
        }
    }

    pub open spec fn tag_tree_outcome(result: Result<TagTree, DecodeError>) -> Result<crate::specs::Part1TagTree, DecodeError> {
        match result { Err(error) => Err(error), Ok(tree) => Ok(tag_tree_view(&tree)) }
    }

    closed spec fn tag_path_view(path: TagTreePath) -> crate::specs::Part1TagPath {
        crate::specs::Part1TagPath { nodes: path.nodes@, length: path.length }
    }

    #[verifier::inline]
    spec fn tag_path_outcome(result: Result<TagTreePath, DecodeError>) -> Result<crate::specs::Part1TagPath, DecodeError> {
        match result { Err(error) => Err(error), Ok(path) => Ok(tag_path_view(path)) }
    }
}

impl Clone for TagTree {
    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures tag_tree_view(&result) == tag_tree_view(self),
    ))]
    fn clone(&self) -> Self {
        Self {
            levels: self.levels.clone(),
            nodes: self.nodes.clone(),
        }
    }
}

#[derive(Clone, Copy)]
#[cfg_attr(not(verus_keep_ghost), derive(Debug, Eq, PartialEq))]
pub struct TagTreeValue {
    pub value: Option<u32>,
    pub is_below_threshold: bool,
}

impl TagTree {
    pub fn new(width: u32, height: u32, limits: &ResourceLimits) -> Result<Self, DecodeError> {
        tag_tree_new(width, height, limits)
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures result == crate::specs::part1_tag_leaf_count(tag_tree_view(self)),
    ))]
    pub fn leaf_count(&self) -> Result<u64, DecodeError> {
        let level = match self.levels.first() {
            Some(level) => level,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTagTree)),
        };
        match u64::from(level.width).checked_mul(u64::from(level.height)) {
            Some(count) => Ok(count),
            None => Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
        }
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result => ensures result == tag_tree_view(self).nodes.len(),))]
    pub const fn node_count(&self) -> usize {
        self.nodes.len()
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures tag_path_outcome(result) == crate::specs::part1_tag_path(tag_tree_view(self), leaf_x, leaf_y, error_offset),
    ))]
    fn decode_path(
        &self,
        leaf_x: u32,
        leaf_y: u32,
        error_offset: usize,
    ) -> Result<TagTreePath, DecodeError> {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_path); }
        let leaf_level = match self.levels.first() {
            Some(level) => level,
            None => return Err(packet_reader_error(0, MalformedKind::InvalidTagTree)),
        };
        if leaf_x >= leaf_level.width || leaf_y >= leaf_level.height {
            return Err(packet_reader_error(
                error_offset,
                MalformedKind::InvalidTagTree,
            ));
        }

        let mut path = [0_usize; 64];
        let mut path_length = 0_usize;
        let mut x = leaf_x;
        let mut y = leaf_y;
        let mut level_index = 0_usize;
        #[cfg(verus_keep_ghost)]
        proof! { assert(path@ =~= Seq::new(64, |i: int| 0usize)); }
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost goal = crate::specs::part1_tag_path(tag_tree_view(self), leaf_x, leaf_y, error_offset);
        }
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant level_index <= self.levels.len(),
                    path_length <= 64,
                    goal == crate::specs::part1_tag_path(tag_tree_view(self), leaf_x, leaf_y, error_offset),
                    goal == crate::specs::part1_tag_path_walk(tag_tree_view(self),
                        crate::specs::Part1TagPath { nodes: path@, length: path_length }, x, y, level_index as nat, error_offset),
                decreases self.levels.len() - level_index,
            )
        )]
        while level_index < self.levels.len() {
            #[cfg(verus_keep_ghost)]
            proof! {
                reveal(crate::specs::part1_tag_path);
                reveal(crate::specs::part1_tag_path_walk);
            }
            if path_length >= path.len() {
                return Err(packet_reader_error(
                    error_offset,
                    MalformedKind::InvalidTagTree,
                ));
            }
            let level = self.levels[level_index];
            if x >= level.width || y >= level.height {
                return Err(packet_reader_error(
                    error_offset,
                    MalformedKind::InvalidTagTree,
                ));
            }
            let physical_y = match usize::try_from(y) {
                Ok(value) => value,
                Err(_) => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            let physical_width = match usize::try_from(level.width) {
                Ok(value) => value,
                Err(_) => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            let row = match physical_y.checked_mul(physical_width) {
                Some(value) => value,
                None => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            let physical_x = match usize::try_from(x) {
                Ok(value) => value,
                Err(_) => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            let relative = match row.checked_add(physical_x) {
                Some(value) => value,
                None => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            let node_index = match level.offset.checked_add(relative) {
                Some(value) => value,
                None => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
            };
            if node_index >= self.nodes.len() {
                return Err(packet_reader_error(
                    error_offset,
                    MalformedKind::InvalidTagTree,
                ));
            }
            path[path_length] = node_index;
            path_length = path_length
                .checked_add(1)
                .ok_or_else(|| packet_reader_error(0, MalformedKind::ArithmeticOverflow))?;
            x /= 2;
            y /= 2;
            level_index = level_index
                .checked_add(1)
                .ok_or_else(|| packet_reader_error(0, MalformedKind::ArithmeticOverflow))?;
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_path_walk); }
        Ok(TagTreePath {
            nodes: path,
            length: path_length,
        })
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, tag_tree_view(final(self)), packet_bit_reader_view(final(reader)))
            == crate::specs::part1_tag_reverse(tag_tree_view(old(self)), tag_path_view(path), path.length as nat,
                0, threshold, packet_bit_reader_view(old(reader))),
    ))]
    fn decode_path_nodes(
        &mut self,
        path: TagTreePath,
        threshold: u32,
        reader: &mut PacketBitReader<'_>,
    ) -> Result<TagTreeValue, DecodeError> {
        let mut inherited_low = 0_u32;
        let mut reverse_index = path.length;
        #[cfg(verus_keep_ghost)]
        proof_decl! {
            let ghost initial_tree = tag_tree_view(self);
            let ghost initial_reader = packet_bit_reader_view(reader);
            let ghost goal = crate::specs::part1_tag_reverse(initial_tree, tag_path_view(path), path.length as nat, 0, threshold, initial_reader);
        }
        #[cfg_attr(
            verus_keep_ghost,
            verus_spec(
                invariant reverse_index <= path.length,
                    initial_tree == tag_tree_view(old(self)), initial_reader == packet_bit_reader_view(old(reader)),
                    goal == crate::specs::part1_tag_reverse(initial_tree, tag_path_view(path), path.length as nat, 0, threshold, initial_reader),
                    goal == crate::specs::part1_tag_reverse(tag_tree_view(self), tag_path_view(path), reverse_index as nat,
                        inherited_low, threshold, packet_bit_reader_view(reader)),
                decreases reverse_index,
            )
        )]
        while reverse_index > 0 {
            #[cfg(verus_keep_ghost)]
            proof! { reveal(crate::specs::part1_tag_reverse); }
            reverse_index = reverse_index
                .checked_sub(1)
                .ok_or_else(|| packet_reader_error(0, MalformedKind::ArithmeticOverflow))?;
            if reverse_index >= path.nodes.len() {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::InvalidTagTree,
                ));
            }
            let node_index = path.nodes[reverse_index];
            if node_index >= self.nodes.len() {
                return Err(packet_reader_error(
                    reader.bytes_consumed(),
                    MalformedKind::InvalidTagTree,
                ));
            }
            #[cfg(verus_keep_ghost)]
            proof_decl! { let ghost before = tag_tree_view(self); }
            let decoded = decode_tag_tree_node(
                &mut self.nodes[node_index],
                inherited_low,
                threshold,
                reader,
            );
            #[cfg(verus_keep_ghost)]
            proof! {
                assert(tag_tree_view(self).nodes =~= before.nodes.update(node_index as int, tag_node_view(self.nodes[node_index as int])));
            }
            match decoded? {
                None => {
                    return Ok(TagTreeValue {
                        value: None,
                        is_below_threshold: false,
                    });
                }
                Some(value) => inherited_low = value,
            }
        }
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_reverse); }
        let leaf_index = path.nodes[0];
        if leaf_index >= self.nodes.len() {
            return Err(packet_reader_error(
                reader.bytes_consumed(),
                MalformedKind::InvalidTagTree,
            ));
        }
        let value = self.nodes[leaf_index].value;
        Ok(TagTreeValue {
            value: if value == u32::MAX { None } else { Some(value) },
            is_below_threshold: value < threshold,
        })
    }

    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures (result, tag_tree_view(final(self)), packet_bit_reader_view(final(reader)))
            == crate::specs::part1_tag_tree_decode(tag_tree_view(old(self)), leaf_x, leaf_y, threshold, packet_bit_reader_view(old(reader))),
    ))]
    pub fn decode(
        &mut self,
        leaf_x: u32,
        leaf_y: u32,
        threshold: u32,
        reader: &mut PacketBitReader<'_>,
    ) -> Result<TagTreeValue, DecodeError> {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_tree_decode); }
        let path = self.decode_path(leaf_x, leaf_y, reader.bytes_consumed())?;
        self.decode_path_nodes(path, threshold, reader)
    }
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures (result, tag_node_view(*final(node)), packet_bit_reader_view(final(reader))) ==
        crate::specs::part1_tag_node_decode(tag_node_view(*old(node)), inherited, threshold, packet_bit_reader_view(old(reader))),
))]
fn decode_tag_tree_node(
    node: &mut TagTreeNode,
    inherited: u32,
    threshold: u32,
    reader: &mut PacketBitReader<'_>,
) -> Result<Option<u32>, DecodeError> {
    #[cfg(verus_keep_ghost)]
    proof_decl! { let ghost goal = crate::specs::part1_tag_node_decode(tag_node_view(*node), inherited, threshold, packet_bit_reader_view(reader)); }
    node.low = crate::refinement::tag_inherited_low(node.low, inherited);
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant goal == crate::specs::part1_tag_node_decode(tag_node_view(*old(node)), inherited, threshold, packet_bit_reader_view(old(reader))),
            goal == crate::specs::part1_tag_node_loop(tag_node_view(*node), threshold, packet_bit_reader_view(reader)),
        decreases threshold as int - node.low as int, node.value as int - node.low as int,
    ))]
    while node.low < threshold && node.low < node.value {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_node_loop); }
        let bit = reader.read_bit()?;
        let next_value = crate::refinement::tag_step_value(node.low, node.value, bit);
        let next_low = if bit {
            node.low
        } else {
            crate::refinement::tag_step_low(node.low, false)
        };
        node.value = next_value;
        node.low = next_low;
    }
    #[cfg(verus_keep_ghost)]
    proof! { reveal(crate::specs::part1_tag_node_loop); }
    Ok(if node.value >= threshold {
        None
    } else {
        Some(node.value)
    })
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures tag_tree_outcome(result) == crate::specs::part1_tag_initial(
        width, height, crate::limits::resource_tag_tree_node_limit(limits)),
))]
pub(crate) fn tag_tree_new(
    width: u32,
    height: u32,
    limits: &ResourceLimits,
) -> Result<TagTree, DecodeError> {
    tag_tree_from_dimensions(width, height, limits.maximum_tag_tree_nodes())
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures tag_tree_outcome(result) == crate::specs::part1_tag_initial(width, height, maximum_nodes),
))]
pub(crate) fn tag_tree_from_dimensions(
    width: u32,
    height: u32,
    maximum_nodes: u64,
) -> Result<TagTree, DecodeError> {
    if width == 0 || height == 0 {
        return Err(packet_reader_error(0, MalformedKind::InvalidTagTree));
    }
    let mut levels = Vec::new();
    let mut total_nodes = 0_usize;
    let mut level_width = width;
    let mut level_height = height;
    let mut remaining_levels = 64_usize;
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(levels@.map_values(|level: TagTreeLevel| tag_level_view(level)) =~= Seq::<crate::specs::Part1TagLevel>::empty());
    }
    #[cfg_attr(verus_keep_ghost, verus_spec(
        invariant remaining_levels <= 64, width != 0, height != 0,
        invariant_except_break
            crate::specs::part1_tag_build(width, height, crate::specs::Part1TagBuild { levels: Seq::empty(), total: 0 }, 64, maximum_nodes)
                == crate::specs::part1_tag_build(level_width, level_height,
                    crate::specs::Part1TagBuild { levels: levels@.map_values(|level: TagTreeLevel| tag_level_view(level)), total: total_nodes },
                    remaining_levels as nat, maximum_nodes),
        ensures crate::specs::part1_tag_build(width, height, crate::specs::Part1TagBuild { levels: Seq::empty(), total: 0 }, 64, maximum_nodes)
            == Ok(crate::specs::Part1TagBuild {
                levels: levels@.map_values(|level: TagTreeLevel| tag_level_view(level)), total: total_nodes
            }),
        decreases remaining_levels,
    ))]
    loop {
        #[cfg(verus_keep_ghost)]
        proof! { reveal(crate::specs::part1_tag_build); }
        if remaining_levels == 0 {
            return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow));
        }
        remaining_levels -= 1;
        let level_nodes = match u64::from(level_width).checked_mul(u64::from(level_height)) {
            Some(count) => count,
            None => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
        };
        let next_total = match (total_nodes as u64).checked_add(level_nodes) {
            Some(count) => count,
            None => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
        };
        if next_total > maximum_nodes {
            return Err(packet_reader_limit(
                Resource::TagTreeNodes,
                maximum_nodes,
                next_total,
            ));
        }
        #[cfg(verus_keep_ghost)]
        proof_decl! { let ghost previous_levels = levels@.map_values(|level: TagTreeLevel| tag_level_view(level)); }
        levels.push(TagTreeLevel {
            offset: total_nodes,
            width: level_width,
            height: level_height,
        });
        #[cfg(verus_keep_ghost)]
        proof! {
            assert(levels@.map_values(|level: TagTreeLevel| tag_level_view(level)) =~= previous_levels.push(
                crate::specs::Part1TagLevel { offset: total_nodes, width: level_width, height: level_height }));
        }
        total_nodes = match usize::try_from(next_total) {
            Ok(total) => total,
            Err(_) => return Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow)),
        };
        if level_width == 1 && level_height == 1 {
            break;
        }
        level_width = ceil_div_two(level_width);
        level_height = ceil_div_two(level_height);
    }
    let nodes = vec![
        TagTreeNode {
            low: 0,
            value: u32::MAX
        };
        total_nodes
    ];
    #[cfg(verus_keep_ghost)]
    proof! {
        assert(nodes@.map_values(|node: TagTreeNode| tag_node_view(node)) =~=
            Seq::new(total_nodes as nat, |i: int| crate::specs::Part1TagNode { low: 0, value: u32::MAX }));
    }
    Ok(TagTree { levels, nodes })
}

#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == (value as nat / 2 + value as nat % 2) as u32,
))]
const fn ceil_div_two(value: u32) -> u32 {
    value / 2 + value % 2
}

#[cfg(test)]
pub(crate) fn exact_packet_precinct_snapshot(value: &PacketPrecinctDecoder) -> String {
    let subbands = value
        .subbands
        .iter()
        .map(|s| {
            (
                s.orientation,
                s.first_decoder,
                s.decoder_count,
                s.code_blocks_across,
                s.code_blocks_down,
                &s.inclusion_tree,
                &s.zero_bitplane_tree,
            )
        })
        .collect::<Vec<_>>();
    format!(
        "{:?}",
        (
            value.component,
            value.resolution,
            value.precinct,
            &value.states,
            &value.contexts,
            &value.decoders,
            subbands
        )
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn precinct_context_preparation_preserves_raw_prefixes_and_exact_leaf_metadata() {
        let style = Tier1CodingStyle {
            force_high_throughput: true,
            ..Tier1CodingStyle::default()
        };
        let mut cases = 0;
        for states_len in [0, 1, 3] {
            for contexts_len in [0, 1, 4] {
                for count in [0, 1, 2, 3, 7, 32] {
                    for across in [0, 1, 2, 3, u32::MAX] {
                        for maximum_zero in [0, 1, u16::MAX] {
                            let state = CodeBlockPacketState {
                                included: true,
                                zero_bitplanes: Some(u16::MAX),
                                lblock: u8::MAX,
                                total_passes: u32::MAX,
                                high_throughput: Some(true),
                            };
                            let context = CodeBlockPacketContext {
                                leaf_x: u32::MAX,
                                leaf_y: u32::MAX,
                                layer: u16::MAX,
                                maximum_zero_bitplanes: u16::MAX,
                                tier1_style: style,
                            };
                            let states = vec![state; states_len];
                            let contexts = vec![context; contexts_len];
                            let expected = if count != 0 && across == 0 {
                                Err(DecodeError::MalformedInput {
                                    offset: 0,
                                    kind: MalformedKind::ArithmeticOverflow,
                                })
                            } else {
                                let mut expected_states = states.clone();
                                let mut expected_contexts = contexts.clone();
                                for index in 0..count {
                                    expected_states.push(CodeBlockPacketState {
                                        included: false,
                                        zero_bitplanes: None,
                                        lblock: 3,
                                        total_passes: 0,
                                        high_throughput: None,
                                    });
                                    expected_contexts.push(CodeBlockPacketContext {
                                        leaf_x: u32::try_from(index).unwrap() % across,
                                        leaf_y: u32::try_from(index).unwrap() / across,
                                        layer: 0,
                                        maximum_zero_bitplanes: maximum_zero,
                                        tier1_style: style,
                                    });
                                }
                                Ok((expected_states, expected_contexts))
                            };
                            assert_eq!(
                                prepare_precinct_contexts(
                                    states,
                                    contexts,
                                    count,
                                    across,
                                    maximum_zero,
                                    style
                                ),
                                expected
                            );
                            cases += 1;
                        }
                    }
                }
            }
        }
        assert_eq!(cases, 810);
    }

    fn precinct_execution_fixture(
        rows: usize,
        across: u32,
        down: u32,
        maximum_zero: u16,
        count: usize,
    ) -> Vec<PacketSubbandExecution> {
        (0..rows)
            .map(|row| {
                let last = row + 1 == rows;
                PacketSubbandExecution {
                    orientation: [
                        SubbandOrientation::Hh,
                        SubbandOrientation::Ll,
                        SubbandOrientation::Hl,
                    ][row % 3],
                    code_blocks_across: if last { across } else { 1 },
                    code_blocks_down: if last { down } else { 1 },
                    maximum_zero_bitplanes: if last { maximum_zero } else { 8 },
                    decoders: (0..if last { count } else { 1 })
                        .map(|index| {
                            let mut decoder = Tier1CodeBlockDecoder::new(
                                1,
                                1,
                                8,
                                SubbandOrientation::Lh,
                                Tier1CodingStyle::default(),
                            )
                            .unwrap();
                            decoder.set_multiple_ht_sets_allowed(index % 2 != 0);
                            decoder
                                .set_ht_magnitude_bound(u8::try_from(index % 74 + 1).unwrap())
                                .unwrap();
                            decoder
                        })
                        .collect(),
                }
            })
            .collect()
    }

    fn reference_precinct_initialization(
        coordinate: (u16, u8, u32),
        style: Tier1CodingStyle,
        executions: Vec<PacketSubbandExecution>,
        limits: &ResourceLimits,
    ) -> Result<PacketPrecinctDecoder, DecodeError> {
        let invalid = DecodeError::MalformedInput {
            offset: 0,
            kind: MalformedKind::InvalidPacketHeader,
        };
        let arithmetic = DecodeError::MalformedInput {
            offset: 0,
            kind: MalformedKind::ArithmeticOverflow,
        };
        if executions.len() > 3 {
            return Err(invalid);
        }
        let mut states = Vec::new();
        let mut contexts = Vec::new();
        let mut decoders = Vec::new();
        let mut subbands = Vec::new();
        let mut total = 0_u64;
        for execution in executions {
            if execution.code_blocks_across == 0
                || execution.code_blocks_down == 0
                || execution.maximum_zero_bitplanes == 0
                || execution.maximum_zero_bitplanes > crate::tier1::MAX_TIER1_BITPLANES
            {
                return Err(invalid);
            }
            let count =
                u128::from(execution.code_blocks_across) * u128::from(execution.code_blocks_down);
            total = u64::try_from(u128::from(total) + count).map_err(|_| arithmetic)?;
            for (resource, limit) in [
                (Resource::CodeBlocks, limits.maximum_code_blocks()),
                (Resource::WorkUnits, limits.maximum_work_units()),
            ] {
                if total > limit {
                    return Err(DecodeError::LimitExceeded {
                        resource,
                        limit,
                        actual: total,
                    });
                }
            }
            let count = usize::try_from(count).map_err(|_| arithmetic)?;
            if count != execution.decoders.len() {
                return Err(invalid);
            }
            let first_decoder = decoders.len();
            for index in 0..count {
                let index = u32::try_from(index).map_err(|_| arithmetic)?;
                states.push(CodeBlockPacketState {
                    included: false,
                    zero_bitplanes: None,
                    lblock: 3,
                    total_passes: 0,
                    high_throughput: None,
                });
                contexts.push(CodeBlockPacketContext {
                    leaf_x: index % execution.code_blocks_across,
                    leaf_y: index / execution.code_blocks_across,
                    layer: 0,
                    maximum_zero_bitplanes: execution.maximum_zero_bitplanes,
                    tier1_style: style,
                });
            }
            decoders.extend(execution.decoders);
            subbands.push(PacketSubbandState {
                orientation: execution.orientation,
                first_decoder,
                decoder_count: count,
                code_blocks_across: execution.code_blocks_across,
                code_blocks_down: execution.code_blocks_down,
                inclusion_tree: TagTree::new(
                    execution.code_blocks_across,
                    execution.code_blocks_down,
                    limits,
                )?,
                zero_bitplane_tree: TagTree::new(
                    execution.code_blocks_across,
                    execution.code_blocks_down,
                    limits,
                )?,
            });
        }
        Ok(PacketPrecinctDecoder {
            component: coordinate.0,
            resolution: coordinate.1,
            precinct: coordinate.2,
            states,
            contexts,
            decoders,
            subbands,
        })
    }

    #[test]
    fn actual_precinct_initialization_keeps_all_owned_state_limits_and_empty_policy() {
        let limits = [
            ResourceLimits::HARDENED,
            ResourceLimits::HARDENED
                .with_maximum_code_blocks(1)
                .unwrap(),
            ResourceLimits::HARDENED.with_maximum_work_units(1).unwrap(),
        ];
        let styles = [
            Tier1CodingStyle::default(),
            Tier1CodingStyle {
                block_coding: crate::tier1::Tier1BlockCoding::Mixed,
                force_high_throughput: true,
                reset_contexts: true,
                ..Tier1CodingStyle::default()
            },
        ];
        let mut cases = 0;
        let mut successes = 0;
        for rows in 0..=4 {
            for across in [0, 1, 2, u32::MAX] {
                for down in [0, 1, 2, u32::MAX] {
                    for maximum_zero in [0, 1, 74, 75] {
                        for count in [0, 1, 2, 3, 4] {
                            for limit in &limits {
                                for coordinate in
                                    [(0, 0, 0), (u16::MAX, u8::MAX, u32::MAX), (1, 1, 17)]
                                {
                                    for style in styles {
                                        let expected = reference_precinct_initialization(
                                            coordinate,
                                            style,
                                            precinct_execution_fixture(
                                                rows,
                                                across,
                                                down,
                                                maximum_zero,
                                                count,
                                            ),
                                            limit,
                                        )
                                        .map(|value| exact_packet_precinct_snapshot(&value));
                                        let actual = packet_precinct_from_subbands(
                                            coordinate.0,
                                            coordinate.1,
                                            coordinate.2,
                                            style,
                                            precinct_execution_fixture(
                                                rows,
                                                across,
                                                down,
                                                maximum_zero,
                                                count,
                                            ),
                                            limit,
                                        )
                                        .map(|value| exact_packet_precinct_snapshot(&value));
                                        let public = PacketPrecinctDecoder::new_subbands(
                                            coordinate.0,
                                            coordinate.1,
                                            coordinate.2,
                                            style,
                                            precinct_execution_fixture(
                                                rows,
                                                across,
                                                down,
                                                maximum_zero,
                                                count,
                                            ),
                                            limit,
                                        )
                                        .map(|value| exact_packet_precinct_snapshot(&value));
                                        successes += usize::from(expected.is_ok());
                                        assert_eq!(actual, expected);
                                        assert_eq!(public, expected);
                                        cases += 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        assert_eq!(cases, 28_800);
        assert!(successes > 100, "{successes} full precinct states checked");
    }

    fn literal_one_node_tree(low: u32, value: u32) -> TagTree {
        TagTree {
            levels: vec![TagTreeLevel {
                offset: 0,
                width: 1,
                height: 1,
            }],
            nodes: vec![TagTreeNode { low, value }],
        }
    }

    fn literal_header_context(style: Tier1CodingStyle) -> CodeBlockPacketContext {
        CodeBlockPacketContext {
            leaf_x: 0,
            leaf_y: 0,
            layer: 0,
            maximum_zero_bitplanes: 2,
            tier1_style: style,
        }
    }

    #[test]
    fn typed_header_factories_observe_real_limits_and_preserve_prefix_admission() {
        let limits = ResourceLimits::default()
            .with_maximum_packet_header_bytes(1)
            .unwrap()
            .with_maximum_work_units(1)
            .unwrap();
        assert_eq!(
            packet_reader_new(&[0, 0], &limits),
            Err(DecodeError::LimitExceeded {
                resource: Resource::PacketHeaderBytes,
                limit: 1,
                actual: 2,
            })
        );
        let expected = PacketBitReader {
            input: &[0, 0],
            byte_index: 0,
            current_byte: 0,
            bits_remaining: 0,
            previous_byte_was_ff: false,
            bits_read: 0,
            maximum_work_units: 1,
            maximum_header_bytes: 1,
        };
        assert_eq!(packet_reader_prefix(&[0, 0], &limits), expected);
        assert_eq!(
            tag_tree_new(u32::MAX, u32::MAX, &limits),
            Err(DecodeError::LimitExceeded {
                resource: Resource::TagTreeNodes,
                limit: limits.maximum_tag_tree_nodes(),
                actual: u64::from(u32::MAX) * u64::from(u32::MAX),
            })
        );
        let expected = TagTree {
            levels: vec![
                TagTreeLevel {
                    offset: 0,
                    width: 2,
                    height: 1,
                },
                TagTreeLevel {
                    offset: 2,
                    width: 1,
                    height: 1,
                },
            ],
            nodes: vec![
                TagTreeNode {
                    low: 0,
                    value: u32::MAX
                };
                3
            ],
        };
        assert_eq!(tag_tree_new(2, 1, &limits), Ok(expected.clone()));
        assert_eq!(TagTree::new(2, 1, &limits), Ok(expected));
    }

    #[test]
    fn actual_full_header_literal_and_every_work_prefix_have_independent_whole_results() {
        for cap in 0_u64..=8 {
            let mut state = code_block_packet_state_new();
            let original = state;
            let mut inclusion = literal_one_node_tree(0, u32::MAX);
            let mut zero = literal_one_node_tree(0, u32::MAX);
            let mut reader = packet_reader_prefix_from_input(&[0xc2], 1, cap);
            let result = decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero,
                literal_header_context(Tier1CodingStyle::default()),
                &mut reader,
            );
            let consumed = if cap < 7 { cap + 1 } else { 7 };
            assert_eq!(
                reader,
                PacketBitReader {
                    input: &[0xc2],
                    byte_index: 1,
                    current_byte: 0xc2,
                    bits_remaining: (8 - consumed) as u8,
                    previous_byte_was_ff: false,
                    bits_read: consumed,
                    maximum_work_units: cap,
                    maximum_header_bytes: 1,
                }
            );
            assert_eq!(
                inclusion,
                literal_one_node_tree(0, if cap >= 1 { 0 } else { u32::MAX })
            );
            assert_eq!(
                zero,
                literal_one_node_tree(0, if cap >= 2 { 0 } else { u32::MAX })
            );
            if cap < 7 {
                assert_eq!(state, original);
                assert_eq!(
                    result,
                    Err(packet_reader_limit(Resource::WorkUnits, cap, cap + 1))
                );
            } else {
                assert_eq!(
                    state,
                    CodeBlockPacketState {
                        included: true,
                        zero_bitplanes: Some(0),
                        lblock: 3,
                        total_passes: 1,
                        high_throughput: Some(false),
                    }
                );
                let mut passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
                let mut lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
                passes[0] = 1;
                lengths[0] = 1;
                assert_eq!(
                    result,
                    Ok(Some(CodeBlockContribution {
                        first_inclusion: true,
                        zero_bitplanes: 0,
                        new_passes: 1,
                        data_length: 1,
                        high_throughput: false,
                        segment_count: 1,
                        segment_passes: passes,
                        segment_lengths: lengths,
                    }))
                );
            }
        }
    }

    #[test]
    fn full_header_admits_every_stored_lblock_byte_and_does_not_validate_unvisited_zero_tree() {
        for lblock in 0..=u8::MAX {
            let mut state = CodeBlockPacketState {
                included: true,
                zero_bitplanes: Some(u16::MAX),
                lblock,
                total_passes: 1,
                high_throughput: Some(false),
            };
            let original = state;
            let mut inclusion = TagTree {
                levels: vec![],
                nodes: vec![],
            };
            let mut zero = TagTree {
                levels: vec![],
                nodes: vec![],
            };
            let input = [0x80, 0, 0, 0, 0];
            let mut reader = packet_reader_prefix_from_input(&input, 5, 64);
            let mut context = literal_header_context(Tier1CodingStyle::default());
            context.maximum_zero_bitplanes = 1;
            let result = decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero,
                context,
                &mut reader,
            );
            let consumed = if lblock <= 32 {
                3 + u64::from(lblock)
            } else {
                3
            };
            let index = consumed.div_ceil(8) as usize;
            assert_eq!(
                reader,
                PacketBitReader {
                    input: &input,
                    byte_index: index,
                    current_byte: if index == 1 { 0x80 } else { 0 },
                    bits_remaining: ((8 - consumed % 8) % 8) as u8,
                    previous_byte_was_ff: false,
                    bits_read: consumed,
                    maximum_work_units: 64,
                    maximum_header_bytes: 5,
                }
            );
            assert!(
                inclusion.levels.is_empty()
                    && inclusion.nodes.is_empty()
                    && zero.levels.is_empty()
                    && zero.nodes.is_empty()
            );
            if lblock > 32 {
                assert_eq!(
                    result,
                    Err(packet_reader_error(1, MalformedKind::InvalidPacketHeader))
                );
                assert_eq!(state, original);
            } else {
                let mut passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
                passes[0] = 1;
                assert_eq!(
                    result,
                    Ok(Some(CodeBlockContribution {
                        first_inclusion: false,
                        zero_bitplanes: u16::MAX,
                        new_passes: 1,
                        data_length: 0,
                        high_throughput: false,
                        segment_count: 1,
                        segment_passes: passes,
                        segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
                    }))
                );
                assert_eq!(
                    state,
                    CodeBlockPacketState {
                        total_passes: 2,
                        ..original
                    }
                );
            }
        }
    }

    #[test]
    fn header_none_empty_unused_raw_trees_and_late_error_rollback_are_distinct() {
        let mut state = code_block_packet_state_new();
        let original = state;
        let mut inclusion = literal_one_node_tree(1, 1);
        let mut zero = TagTree {
            levels: vec![],
            nodes: vec![],
        };
        let mut reader = packet_reader_prefix_from_input(&[], 0, 0);
        reader.bits_remaining = u8::MAX;
        let before = reader;
        assert_eq!(
            decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero,
                literal_header_context(Tier1CodingStyle::default()),
                &mut reader
            ),
            Ok(None)
        );
        assert_eq!(state, original);
        assert_eq!(reader, before);
        assert_eq!(inclusion, literal_one_node_tree(1, 1));
        assert_eq!(
            zero,
            TagTree {
                levels: vec![],
                nodes: vec![]
            }
        );

        let mut state = CodeBlockPacketState {
            included: true,
            zero_bitplanes: Some(0),
            lblock: 0,
            total_passes: 1,
            high_throughput: Some(false),
        };
        let mut inclusion = TagTree {
            levels: vec![],
            nodes: vec![],
        };
        let mut reader = packet_reader_prefix_from_input(&[0x80], 1, 3);
        let result = decode_code_block_contribution(
            &mut state,
            &mut inclusion,
            &mut zero,
            literal_header_context(Tier1CodingStyle::default()),
            &mut reader,
        )
        .unwrap()
        .unwrap();
        let mut passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        passes[0] = 1;
        assert_eq!(
            result,
            CodeBlockContribution {
                first_inclusion: false,
                zero_bitplanes: 0,
                new_passes: 1,
                data_length: 0,
                high_throughput: false,
                segment_count: 1,
                segment_passes: passes,
                segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
            }
        );
        assert_eq!(state.total_passes, 2);
        assert_eq!(reader.bits_read, 3);
        assert!(inclusion.levels.is_empty() && zero.levels.is_empty());
        for total in [crate::tier1::MAX_TIER1_PASSES, u32::MAX] {
            let mut state = CodeBlockPacketState {
                included: true,
                zero_bitplanes: Some(0),
                lblock: 3,
                total_passes: total,
                high_throughput: Some(false),
            };
            let before = state;
            let mut reader = packet_reader_prefix_from_input(&[0x84], 1, 64);
            assert_eq!(
                decode_code_block_contribution(
                    &mut state,
                    &mut inclusion,
                    &mut zero,
                    literal_header_context(Tier1CodingStyle::default()),
                    &mut reader
                ),
                Err(packet_reader_error(
                    1,
                    if total == u32::MAX {
                        MalformedKind::ArithmeticOverflow
                    } else {
                        MalformedKind::InvalidPacketHeader
                    }
                ))
            );
            assert_eq!(state, before);
            assert_eq!(
                (reader.bits_read, reader.byte_index, reader.bits_remaining),
                (6, 1, 2)
            );
        }
    }

    #[test]
    fn actual_mixed_header_probe_commits_only_selected_reader_and_preserves_failed_main_cursor() {
        for (lblock, input, primary_bits, expected_passes, expected_length, route, consumed) in [
            (3_u8, 0x38_u8, 3_u8, 4_u32, 7_u32, Some(false), 5_u64),
            (4, 0x1c, 4, 1, 1, Some(true), 4),
            (3, 0, 3, 1, 0, None, 3),
        ] {
            let mut state = CodeBlockPacketState {
                included: true,
                zero_bitplanes: Some(0),
                lblock,
                total_passes: 0,
                high_throughput: None,
            };
            let mut segments = header_segments_new(
                &state,
                Tier1CodingStyle::from_code_block_style(0xc0).unwrap(),
            );
            let data = [input];
            let mut reader = packet_reader_prefix_from_input(&data, 1, 64);
            assert_eq!(
                read_header_segment_length(
                    &mut state,
                    &mut segments,
                    &mut reader,
                    0,
                    4,
                    1,
                    primary_bits
                ),
                Ok((expected_passes, expected_length))
            );
            assert_eq!(state.high_throughput, route);
            assert_eq!(segments.routing, route);
            assert_eq!(
                reader,
                PacketBitReader {
                    input: &[input],
                    byte_index: 1,
                    current_byte: input,
                    bits_remaining: (8 - consumed) as u8,
                    previous_byte_was_ff: false,
                    bits_read: consumed,
                    maximum_work_units: 64,
                    maximum_header_bytes: 1,
                }
            );
        }
        let mut state = CodeBlockPacketState {
            included: true,
            zero_bitplanes: Some(0),
            lblock: 4,
            total_passes: 0,
            high_throughput: None,
        };
        let before = state;
        let mut segments = header_segments_new(
            &state,
            Tier1CodingStyle::from_code_block_style(0xc0).unwrap(),
        );
        let mut reader = packet_reader_prefix_from_input(&[0x1c], 1, 4);
        assert_eq!(
            read_header_segment_length(&mut state, &mut segments, &mut reader, 0, 4, 1, 4),
            Err(packet_reader_limit(Resource::WorkUnits, 4, 5))
        );
        assert_eq!(state, before);
        assert_eq!(segments.routing, None);
        assert_eq!(
            reader,
            PacketBitReader {
                input: &[0x1c],
                byte_index: 1,
                current_byte: 0x1c,
                bits_remaining: 4,
                previous_byte_was_ff: false,
                bits_read: 4,
                maximum_work_units: 4,
                maximum_header_bytes: 1,
            }
        );
        let mut reader = packet_reader_prefix_from_input(&[0x10], 2, 64);
        assert_eq!(
            read_header_segment_length(&mut state, &mut segments, &mut reader, 0, 164, 1, 4),
            Err(packet_reader_error(1, MalformedKind::Truncated))
        );
        assert_eq!(reader.bits_read, 4);
        assert_eq!(reader.bits_remaining, 4);
        assert_eq!(state, before);
    }

    #[test]
    fn native_header_segment_capacity_and_final_count_conversion_keep_exact_order() {
        let mut state = CodeBlockPacketState {
            included: true,
            zero_bitplanes: Some(0),
            lblock: 3,
            total_passes: 0,
            high_throughput: Some(false),
        };
        let original = state;
        for count in [164, 165, usize::MAX] {
            let mut segments = header_segments_new(&state, Tier1CodingStyle::default());
            segments.segment_count = count;
            state.total_passes = u32::MAX;
            let before = state;
            let mut reader = packet_reader_prefix_from_input(&[], 0, 0);
            reader.byte_index = 17;
            let old_reader = reader;
            assert_eq!(
                read_header_segment(
                    &mut state,
                    &mut segments,
                    u8::MAX,
                    literal_header_context(Tier1CodingStyle::default()),
                    &mut reader
                ),
                Err(packet_reader_error(17, MalformedKind::InvalidPacketHeader))
            );
            assert_eq!(state, before);
            assert_eq!(reader, old_reader);
            assert_eq!(segments.segment_count, count);
        }
        for count in [164, 165, 256] {
            state = original;
            let mut segments = header_segments_new(&state, Tier1CodingStyle::default());
            segments.segment_count = count;
            let next = state;
            let mut reader = packet_reader_prefix_from_input(&[], 0, 0);
            reader.byte_index = 17;
            let result = commit_header_contribution(&mut state, next, segments, false, 1, &reader);
            assert_eq!(
                state,
                CodeBlockPacketState {
                    total_passes: 1,
                    ..original
                }
            );
            if count <= 255 {
                assert_eq!(result.unwrap().unwrap().segment_count(), count as u8);
            } else {
                assert_eq!(
                    result,
                    Err(packet_reader_error(17, MalformedKind::ArithmeticOverflow))
                );
            }
        }
    }

    #[test]
    fn packet_reader_words_match_closed_two_byte_oracle_and_all_eight_final_fields() {
        for first in 0..=u8::MAX {
            for second in 0..=u8::MAX {
                let input = [first, second];
                for count in [0_u8, 1, 7, 8, 9, 15, 16, 32] {
                    let mut reader = packet_reader_prefix_from_input(&input, 32, 64);
                    let result = reader.read_bits(count);
                    let stuffed = first == 0xff;
                    let invalid_stuff = stuffed && second >= 0x80 && count > 8;
                    let available = if stuffed { 15_u8 } else { 16 };
                    let read = if invalid_stuff {
                        8
                    } else {
                        count.min(available)
                    };
                    let expected_result = if invalid_stuff {
                        Err(packet_reader_error(1, MalformedKind::InvalidBitStuffing))
                    } else if count > available {
                        Err(packet_reader_error(2, MalformedKind::Truncated))
                    } else if count == 0 {
                        Ok(0)
                    } else if count <= 8 {
                        Ok(u32::from(first) >> (8 - count))
                    } else if stuffed {
                        Ok((255_u32 << (count - 8)) | (u32::from(second) >> (15 - count)))
                    } else {
                        Ok(((u32::from(first) * 256) + u32::from(second)) >> (16 - count))
                    };
                    let loaded_second = read > 8;
                    assert_eq!(result, expected_result, "input={input:?}, count={count}");
                    assert_eq!(
                        reader,
                        PacketBitReader {
                            input: &input,
                            byte_index: if read == 0 {
                                0
                            } else if loaded_second {
                                2
                            } else {
                                1
                            },
                            current_byte: if read == 0 {
                                0
                            } else if loaded_second {
                                second
                            } else {
                                first
                            },
                            bits_remaining: if loaded_second {
                                available - read
                            } else if read == 0 {
                                0
                            } else {
                                8 - read
                            },
                            previous_byte_was_ff: read != 0
                                && if loaded_second {
                                    second == 0xff
                                } else {
                                    stuffed
                                },
                            bits_read: u64::from(read),
                            maximum_work_units: 64,
                            maximum_header_bytes: 32,
                        }
                    );
                }
            }
        }
    }

    #[test]
    fn packet_reader_native_state_errors_preserve_exact_admission_and_consumption_order() {
        let mut reader = packet_reader_prefix_from_input(&[], 0, 0);
        let before = reader;
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_limit(Resource::PacketHeaderBytes, 0, 1))
        );
        assert_eq!(reader, before);
        reader.byte_index = usize::MAX;
        reader.maximum_header_bytes = u64::MAX;
        let before = reader;
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_error(
                usize::MAX,
                if usize::BITS == 64 {
                    MalformedKind::ArithmeticOverflow
                } else {
                    MalformedKind::Truncated
                }
            ))
        );
        assert_eq!(reader, before);
    }

    #[test]
    fn raw_tag_tree_single_node_matches_wide_threshold_and_budget_oracle() {
        for low in [0, 1, 3, u32::MAX - 1, u32::MAX] {
            for value in [0, 1, 4, u32::MAX - 1, u32::MAX] {
                for threshold in [0, 1, 2, 4, u32::MAX] {
                    for cap in [0_u64, 1, 2, 8] {
                        let mut tree = TagTree {
                            levels: vec![TagTreeLevel {
                                offset: 0,
                                width: 1,
                                height: 1,
                            }],
                            nodes: vec![TagTreeNode { low, value }],
                        };
                        let before = tree.clone();
                        let mut reader = packet_reader_prefix_from_input(&[0], 1, cap);
                        let needed = u64::from(threshold.min(value)).saturating_sub(u64::from(low));
                        let successful = needed.min(cap).min(8);
                        let mut expected_tree = before;
                        expected_tree.nodes[0].low = (u64::from(low) + successful) as u32;
                        let actual = tree.decode(0, 0, threshold, &mut reader);
                        let consumed = if needed > cap && cap < 8 {
                            cap + 1
                        } else {
                            successful
                        };
                        let expected = if needed > cap && cap < 8 {
                            Err(packet_reader_limit(Resource::WorkUnits, cap, cap + 1))
                        } else if needed > 8 {
                            Err(packet_reader_limit(Resource::PacketHeaderBytes, 1, 2))
                        } else {
                            Ok(TagTreeValue {
                                value: if value < threshold { Some(value) } else { None },
                                is_below_threshold: value < threshold,
                            })
                        };
                        assert_eq!(actual, expected);
                        assert_eq!(tree, expected_tree);
                        assert_eq!(
                            reader,
                            PacketBitReader {
                                input: &[0],
                                byte_index: usize::from(consumed != 0),
                                current_byte: 0,
                                bits_remaining: if consumed == 0 {
                                    0
                                } else {
                                    (8 - consumed) as u8
                                },
                                previous_byte_was_ff: false,
                                bits_read: consumed,
                                maximum_work_units: cap,
                                maximum_header_bytes: 1,
                            }
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn raw_tag_tree_duplicate_paths_and_64_65_levels_keep_real_state_and_error_order() {
        for levels in [2, 64, 65] {
            let mut tree = TagTree {
                levels: vec![
                    TagTreeLevel {
                        offset: 0,
                        width: 1,
                        height: 1
                    };
                    levels
                ],
                nodes: vec![TagTreeNode {
                    low: 0,
                    value: u32::MAX,
                }],
            };
            let before = tree.clone();
            let mut reader = packet_reader_prefix_from_input(&[0x80], 1, 1);
            let original_reader = reader;
            let result = tree.decode(0, 0, 1, &mut reader);
            if levels == 65 {
                assert_eq!(
                    result,
                    Err(packet_reader_error(0, MalformedKind::InvalidTagTree))
                );
                assert_eq!(tree, before);
                assert_eq!(reader, original_reader);
            } else {
                assert_eq!(
                    result,
                    Ok(TagTreeValue {
                        value: Some(0),
                        is_below_threshold: true
                    })
                );
                assert_eq!(tree.levels, before.levels);
                assert_eq!(tree.nodes, [TagTreeNode { low: 0, value: 0 }]);
                assert_eq!(
                    (reader.bits_read, reader.byte_index, reader.bits_remaining),
                    (1, 1, 7)
                );
            }
        }
        for offset in [0, usize::MAX] {
            let mut tree = TagTree {
                levels: vec![TagTreeLevel {
                    offset,
                    width: 2,
                    height: 2,
                }],
                nodes: vec![],
            };
            let before = tree.clone();
            let mut reader = packet_reader_prefix_from_input(&[], u64::MAX, u64::MAX);
            reader.byte_index = 17;
            let original = reader;
            assert_eq!(
                tree.decode(1, 1, u32::MAX, &mut reader),
                Err(if offset == 0 {
                    packet_reader_error(17, MalformedKind::InvalidTagTree)
                } else {
                    packet_reader_error(0, MalformedKind::ArithmeticOverflow)
                })
            );
            assert_eq!(tree, before);
            assert_eq!(reader, original);
        }
        let mut empty = TagTree {
            levels: vec![],
            nodes: vec![TagTreeNode { low: 7, value: 0 }],
        };
        let mut reader = packet_reader_prefix_from_input(&[], 0, 0);
        reader.byte_index = 17;
        assert_eq!(
            empty.leaf_count(),
            Err(packet_reader_error(0, MalformedKind::InvalidTagTree))
        );
        assert_eq!(
            empty.decode(0, 0, 1, &mut reader),
            Err(packet_reader_error(0, MalformedKind::InvalidTagTree))
        );
        assert_eq!(empty.nodes[0], TagTreeNode { low: 7, value: 0 });
    }

    #[test]
    fn tag_tree_real_constructor_matches_closed_rectangle_levels_and_cap_first_failure() {
        for width in 1_u32..=9 {
            for height in 1_u32..=9 {
                let top = 32 - (width.max(height) - 1).leading_zeros();
                for cap in [0_u64, 1, 8, 64, 200] {
                    let mut levels = Vec::new();
                    let mut total = 0_u64;
                    let mut failure = None;
                    for level in 0..=top {
                        let scale = 1_u64 << level;
                        let w = u64::from(width).div_ceil(scale);
                        let h = u64::from(height).div_ceil(scale);
                        let next = total + w * h;
                        if next > cap {
                            failure = Some(packet_reader_limit(Resource::TagTreeNodes, cap, next));
                            break;
                        }
                        levels.push(TagTreeLevel {
                            offset: total as usize,
                            width: w as u32,
                            height: h as u32,
                        });
                        total = next;
                    }
                    assert_eq!(
                        tag_tree_from_dimensions(width, height, cap),
                        match failure {
                            Some(error) => Err(error),
                            None => Ok(TagTree {
                                levels,
                                nodes: vec![
                                    TagTreeNode {
                                        low: 0,
                                        value: u32::MAX
                                    };
                                    total as usize
                                ]
                            }),
                        }
                    );
                }
            }
        }
        assert_eq!(
            tag_tree_from_dimensions(0, u32::MAX, 0),
            Err(packet_reader_error(0, MalformedKind::InvalidTagTree))
        );
        assert_eq!(
            tag_tree_from_dimensions(u32::MAX, u32::MAX, u64::MAX),
            Err(packet_reader_error(0, MalformedKind::ArithmeticOverflow))
        );
    }

    #[test]
    fn packet_state_getters_and_copy_preserve_all_native_fields_without_header_invariants() {
        assert_eq!(
            code_block_packet_state_new(),
            CodeBlockPacketState {
                included: false,
                zero_bitplanes: None,
                lblock: 3,
                total_passes: 0,
                high_throughput: None,
            }
        );
        for lblock in 0..=u8::MAX {
            for included in [false, true] {
                for zero_bitplanes in [None, Some(0), Some(u16::MAX)] {
                    for total_passes in [0, crate::tier1::MAX_TIER1_PASSES, u32::MAX] {
                        for high_throughput in [None, Some(false), Some(true)] {
                            let state = CodeBlockPacketState {
                                included,
                                zero_bitplanes,
                                lblock,
                                total_passes,
                                high_throughput,
                            };
                            let copy = state;
                            assert_eq!(
                                (
                                    copy.included(),
                                    copy.zero_bitplanes(),
                                    copy.lblock(),
                                    copy.total_passes(),
                                    copy.high_throughput()
                                ),
                                (
                                    included,
                                    zero_bitplanes,
                                    lblock,
                                    total_passes,
                                    high_throughput
                                )
                            );
                            assert_eq!(copy, state);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn packet_reader_budget_stuffing_and_full_width_words() {
        let mut reader = packet_reader_prefix_from_input(&[0x80], 1, 0);
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_limit(Resource::WorkUnits, 0, 1))
        );
        assert_eq!(
            reader,
            PacketBitReader {
                input: &[0x80],
                byte_index: 1,
                current_byte: 0x80,
                bits_remaining: 7,
                previous_byte_was_ff: false,
                bits_read: 1,
                maximum_work_units: 0,
                maximum_header_bytes: 1,
            }
        );
        reader.bits_read = u64::MAX;
        let mut expected = reader;
        expected.bits_remaining = 6;
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_error(1, MalformedKind::ArithmeticOverflow))
        );
        assert_eq!(reader, expected);
        reader.bits_remaining = u8::MAX;
        let before = reader;
        assert_eq!(reader.read_bits(0), Ok(0));
        assert_eq!(reader, before);
        for count in 33..=u8::MAX {
            assert_eq!(
                reader.read_bits(count),
                Err(packet_reader_error(1, MalformedKind::InvalidMarkerLength))
            );
            assert_eq!(reader, before);
        }
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_error(1, MalformedKind::InvalidBitStuffing))
        );
        assert_eq!(reader, before);
        assert_eq!(
            packet_reader_from_input(&[0, 0], 1, 0),
            Err(packet_reader_limit(Resource::PacketHeaderBytes, 1, 2))
        );
        let mut reader = packet_reader_prefix_from_input(&[0xff, 0x80], 2, 64);
        assert_eq!(reader.read_bit(), Ok(true));
        reader.align_to_byte();
        assert!(reader.previous_byte_was_ff);
        let before = reader;
        assert_eq!(
            reader.read_bit(),
            Err(packet_reader_error(1, MalformedKind::InvalidBitStuffing))
        );
        assert_eq!(reader, before);
        let mut reader = packet_reader_prefix_from_input(&[0xff, 0x7f, 0xff, 0x7f, 0xff], 5, 32);
        assert_eq!(reader.read_bits(32), Ok(u32::MAX));
        assert_eq!(
            (
                reader.byte_index,
                reader.bits_remaining,
                reader.bits_read,
                reader.current_byte,
                reader.previous_byte_was_ff
            ),
            (5, 6, 32, 0xff, true)
        );
    }

    fn literal_empty_ht_contribution(count: u8, passes: u8) -> CodeBlockContribution {
        CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: passes,
            data_length: 0,
            high_throughput: true,
            segment_count: count,
            segment_passes: [1; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
            segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
        }
    }

    fn literal_ht_decoder(bitplanes: u16) -> Tier1CodeBlockDecoder {
        Tier1CodeBlockDecoder::new(
            1,
            1,
            bitplanes,
            SubbandOrientation::Ll,
            Tier1CodingStyle::from_code_block_style(0x40).unwrap(),
        )
        .unwrap()
    }

    #[test]
    fn ht_body_zero_setting_precedes_count_error_but_outer_rolls_back_every_field() {
        let limits = ResourceLimits::default();
        let mut header = literal_empty_ht_contribution(0, 0);
        header.zero_bitplanes = 1;
        let mut staged = literal_ht_decoder(3);
        assert_eq!(staged.maximum_passes(), 7);
        assert_eq!(
            decode_code_block_contribution_body_staged(&mut staged, &header, &[], &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodeBlock
            }),
        );
        assert_eq!(staged.maximum_passes(), 4);
        assert_eq!(
            (
                staged.next_pass(),
                staged.decoded_segments(),
                staged.decoded_bytes()
            ),
            (0, 0, 0)
        );
        let mut transactional = literal_ht_decoder(3);
        let before = format!("{transactional:?}");
        assert_eq!(
            decode_code_block_contribution_body(&mut transactional, &header, &[], &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodeBlock
            }),
        );
        assert_eq!(format!("{transactional:?}"), before);
    }

    #[test]
    fn ht_body_final_pass_mismatch_keeps_staged_progress_and_rolls_back_outer_decoder() {
        let limits = ResourceLimits::default();
        let mut header = literal_empty_ht_contribution(2, 2);
        header.segment_passes[1] = 2;
        let mut staged = literal_ht_decoder(3);
        assert_eq!(
            decode_code_block_contribution_body_staged(&mut staged, &header, &[], &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodeBlock
            }),
        );
        assert_eq!(
            (
                staged.next_pass(),
                staged.decoded_segments(),
                staged.decoded_bytes()
            ),
            (3, 2, 0)
        );
        let mut transactional = literal_ht_decoder(3);
        let before = format!("{transactional:?}");
        assert!(
            decode_code_block_contribution_body(&mut transactional, &header, &[], &limits).is_err()
        );
        assert_eq!(format!("{transactional:?}"), before);
        header.new_passes = 3;
        assert_eq!(
            decode_code_block_contribution_body(&mut transactional, &header, &[], &limits),
            Ok(CodeBlockBodyDecode {
                segments: 2,
                passes: 3,
                bytes: 0
            }),
        );
        assert_eq!(
            (
                transactional.next_pass(),
                transactional.decoded_segments(),
                transactional.decoded_bytes()
            ),
            (3, 2, 0)
        );
        assert_eq!(transactional.plane().signed_coefficient(0, 0).unwrap(), 0);
    }

    #[test]
    fn ht_body_native_count_reaches_physical_header_boundary_without_count_normalization() {
        let limits = ResourceLimits::default();
        let header = literal_empty_ht_contribution(165, 0);
        let mut staged = literal_ht_decoder(56);
        assert_eq!(
            decode_code_block_contribution_body_staged(&mut staged, &header, &[], &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidPacketHeader
            }),
        );
        assert_eq!(
            (
                staged.next_pass(),
                staged.decoded_segments(),
                staged.decoded_bytes()
            ),
            (164, 164, 0)
        );
        let mut transactional = literal_ht_decoder(56);
        let before = format!("{transactional:?}");
        assert_eq!(
            decode_code_block_contribution_body(&mut transactional, &header, &[], &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidPacketHeader
            }),
        );
        assert_eq!(format!("{transactional:?}"), before);
    }

    #[test]
    fn shared_code_block_body_prepare_has_exact_native_admission_and_frame() {
        for force in [false, true] {
            for high_throughput in [false, true] {
                for zero_bitplanes in [0, u16::MAX] {
                    for wrong_length in [false, true] {
                        let mut decoder = Tier1CodeBlockDecoder::new(
                            1,
                            1,
                            1,
                            crate::tier1::SubbandOrientation::Ll,
                            Tier1CodingStyle {
                                force_high_throughput: force,
                                ..Tier1CodingStyle::default()
                            },
                        )
                        .unwrap();
                        let before = format!("{decoder:?}");
                        let contribution = CodeBlockContribution {
                            first_inclusion: false,
                            zero_bitplanes,
                            new_passes: u8::MAX,
                            data_length: 1,
                            high_throughput,
                            segment_count: u8::MAX,
                            segment_passes: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
                            segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
                        };
                        let body: &[u8] = if wrong_length { &[] } else { &[0xff] };
                        let accepted =
                            !wrong_length && (!force || high_throughput) && zero_bitplanes == 0;
                        assert_eq!(
                            prepare_code_block_contribution_body(&mut decoder, &contribution, body),
                            if accepted {
                                Ok(())
                            } else {
                                Err(packet_invalid_code_block())
                            }
                        );
                        assert_eq!(
                            format!("{decoder:?}"),
                            if accepted {
                                before.replacen(
                                    "zero_bitplanes: None,",
                                    "zero_bitplanes: Some(0),",
                                    1,
                                )
                            } else {
                                before
                            }
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn mixed_packet_union_routes_literal_bytes_and_keeps_empty_count_distinctions() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0xc0).unwrap();
        for high in [false, true] {
            let mut decoder =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
            let mut header = one_ff_legacy_contribution();
            header.high_throughput = high;
            let body: &[u8] = if high { &[0, 0x63, 0] } else { &[0xff] };
            header.data_length = body.len() as u32;
            header.segment_lengths[0] = header.data_length;
            assert_eq!(
                decode_code_block_contribution_body(&mut decoder, &header, body, &limits),
                Ok(CodeBlockBodyDecode {
                    segments: 1,
                    passes: 1,
                    bytes: header.data_length
                }),
            );
            assert_eq!(
                (
                    decoder.next_pass(),
                    decoder.decoded_segments(),
                    decoder.decoded_bytes()
                ),
                (1, 1, body.len() as u64)
            );
            assert_eq!(
                decoder.plane().signed_coefficient(0, 0).unwrap(),
                if high { -1 } else { 0 }
            );

            let mut decoder =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
            let before = format!("{decoder:?}");
            header.segment_count = 0;
            header.new_passes = 0;
            header.data_length = 0;
            let result = decode_code_block_contribution_body(&mut decoder, &header, &[], &limits);
            if high {
                assert_eq!(result, Err(packet_invalid_code_block()));
                assert_eq!(format!("{decoder:?}"), before);
            } else {
                assert_eq!(
                    result,
                    Ok(CodeBlockBodyDecode {
                        segments: 0,
                        passes: 0,
                        bytes: 0
                    })
                );
                assert_eq!(
                    (
                        decoder.next_pass(),
                        decoder.decoded_segments(),
                        decoder.decoded_bytes()
                    ),
                    (0, 0, 0)
                );
            }
        }
    }

    #[test]
    fn mixed_packet_union_preserves_each_route_late_error_and_full_outer_rollback() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0xc0).unwrap();
        for high in [false, true] {
            let mut header = one_ff_legacy_contribution();
            header.high_throughput = high;
            header.new_passes = 2;
            let body: &[u8] = if high { &[0, 0x63, 0] } else { &[0xff] };
            header.data_length = body.len() as u32;
            header.segment_lengths[0] = header.data_length;
            let mut staged =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
            assert_eq!(
                decode_code_block_contribution_body_staged(&mut staged, &header, body, &limits),
                Err(packet_invalid_code_block())
            );
            assert_eq!(
                (
                    staged.next_pass(),
                    staged.decoded_segments(),
                    staged.decoded_bytes()
                ),
                (1, 1, body.len() as u64)
            );
            assert_eq!(
                staged.plane().signed_coefficient(0, 0).unwrap(),
                if high { -1 } else { 0 }
            );
            let mut decoder =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
            let before = format!("{decoder:?}");
            assert_eq!(
                decode_code_block_contribution_body(&mut decoder, &header, body, &limits),
                Err(packet_invalid_code_block())
            );
            assert_eq!(format!("{decoder:?}"), before);
        }
    }

    #[test]
    fn mixed_packet_union_uses_actual_route_specific_input_budget() {
        let limits = ResourceLimits::default()
            .with_maximum_input_bytes(1)
            .unwrap();
        let style = Tier1CodingStyle::from_code_block_style(0xc0).unwrap();
        for high in [false, true] {
            let mut header = one_ff_legacy_contribution();
            header.high_throughput = high;
            let body: &[u8] = if high { &[0, 0x63, 0] } else { &[0xff, 0] };
            header.data_length = body.len() as u32;
            header.segment_lengths[0] = header.data_length;
            let mut decoder =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
            let before = format!("{decoder:?}");
            let result = decode_code_block_contribution_body(&mut decoder, &header, body, &limits);
            if high {
                assert_eq!(
                    result,
                    Ok(CodeBlockBodyDecode {
                        segments: 1,
                        passes: 1,
                        bytes: 3
                    })
                );
                assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), -1);
            } else {
                assert_eq!(
                    result,
                    Err(DecodeError::LimitExceeded {
                        resource: Resource::InputBytes,
                        limit: 1,
                        actual: 2,
                    })
                );
                assert_eq!(format!("{decoder:?}"), before);
            }
        }
    }

    fn literal_header_subband() -> PacketSubbandState {
        PacketSubbandState {
            orientation: SubbandOrientation::Ll,
            first_decoder: 0,
            decoder_count: 1,
            code_blocks_across: 1,
            code_blocks_down: 1,
            inclusion_tree: tag_tree_new(1, 1, &ResourceLimits::default()).unwrap(),
            zero_bitplane_tree: tag_tree_new(1, 1, &ResourceLimits::default()).unwrap(),
        }
    }

    fn literal_precinct_header_context() -> CodeBlockPacketContext {
        CodeBlockPacketContext {
            leaf_x: 0,
            leaf_y: 0,
            layer: 0,
            maximum_zero_bitplanes: 3,
            tier1_style: Tier1CodingStyle::default(),
        }
    }

    fn literal_packet_precinct() -> PacketPrecinctDecoder {
        PacketPrecinctDecoder {
            component: 0,
            resolution: 0,
            precinct: 0,
            states: vec![code_block_packet_state_new()],
            contexts: vec![literal_precinct_header_context()],
            decoders: vec![one_bit_legacy_decoder(false)],
            subbands: vec![literal_header_subband()],
        }
    }

    #[test]
    fn public_single_boundary_keeps_whole_payload_priority_and_real_partial_header_effects() {
        let base = ResourceLimits::default();
        for (payload, limited, error, included, passes, low) in [
            (
                &[0, 0][..],
                true,
                DecodeError::LimitExceeded {
                    resource: Resource::PacketHeaderBytes,
                    limit: 1,
                    actual: 2,
                },
                false,
                0,
                0,
            ),
            (
                &[0, 0][..],
                false,
                packet_reader_error(1, MalformedKind::TrailingData),
                false,
                0,
                0,
            ),
            (
                &[0x80][..],
                false,
                packet_reader_error(1, MalformedKind::InvalidPacketHeader),
                false,
                0,
                1,
            ),
            (&[0xe1][..], false, packet_invalid_code_block(), true, 1, 0),
        ] {
            let limits = if limited {
                base.with_maximum_packet_header_bytes(1).unwrap()
            } else {
                base
            };
            let mut state = code_block_packet_state_new();
            let mut inclusion = tag_tree_new(1, 1, &base).unwrap();
            let mut zero = tag_tree_new(1, 1, &base).unwrap();
            let mut decoder = one_bit_legacy_decoder(false);
            let before = format!("{decoder:?}");
            assert_eq!(
                decode_single_code_block_packet(
                    payload,
                    &mut state,
                    &mut inclusion,
                    &mut zero,
                    literal_precinct_header_context(),
                    &mut decoder,
                    &limits
                ),
                Err(error)
            );
            assert_eq!(
                (
                    state.included(),
                    state.total_passes(),
                    inclusion.nodes[0].low
                ),
                (included, passes, low)
            );
            assert_eq!(format!("{decoder:?}"), before);
            if included {
                assert_eq!(zero.nodes[0].value, 0);
            }
        }
        let mut state = code_block_packet_state_new();
        let mut inclusion = tag_tree_new(1, 1, &base).unwrap();
        let mut zero = tag_tree_new(1, 1, &base).unwrap();
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut context = literal_precinct_header_context();
        context.tier1_style = style;
        let mut decoder =
            Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
        assert_eq!(
            decode_single_code_block_packet(
                &[0xe3, 0, 0x63, 0],
                &mut state,
                &mut inclusion,
                &mut zero,
                context,
                &mut decoder,
                &base
            ),
            Ok(Some(CodeBlockBodyDecode {
                segments: 1,
                passes: 1,
                bytes: 3
            }))
        );
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), -1);
    }

    #[test]
    fn public_multi_boundary_preflights_every_body_then_keeps_prior_real_decoder_commits() {
        let limits = ResourceLimits::default();
        for late in [false, true] {
            let mut bytes = vec![0x55; 9];
            bytes.extend_from_slice(&[0xf8, 0xb1, 0, 0x01, 0xae]);
            if late {
                bytes.extend_from_slice(&[0x01, 0xae]);
            }
            let style = coding_style(false, false);
            let tile = TilePartPayload::uniform_for_packet_decoding(
                0,
                0,
                1,
                1,
                style,
                crate::codestream::RoiShifts::none(),
                &bytes,
            )
            .unwrap();
            let mut states = [code_block_packet_state_new(); 2];
            let mut inclusion = tag_tree_new(2, 1, &limits).unwrap();
            let mut zero = tag_tree_new(2, 1, &limits).unwrap();
            let mut first = literal_precinct_header_context();
            first.maximum_zero_bitplanes = 1;
            let contexts = [first, CodeBlockPacketContext { leaf_x: 1, ..first }];
            let mut decoders = [one_bit_legacy_decoder(false), one_bit_legacy_decoder(late)];
            let before = [format!("{:?}", decoders[0]), format!("{:?}", decoders[1])];
            assert_eq!(
                decode_multi_code_block_packet(
                    &tile,
                    9,
                    PacketCodeBlockExecution {
                        states: &mut states,
                        inclusion_tree: &mut inclusion,
                        zero_bitplane_tree: &mut zero,
                        contexts: &contexts,
                        decoders: &mut decoders,
                    },
                    &limits
                ),
                Err(if late {
                    packet_invalid_code_block()
                } else {
                    packet_reader_error(9, MalformedKind::Truncated)
                })
            );
            assert!(states.iter().all(|s| s.included() && s.total_passes() == 1));
            assert_eq!(format!("{:?}", decoders[1]), before[1]);
            if late {
                assert_eq!(
                    (
                        decoders[0].next_pass(),
                        decoders[0].decoded_segments(),
                        decoders[0].decoded_bytes()
                    ),
                    (1, 1, 2)
                );
            } else {
                assert_eq!(format!("{:?}", decoders[0]), before[0]);
            }
        }
    }

    #[test]
    fn public_multi_uses_prefix_header_budget_and_ignores_sop_sequence_values() {
        let limits = ResourceLimits::default()
            .with_maximum_packet_header_bytes(1)
            .unwrap();
        for sequence in [[0, 0], [0xff, 0xff], [0x12, 0x35]] {
            let data = [0xff, 0x91, 0, 4, sequence[0], sequence[1], 0, 0xff];
            let tile = TilePartPayload::uniform_for_packet_decoding(
                0,
                0,
                1,
                1,
                coding_style(true, false),
                crate::codestream::RoiShifts::none(),
                &data,
            )
            .unwrap();
            let mut states = [code_block_packet_state_new()];
            let mut inclusion = tag_tree_new(1, 1, &ResourceLimits::default()).unwrap();
            let mut zero = tag_tree_new(1, 1, &ResourceLimits::default()).unwrap();
            let contexts = [literal_precinct_header_context()];
            let mut decoders = [one_bit_legacy_decoder(false)];
            assert_eq!(
                decode_multi_code_block_packet(
                    &tile,
                    0,
                    PacketCodeBlockExecution {
                        states: &mut states,
                        inclusion_tree: &mut inclusion,
                        zero_bitplane_tree: &mut zero,
                        contexts: &contexts,
                        decoders: &mut decoders,
                    },
                    &limits
                ),
                Ok(PacketBodyDecode {
                    present: false,
                    code_blocks: 1,
                    contributions: 0,
                    segments: 0,
                    passes: 0,
                    header_bytes: 1,
                    body_bytes: 0,
                    bytes_consumed: 7
                })
            );
        }
    }

    #[test]
    fn real_shared_body_policy_retains_nonzero_local_errors_without_remapping_child_errors() {
        let contribution = one_ff_legacy_contribution();
        let mut cursor = PacketBodyPreflight {
            index: 0,
            end: usize::MAX,
        };
        assert_eq!(
            preflight_packet_body_ranges(&[Some(contribution)], &[], &mut cursor, (71, 29)),
            Err(packet_reader_error(29, MalformedKind::ArithmeticOverflow))
        );
        assert_eq!((cursor.index, cursor.end), (0, usize::MAX));
        let mut execution = PacketBodyExecutionProgress {
            index: 0,
            offset: 0,
            segments: 0,
            passes: 0,
        };
        assert_eq!(
            execute_packet_body_contributions(
                &mut [],
                &[Some(contribution)],
                &[0xff],
                &mut execution,
                (71, 29),
                true,
                &ResourceLimits::default()
            ),
            Err(packet_reader_error(29, MalformedKind::InvalidPacketHeader))
        );
        let mut decoder = [one_bit_legacy_decoder(true)];
        let before = format!("{:?}", decoder[0]);
        assert_eq!(
            execute_packet_body_contributions(
                &mut decoder,
                &[Some(contribution)],
                &[0xff],
                &mut execution,
                (71, 29),
                true,
                &ResourceLimits::default()
            ),
            Err(packet_invalid_code_block())
        );
        assert_eq!(format!("{:?}", decoder[0]), before);
    }

    #[test]
    fn actual_multi_header_slot_commits_raw_owner_state_before_count_and_storage_rejections() {
        let limits = ResourceLimits::default();
        for overflow in [false, true] {
            let mut states = [code_block_packet_state_new()];
            let mut inclusion = tag_tree_new(1, 1, &limits).unwrap();
            let mut zero = tag_tree_new(1, 1, &limits).unwrap();
            let contexts = [literal_precinct_header_context()];
            let mut reader = packet_reader_prefix(&[0xc2], &limits);
            let mut contributions = if overflow { vec![None] } else { Vec::new() };
            let mut progress = MultiHeaderProgress {
                index: 0,
                count: if overflow { u32::MAX } else { 0 },
            };
            assert_eq!(
                read_multi_packet_header_slot(
                    &mut states,
                    &mut inclusion,
                    &mut zero,
                    MultiHeaderParameters {
                        contexts: &contexts,
                        offset: 23
                    },
                    &mut contributions,
                    &mut reader,
                    &mut progress
                ),
                Err(packet_reader_error(
                    23,
                    if overflow {
                        MalformedKind::ArithmeticOverflow
                    } else {
                        MalformedKind::InvalidPacketHeader
                    }
                ))
            );
            assert_eq!((states[0].included(), states[0].total_passes()), (true, 1));
            assert_eq!(
                (reader.byte_index, reader.bits_remaining, reader.bits_read),
                (1, 1, 7)
            );
            assert_eq!(
                (progress.index, progress.count),
                (0, if overflow { u32::MAX } else { 1 })
            );
            assert!(contributions.iter().all(Option::is_none));
            assert_eq!(inclusion.nodes[0], TagTreeNode { low: 0, value: 0 });
            assert_eq!(zero.nodes[0], TagTreeNode { low: 0, value: 0 });
        }
    }

    #[test]
    fn actual_jpip_outer_restores_all_raw_fields_and_clone_preserves_unused_tree_words() {
        let limits = ResourceLimits::default();
        let template = literal_progression_tile(&[], 1, 0, 0, 1);
        for empty_states in [false, true] {
            let mut precinct = literal_ht_progression_precinct(0);
            precinct.contexts[0].layer = 7;
            precinct.subbands[0].inclusion_tree.nodes.push(TagTreeNode {
                low: 19,
                value: u32::MAX,
            });
            precinct.subbands[0]
                .zero_bitplane_tree
                .nodes
                .push(TagTreeNode {
                    low: u32::MAX,
                    value: 23,
                });
            if empty_states {
                precinct.states.clear();
            }
            let before = exact_packet_precinct_snapshot(&precinct);
            let data: &[u8] = if empty_states { &[] } else { &[0xe3] };
            assert!(
                decode_jpip_precinct_packet(&template, data, 0, 0, &mut precinct, &limits).is_err()
            );
            assert_eq!(exact_packet_precinct_snapshot(&precinct), before);
            assert_eq!(
                precinct.subbands[0].inclusion_tree.nodes[1],
                TagTreeNode {
                    low: 19,
                    value: u32::MAX
                }
            );
            assert_eq!(
                precinct.subbands[0].zero_bitplane_tree.nodes[1],
                TagTreeNode {
                    low: u32::MAX,
                    value: 23
                }
            );
        }
        let mut inner = literal_ht_progression_precinct(0);
        inner.states.clear();
        inner.contexts[0].layer = 7;
        assert_eq!(
            decode_jpip_precinct_packet_inner(&template, &[], 0, 0, &mut inner, &limits),
            Err(invalid_packet_header())
        );
        assert_eq!(inner.contexts[0].layer, 0);
    }

    fn literal_ht_progression_precinct(resolution: u8) -> PacketPrecinctDecoder {
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut precinct = literal_packet_precinct();
        precinct.resolution = resolution;
        precinct.contexts[0].tier1_style = style;
        precinct.decoders[0] =
            Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
        precinct
    }

    fn literal_progression_tile(
        data: &[u8],
        layers: u16,
        levels: u8,
        index: u8,
        count: u8,
    ) -> TilePartPayload<'_> {
        let mut style = coding_style(false, false);
        style.layers = layers;
        style.decomposition_levels = levels;
        style.code_block_style = 0x40;
        TilePartPayload::uniform_for_packet_decoding(
            7,
            index,
            count,
            1,
            style,
            crate::codestream::RoiShifts::none(),
            data,
        )
        .unwrap()
    }

    #[test]
    fn full_selected_progression_derives_literal_headers_and_skips_only_higher_resolution_coefficients()
     {
        let limits = ResourceLimits::default();
        let grid =
            packet_grid_new_with_component_resolutions(1, 1, vec![2], vec![1, 1], &limits).unwrap();
        let parts = [literal_progression_tile(
            &[0xe3, 0, 0x63, 0, 0xe3, 0, 0x63, 0],
            1,
            1,
            0,
            1,
        )];
        let mut precincts = [
            literal_ht_progression_precinct(0),
            literal_ht_progression_precinct(1),
        ];
        assert_eq!(
            decode_progression_tile_packets_selected(
                &parts,
                &grid,
                &mut precincts,
                Some(&[1]),
                &limits
            ),
            Ok(TilePacketDecode {
                tile_index: 7,
                tile_parts: 1,
                packets: 2,
                present_packets: 2,
                contributions: 2,
                segments: 1,
                passes: 1,
                packet_header_bytes: 2,
                packet_body_bytes: 6,
                payload_bytes: 8
            })
        );
        assert_eq!(
            precincts[0].decoders[0]
                .plane()
                .signed_coefficient(0, 0)
                .unwrap(),
            -1
        );
        assert_eq!(
            precincts[1].decoders[0]
                .plane()
                .signed_coefficient(0, 0)
                .unwrap(),
            0
        );
        for precinct in &precincts {
            assert!(precinct.states[0].included());
            assert_eq!(precinct.states[0].total_passes(), 1);
            assert_eq!(precinct.states[0].high_throughput(), Some(true));
        }
    }

    #[test]
    fn full_progression_restarts_actual_tile_iterators_and_retains_real_output_on_late_trailing_data()
     {
        let limits = ResourceLimits::default();
        let grid =
            packet_grid_new_with_component_resolutions(2, 1, vec![1], vec![1], &limits).unwrap();
        for trailing in [false, true] {
            let second: &[u8] = if trailing { &[0, 0x55] } else { &[0] };
            let parts = [
                literal_progression_tile(&[0xe3, 0, 0x63, 0], 2, 0, 0, 2),
                literal_progression_tile(second, 2, 0, 1, 2),
            ];
            let mut precincts = [literal_ht_progression_precinct(0)];
            assert_eq!(
                decode_progression_tile_packets(&parts, &grid, &mut precincts, &limits),
                if trailing {
                    Err(packet_reader_error(1, MalformedKind::TrailingData))
                } else {
                    Ok(TilePacketDecode {
                        tile_index: 7,
                        tile_parts: 2,
                        packets: 2,
                        present_packets: 1,
                        contributions: 1,
                        segments: 1,
                        passes: 1,
                        packet_header_bytes: 2,
                        packet_body_bytes: 3,
                        payload_bytes: 5,
                    })
                }
            );
            assert_eq!(
                precincts[0].decoders[0]
                    .plane()
                    .signed_coefficient(0, 0)
                    .unwrap(),
                -1
            );
            assert_eq!(precincts[0].contexts[0].layer, 1);
            assert_eq!(precincts[0].states[0].total_passes(), 1);
        }
    }

    #[test]
    fn actual_progression_work_guard_follows_real_next_and_restart_duplicate_effects() {
        let limits = ResourceLimits::default()
            .with_maximum_work_units(3)
            .unwrap();
        let grid =
            packet_grid_new_with_component_resolutions(2, 1, vec![1], vec![1], &limits).unwrap();
        let parts = [
            literal_progression_tile(&[0], 2, 0, 0, 2),
            literal_progression_tile(&[0], 2, 0, 1, 2),
        ];
        let mut precincts = [literal_ht_progression_precinct(0)];
        let input =
            prepare_progression_tile_input(&parts, &grid, &precincts, None, &limits).unwrap();
        let params = ProgressionTileParameters {
            tile_parts: &parts,
            grid: &grid,
            input: &input,
            selection: None,
            limits: &limits,
        };
        let mut progress = progression_tile_progress_new(&params).unwrap();
        assert_eq!(
            run_progression_tile_packets(&params, &mut precincts, &mut progress),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
        assert_eq!(
            (
                progress.remaining_packets,
                progress.packets,
                progress.current_tile_part,
                progress.offset,
                progress.packed_offset
            ),
            (0, 1, 1, 0, 0)
        );
        assert_eq!(progress.seen, vec![true, false]);
        assert_eq!(progress.iterator.emitted(), 2);
        assert_eq!(precincts[0].contexts[0].layer, 0);
        assert!(!precincts[0].states[0].included());
    }

    #[test]
    fn actual_progression_accounting_keeps_every_ordered_overflow_and_new_offset_error() {
        let limits = ResourceLimits::default();
        let grid = raw_iterator_grid();
        let parts = [literal_progression_tile(&[0], 1, 0, 0, 1)];
        let precincts = [literal_ht_progression_precinct(0)];
        let input =
            prepare_progression_tile_input(&parts, &grid, &precincts, None, &limits).unwrap();
        let params = ProgressionTileParameters {
            tile_parts: &parts,
            grid: &grid,
            input: &input,
            selection: None,
            limits: &limits,
        };
        let decoded = PacketBodyDecode {
            present: true,
            code_blocks: 1,
            contributions: 1,
            segments: 1,
            passes: 1,
            header_bytes: 1,
            body_bytes: 1,
            bytes_consumed: 2,
        };
        for field in 0..7 {
            let mut progress = progression_tile_progress_new(&params).unwrap();
            match field {
                0 => progress.packets = u64::MAX,
                1 => progress.present_packets = u64::MAX,
                2 => progress.contributions = u64::MAX,
                3 => progress.segments = u64::MAX,
                4 => progress.passes = u64::MAX,
                5 => progress.packet_header_bytes = u64::MAX,
                6 => progress.packet_body_bytes = u64::MAX,
                _ => unreachable!(),
            }
            assert_eq!(
                account_progression_packet(&mut progress, decoded, 2, 0, Some(2), 0),
                Err(packet_arithmetic_overflow())
            );
            assert_eq!(progress.offset, 2);
            assert_eq!(progress.seen, vec![field != 0]);
            let actual = [
                progress.packets,
                progress.present_packets,
                progress.contributions,
                progress.segments,
                progress.passes,
                progress.packet_header_bytes,
                progress.packet_body_bytes,
            ];
            for (index, value) in actual.into_iter().enumerate() {
                assert_eq!(
                    value,
                    if index == field {
                        u64::MAX
                    } else {
                        u64::from(index < field)
                    }
                );
            }
        }
        let mut progress = progression_tile_progress_new(&params).unwrap();
        progress.offset = 3;
        progress.packed_offset = usize::MAX;
        assert_eq!(
            account_progression_packet(&mut progress, decoded, 2, 1, Some(2), 0),
            Err(packet_reader_error(5, MalformedKind::ArithmeticOverflow))
        );
        assert_eq!(
            (progress.offset, progress.packed_offset, progress.packets),
            (5, usize::MAX, 0)
        );
        assert_eq!(progress.seen, vec![false]);
    }

    #[test]
    fn full_progression_uses_real_ppt_reassembly_and_plt_iteration_without_tile_body_bytes() {
        fn segment(stream: &mut Vec<u8>, marker: u16, payload: &[u8]) {
            stream.extend_from_slice(&marker.to_be_bytes());
            stream.extend_from_slice(&u16::try_from(payload.len() + 2).unwrap().to_be_bytes());
            stream.extend_from_slice(payload);
        }
        let mut stream = vec![0xff, 0x4f];
        let mut siz = vec![0, 0];
        for value in [1_u32, 1, 0, 0, 1, 1, 0, 0] {
            siz.extend_from_slice(&value.to_be_bytes());
        }
        siz.extend_from_slice(&[0, 1, 7, 1, 1]);
        segment(&mut stream, 0xff51, &siz);
        segment(&mut stream, 0xff52, &[0, 0, 0, 1, 0, 0, 0, 0, 0, 1]);
        segment(&mut stream, 0xff5c, &[0x20, 0]);
        segment(&mut stream, 0xff90, &[0, 0, 0, 0, 0, 26, 0, 1]);
        segment(&mut stream, 0xff58, &[0, 1]);
        segment(&mut stream, 0xff61, &[0, 0]);
        stream.extend_from_slice(&[0xff, 0x93, 0xff, 0xd9]);
        let limits = ResourceLimits::default();
        let layout = crate::codestream::parse_layout(&stream, &limits).unwrap();
        assert_eq!(layout.tile_parts.len(), 1);
        assert!(layout.tile_parts[0].data.is_empty());
        assert!(layout.tile_parts[0].packed_packet_headers.is_present());
        assert!(layout.tile_parts[0].packet_lengths.is_present());
        let grid =
            packet_grid_new_with_component_resolutions(1, 1, vec![1], vec![1], &limits).unwrap();
        let mut precincts = [literal_packet_precinct()];
        assert_eq!(
            decode_progression_tile_packets(&layout.tile_parts, &grid, &mut precincts, &limits),
            Ok(TilePacketDecode {
                tile_index: 0,
                tile_parts: 1,
                packets: 1,
                present_packets: 0,
                contributions: 0,
                segments: 0,
                passes: 0,
                packet_header_bytes: 1,
                packet_body_bytes: 0,
                payload_bytes: 0
            })
        );
        assert!(!precincts[0].states[0].included());
        assert_eq!(
            precincts[0].decoders[0]
                .plane()
                .signed_coefficient(0, 0)
                .unwrap(),
            0
        );
        let template = &layout.tile_parts[0];
        let template_before = format!("{template:?}");
        let mut inline = literal_packet_precinct();
        inline.contexts[0].layer = 9;
        let decoder_before = format!("{:?}", inline.decoders[0]);
        assert_eq!(
            decode_jpip_precinct_packet(template, &[0xe1, 0xff], 0, 0, &mut inline, &limits),
            Ok(2)
        );
        assert!(inline.states[0].included());
        assert_eq!(
            (inline.states[0].total_passes(), inline.contexts[0].layer),
            (1, 0)
        );
        assert_eq!(format!("{:?}", inline.decoders[0]), decoder_before);
        assert_eq!(format!("{template:?}"), template_before);
    }

    fn raw_iterator_grid() -> PacketGrid {
        PacketGrid {
            layers: 1,
            components: 1,
            resolutions: 1,
            component_resolutions: vec![1],
            maximum_precincts_per_resolution: 1,
            precinct_counts: vec![1],
            precinct_offsets: vec![0, 1],
            candidate_count: 1,
            packet_count: 1,
        }
    }

    #[test]
    fn raw_grid_lookup_retains_physical_zero_and_offset_error_priority() {
        let invalid = packet_reader_error(0, MalformedKind::InvalidCodingStyle);
        let mut grid = raw_iterator_grid();
        grid.component_resolutions.clear();
        grid.precinct_counts.clear();
        grid.precinct_offsets.clear();
        assert_eq!(grid.precinct_count(0, 0), Err(invalid));
        grid.component_resolutions.push(0);
        assert_eq!(grid.precinct_count(0, 0), Ok(0));
        assert_eq!(grid.precinct_index(0, 0, 0), Err(invalid));
        grid.component_resolutions[0] = 1;
        assert_eq!(grid.precinct_count(0, 0), Err(invalid));
        grid.precinct_counts.push(2);
        assert_eq!(grid.precinct_index(0, 0, 1), Err(invalid));
        grid.precinct_offsets.push(usize::MAX);
        assert_eq!(grid.precinct_index(0, 0, 0), Ok(usize::MAX));
        assert_eq!(
            grid.precinct_index(0, 0, 1),
            Err(packet_arithmetic_overflow())
        );
        grid.layers = 0;
        assert_eq!(
            grid.total_precinct_count(),
            Err(packet_arithmetic_overflow())
        );
        assert_eq!(grid.selected_packet_count(&[1]), Ok(0));
    }

    #[test]
    fn actual_grid_factory_keeps_full_offsets_and_candidate_work_under_selected_caps() {
        let limits = ResourceLimits::default()
            .with_maximum_packets(10)
            .unwrap()
            .with_maximum_work_units(32)
            .unwrap();
        let grid = packet_grid_new_with_selected_resolutions(
            2,
            2,
            vec![1, 2],
            vec![2, 0, 3, 4],
            Some(&[1, 1]),
            &limits,
        )
        .unwrap();
        assert_eq!((grid.layers, grid.components, grid.resolutions), (2, 2, 2));
        assert_eq!(grid.component_resolutions, vec![1, 2]);
        assert_eq!(grid.precinct_counts, vec![2, 0, 3, 4]);
        assert_eq!(grid.precinct_offsets, vec![0, 2, 2, 5, 9]);
        assert_eq!(
            (
                grid.maximum_precincts_per_resolution,
                grid.candidate_count,
                grid.packet_count
            ),
            (4, 32, 18)
        );
        assert_eq!(grid.selected_packet_count(&[1, 1]), Ok(10));
        let work_limited = limits.with_maximum_work_units(31).unwrap();
        assert!(matches!(
            packet_grid_new_with_selected_resolutions(
                2,
                2,
                vec![1, 2],
                vec![2, 0, 3, 4],
                Some(&[1, 1]),
                &work_limited,
            ),
            Err(DecodeError::LimitExceeded {
                resource: Resource::WorkUnits,
                limit: 31,
                actual: 32
            })
        ));
        assert!(matches!(
            packet_grid_new_with_selected_resolutions(
                2,
                2,
                vec![1, 2],
                vec![2, 1, 3, 4],
                Some(&[1, 1]),
                &work_limited,
            ),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodingStyle
            })
        ));
        assert!(matches!(
            packet_grid_new_with_selected_resolutions(
                2,
                2,
                vec![1, 2],
                vec![2, 0, 3, 4],
                None,
                &limits,
            ),
            Err(DecodeError::LimitExceeded {
                resource: Resource::Packets,
                limit: 10,
                actual: 18
            })
        ));
    }

    #[test]
    fn raw_packet_iterator_retains_advanced_candidate_and_late_emitted_errors() {
        for case in 0..5 {
            let mut grid = raw_iterator_grid();
            match case {
                0 => grid.maximum_precincts_per_resolution = 0,
                1 => grid.component_resolutions.clear(),
                2 => grid.packet_count = 0,
                3 => {}
                4 => {
                    grid.components = 2;
                    grid.candidate_count = 2;
                    grid.component_resolutions = vec![1, 1];
                    grid.precinct_counts = vec![0];
                }
                _ => unreachable!(),
            }
            let before = grid.clone();
            let mut iterator = packet_iterator_new(&grid, ProgressionOrder::Lrcp);
            if case == 3 {
                iterator.emitted = u64::MAX;
            }
            assert_eq!(
                iterator.next_packet(),
                Err(if case == 2 || case == 3 {
                    packet_arithmetic_overflow()
                } else {
                    packet_reader_error(0, MalformedKind::InvalidCodingStyle)
                })
            );
            assert_eq!(iterator.candidate_index, if case == 4 { 2 } else { 1 });
            assert_eq!(
                iterator.emitted,
                match case {
                    2 => 1,
                    3 => u64::MAX,
                    _ => 0,
                }
            );
            assert_eq!(*iterator.grid, before);
        }
        let grid = raw_iterator_grid();
        let mut iterator = packet_iterator_new(&grid, ProgressionOrder::Cprl);
        iterator.candidate_index = u64::MAX;
        iterator.emitted = u64::MAX;
        assert_eq!(iterator.next_packet(), Ok(None));
        assert_eq!(
            (iterator.candidate_index, iterator.emitted),
            (u64::MAX, u64::MAX)
        );
    }

    #[test]
    fn raw_poc_inverted_component_count_and_decode_keep_distinct_native_policies() {
        let grid = raw_iterator_grid();
        let mut record = ProgressionChange {
            resolution_start: 0,
            component_start: 2,
            layer_end: u16::MAX,
            resolution_end: u8::MAX,
            component_end: 1,
            progression_order: ProgressionOrder::Lrcp,
        };
        assert_eq!(window_candidate_count(&grid, record), Ok(0));
        assert_eq!(
            decode_window_candidate(&grid, record, 0),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
        record.component_end = 3;
        record.resolution_start = 2;
        record.resolution_end = 1;
        assert_eq!(
            window_candidate_count(&grid, record),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
        assert_eq!(
            decode_window_candidate(&grid, record, 0),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
    }

    fn literal_progression_window() -> ProgressionChange {
        ProgressionChange {
            resolution_start: 0,
            component_start: 0,
            layer_end: 1,
            resolution_end: 1,
            component_end: 1,
            progression_order: ProgressionOrder::Lrcp,
        }
    }

    #[test]
    fn raw_progression_default_error_commits_nested_state_without_syncing_outer_emitted() {
        let mut grid = raw_iterator_grid();
        grid.packet_count = 0;
        let changes = ProgressionChanges::none();
        let mut iterator = progression_packet_iterator_new(
            &grid,
            ProgressionOrder::Lrcp,
            &changes,
            &ResourceLimits::default(),
        )
        .unwrap();
        iterator.emitted = 17;
        assert_eq!(iterator.next_packet(), Err(packet_arithmetic_overflow()));
        assert_eq!(iterator.emitted, 17);
        let default = iterator.default.as_ref().unwrap();
        assert_eq!((default.candidate_index, default.emitted), (1, 1));
        assert_eq!(
            (
                iterator.window_index,
                iterator.window_candidate,
                iterator.window_candidates
            ),
            (0, 0, 0)
        );
    }

    #[test]
    fn raw_progression_window_advance_retains_partial_cursor_before_next_window_rejection() {
        let grid = raw_iterator_grid();
        let good = literal_progression_window();
        let bad = ProgressionChange {
            resolution_start: 2,
            ..good
        };
        let changes = ProgressionChanges::from_records(vec![good, bad]);
        let mut iterator = ProgressionPacketIterator {
            grid: &grid,
            changes: &changes,
            default: None,
            window_index: 0,
            window_candidate: 5,
            window_candidates: 5,
            emitted: 0,
        };
        assert_eq!(
            iterator.next_packet(),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
        assert_eq!(
            (
                iterator.window_index,
                iterator.window_candidate,
                iterator.window_candidates,
                iterator.emitted
            ),
            (1, 0, 5, 0)
        );
        let empty = ProgressionChanges::none();
        iterator.changes = &empty;
        iterator.window_index = 3;
        iterator.window_candidate = 0;
        let record = literal_progression_window();
        assert_eq!(
            iterator.candidate_step(record),
            Err(packet_reader_error(
                0,
                MalformedKind::InvalidProgressionOrderChange
            ))
        );
        assert_eq!(
            (
                iterator.window_index,
                iterator.window_candidate,
                iterator.window_candidates,
                iterator.emitted
            ),
            (3, 1, 5, 0)
        );
    }

    #[test]
    fn actual_progression_constructor_charges_duplicate_windows_and_next_suppresses_only_prior_membership()
     {
        let grid = raw_iterator_grid();
        let record = literal_progression_window();
        let changes = ProgressionChanges::from_records(vec![record, record]);
        let limited = ResourceLimits::default()
            .with_maximum_work_units(1)
            .unwrap();
        assert!(matches!(
            progression_packet_iterator_new(&grid, ProgressionOrder::Cprl, &changes, &limited),
            Err(DecodeError::LimitExceeded {
                resource: Resource::WorkUnits,
                limit: 1,
                actual: 2
            })
        ));
        let limits = ResourceLimits::default()
            .with_maximum_work_units(2)
            .unwrap();
        let mut iterator =
            progression_packet_iterator_new(&grid, ProgressionOrder::Cprl, &changes, &limits)
                .unwrap();
        assert_eq!(
            iterator.next_packet(),
            Ok(Some(PacketCoordinate {
                layer: 0,
                resolution: 0,
                component: 0,
                precinct: 0
            }))
        );
        assert_eq!(
            (
                iterator.window_index,
                iterator.window_candidate,
                iterator.window_candidates,
                iterator.emitted
            ),
            (0, 1, 1, 1)
        );
        assert_eq!(iterator.next_packet(), Ok(None));
        assert_eq!(
            (
                iterator.window_index,
                iterator.window_candidate,
                iterator.window_candidates,
                iterator.emitted
            ),
            (2, 0, 0, 1)
        );
        assert_eq!(iterator.next_packet(), Ok(None));
    }

    fn literal_payload_parameters() -> PrecinctPayloadParameters {
        PrecinctPayloadParameters {
            error_offset: 21,
            packed_offset: 0,
            expected_packet_length: None,
            expected_sop_sequence: 0x1234,
            style: Tier1CodingStyle::default(),
            sop: false,
            eph: false,
            packed: false,
            decode_tier1: true,
        }
    }

    #[test]
    fn precinct_payload_prefix_checks_actual_markers_before_packed_ranges_and_budgets() {
        let limits = ResourceLimits::default()
            .with_maximum_work_units(1)
            .unwrap();
        let mut parameters = literal_payload_parameters();
        parameters.sop = true;
        parameters.packed = true;
        parameters.packed_offset = usize::MAX;
        for (data, kind) in [
            (&[][..], MalformedKind::Truncated),
            (&[0xff, 0x91, 0][..], MalformedKind::Truncated),
            (&[0, 0x91, 0, 4][..], MalformedKind::InvalidPacketHeader),
            (&[0xff, 0x91, 0, 4][..], MalformedKind::Truncated),
            (
                &[0xff, 0x91, 0, 4, 0x12, 0x35][..],
                MalformedKind::InvalidPacketHeader,
            ),
        ] {
            assert!(matches!(
                decode_precinct_packet_payload_prefix(data, &[], parameters, &limits),
                Err(DecodeError::MalformedInput { offset, kind: actual })
                    if actual == kind && offset == if kind == MalformedKind::Truncated { 21 } else { 0 }
            ));
        }
        let data = [0xff, 0x91, 0, 4, 0x12, 0x34, 0x80];
        assert!(matches!(
            decode_precinct_packet_payload_prefix(&data, &[], parameters, &limits),
            Err(DecodeError::MalformedInput { offset, kind: MalformedKind::Truncated })
                if offset == usize::MAX as u64
        ));
        for packed in [false, true] {
            parameters.packed = packed;
            parameters.packed_offset = 1;
            let prefix =
                decode_precinct_packet_payload_prefix(&data, &[0xaa, 0x80], parameters, &limits)
                    .unwrap();
            assert!(prefix.present);
            assert_eq!(prefix.sop_bytes, 6);
            assert_eq!(prefix.packet_data, &[0x80]);
            assert_eq!(prefix.reader.input, &[0x80]);
            assert_eq!(
                (
                    prefix.reader.byte_index,
                    prefix.reader.bits_remaining,
                    prefix.reader.current_byte,
                    prefix.reader.previous_byte_was_ff,
                    prefix.reader.bits_read,
                ),
                (1, 7, 0x80, false, 1)
            );
        }
    }

    #[test]
    fn precinct_payload_literal_inline_and_packed_streams_account_for_markers_and_real_coefficients()
     {
        let limits = ResourceLimits::default();
        for packed in [false, true] {
            for decode_tier1 in [false, true] {
                let mut precinct = literal_packet_precinct();
                let mut parameters = literal_payload_parameters();
                parameters.packed = packed;
                parameters.sop = true;
                parameters.eph = true;
                parameters.packed_offset = 1;
                parameters.expected_packet_length = Some(10);
                parameters.decode_tier1 = decode_tier1;
                let inline = [0xff, 0x91, 0, 4, 0x12, 0x34, 0xe1, 0xff, 0x92, 0xff];
                let packed_body = [0xff, 0x91, 0, 4, 0x12, 0x34, 0xff];
                let data: &[u8] = if packed { &packed_body } else { &inline };
                assert_eq!(
                    decode_precinct_packet_payload(
                        data,
                        &[0xaa, 0xe1, 0xff, 0x92],
                        parameters,
                        &mut precinct,
                        &limits,
                    ),
                    Ok((
                        PacketBodyDecode {
                            present: true,
                            code_blocks: 1,
                            contributions: 1,
                            segments: u32::from(decode_tier1),
                            passes: u32::from(decode_tier1),
                            header_bytes: 1,
                            body_bytes: 1,
                            bytes_consumed: 10,
                        },
                        if packed { 7 } else { 10 },
                        if packed { 3 } else { 0 },
                    ))
                );
                assert_eq!(precinct.states[0].total_passes(), 1);
                assert!(precinct.states[0].included());
                assert_eq!(
                    precinct.decoders[0]
                        .plane()
                        .signed_coefficient(0, 0)
                        .unwrap(),
                    0
                );
                assert_eq!(precinct.decoders[0].next_pass(), u32::from(decode_tier1));
                assert_eq!(
                    precinct.decoders[0].decoded_segments(),
                    u32::from(decode_tier1)
                );
            }
        }
    }

    #[test]
    fn precinct_payload_errors_retain_exact_header_and_late_coefficient_effects() {
        let limits = ResourceLimits::default();
        for (data, eph, expected, error, coefficient) in [
            (&[0xe1][..], false, None, MalformedKind::Truncated, 0),
            (
                &[0xe1, 0xff, 0x93, 0xff][..],
                true,
                None,
                MalformedKind::InvalidPacketHeader,
                0,
            ),
            (
                &[0xe1, 0xff][..],
                false,
                Some(3),
                MalformedKind::InvalidPacketLength,
                0,
            ),
        ] {
            let mut precinct = literal_packet_precinct();
            let mut parameters = literal_payload_parameters();
            parameters.eph = eph;
            parameters.expected_packet_length = expected;
            assert_eq!(
                decode_precinct_packet_payload(data, &[], parameters, &mut precinct, &limits),
                Err(DecodeError::MalformedInput {
                    offset: if error == MalformedKind::InvalidPacketHeader {
                        0
                    } else {
                        21
                    },
                    kind: error,
                })
            );
            assert_eq!(precinct.states[0].total_passes(), 1);
            assert_eq!(precinct.states[0].zero_bitplanes(), Some(0));
            assert!(precinct.states[0].included());
            for tree in [
                &precinct.subbands[0].inclusion_tree,
                &precinct.subbands[0].zero_bitplane_tree,
            ] {
                assert_eq!(tree.nodes[0], TagTreeNode { low: 0, value: 0 });
            }
            assert_eq!(
                precinct.decoders[0]
                    .plane()
                    .signed_coefficient(0, 0)
                    .unwrap(),
                coefficient
            );
            assert_eq!(
                precinct.decoders[0].next_pass(),
                u32::from(expected.is_some())
            );
            assert_eq!(
                (precinct.component, precinct.resolution, precinct.precinct),
                (0, 0, 0)
            );
        }
    }

    #[test]
    fn actual_precinct_wrapper_commits_literal_ht_cleanup_before_late_length_mismatch() {
        let limits = ResourceLimits::default();
        let mut style = coding_style(false, false);
        style.code_block_style = 0x40;
        let ht_style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let tile = TilePartPayload::uniform_for_packet_decoding(
            0,
            0,
            1,
            1,
            style,
            crate::codestream::RoiShifts::none(),
            &[0xe3, 0, 0x63, 0],
        )
        .unwrap();
        for expected in [4, 5] {
            let mut precinct = literal_packet_precinct();
            precinct.contexts[0].tier1_style = ht_style;
            precinct.decoders[0] =
                Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, ht_style).unwrap();
            let result = decode_precinct_packet(
                &tile,
                0,
                &[],
                0,
                Some(expected),
                0,
                &mut precinct,
                true,
                &limits,
            );
            assert_eq!(
                result,
                if expected == 4 {
                    Ok((
                        PacketBodyDecode {
                            present: true,
                            code_blocks: 1,
                            contributions: 1,
                            segments: 1,
                            passes: 1,
                            header_bytes: 1,
                            body_bytes: 3,
                            bytes_consumed: 4,
                        },
                        4,
                        0,
                    ))
                } else {
                    Err(DecodeError::MalformedInput {
                        offset: 0,
                        kind: MalformedKind::InvalidPacketLength,
                    })
                }
            );
            assert_eq!(precinct.states[0].total_passes(), 1);
            assert_eq!(precinct.states[0].high_throughput(), Some(true));
            assert_eq!(
                precinct.decoders[0]
                    .plane()
                    .signed_coefficient(0, 0)
                    .unwrap(),
                -1
            );
            assert_eq!(precinct.decoders[0].next_pass(), 1);
        }
    }

    #[test]
    fn actual_precinct_wrapper_preserves_shape_cap_offset_and_component_error_priority() {
        let limits = ResourceLimits::default();
        let tile = TilePartPayload::uniform_for_packet_decoding(
            0,
            0,
            1,
            1,
            coding_style(true, true),
            crate::codestream::RoiShifts::none(),
            &[],
        )
        .unwrap();
        let mut precinct = literal_packet_precinct();
        precinct.component = 1;
        precinct.contexts.clear();
        assert_eq!(
            decode_precinct_packet(&tile, 7, &[], 0, None, 0, &mut precinct, true, &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidPacketHeader
            })
        );
        precinct.contexts.push(literal_precinct_header_context());
        let mut second = literal_packet_precinct();
        precinct.states.append(&mut second.states);
        precinct.contexts.append(&mut second.contexts);
        precinct.decoders.append(&mut second.decoders);
        let limited = limits.with_maximum_code_blocks(1).unwrap();
        assert_eq!(
            decode_precinct_packet(&tile, 7, &[], 0, None, 0, &mut precinct, true, &limited),
            Err(DecodeError::LimitExceeded {
                resource: Resource::CodeBlocks,
                limit: 1,
                actual: 2
            })
        );
        precinct.states.pop();
        precinct.contexts.pop();
        precinct.decoders.pop();
        assert_eq!(
            decode_precinct_packet(&tile, 7, &[], 0, None, 0, &mut precinct, true, &limits),
            Err(DecodeError::MalformedInput {
                offset: 7,
                kind: MalformedKind::InvalidPacketLength
            })
        );
        assert_eq!(
            decode_precinct_packet(&tile, 0, &[], 0, None, 0, &mut precinct, true, &limits),
            Err(DecodeError::MalformedInput {
                offset: 0,
                kind: MalformedKind::InvalidCodingStyle
            })
        );
        assert!(!precinct.states[0].included());
        assert_eq!(precinct.states[0].total_passes(), 0);
        assert_eq!(
            precinct.decoders[0]
                .plane()
                .signed_coefficient(0, 0)
                .unwrap(),
            0
        );
    }

    #[test]
    fn precinct_headers_associate_real_bits_and_preserve_overlapping_raw_subbands() {
        let limits = ResourceLimits::default();
        for repeated in [false, true] {
            let mut states = [code_block_packet_state_new()];
            let contexts = [literal_precinct_header_context()];
            let mut subbands = vec![literal_header_subband()];
            if repeated {
                subbands.push(literal_header_subband());
            }
            let mut contributions = [None];
            let bytes: &[u8] = if repeated { &[0xc3, 0] } else { &[0xc2] };
            let mut reader = packet_reader_prefix(bytes, &limits);
            let mut progress = PrecinctHeaderProgress {
                subband_index: 0,
                local_index: 0,
                contribution_count: 0,
            };
            decode_precinct_contribution_headers(
                &mut states,
                &contexts,
                &mut subbands,
                &mut contributions,
                &mut reader,
                PrecinctHeaderParameters {
                    layer: 0,
                    style: Tier1CodingStyle::default(),
                },
                &mut progress,
            )
            .unwrap();
            let count = if repeated { 2 } else { 1 };
            assert_eq!(
                (
                    progress.subband_index,
                    progress.local_index,
                    progress.contribution_count
                ),
                (count as usize, 1, count)
            );
            assert_eq!(
                states[0],
                CodeBlockPacketState {
                    included: true,
                    zero_bitplanes: Some(0),
                    lblock: 3,
                    total_passes: count,
                    high_throughput: Some(false),
                }
            );
            let header = contributions[0].unwrap();
            assert_eq!(
                (
                    header.first_inclusion,
                    header.zero_bitplanes,
                    header.new_passes,
                    header.data_length,
                    header.high_throughput,
                    header.segment_count
                ),
                (!repeated, 0, 1, if repeated { 0 } else { 1 }, false, 1)
            );
            assert_eq!(header.segment_passes[0], 1);
            assert_eq!(header.segment_lengths[0], if repeated { 0 } else { 1 });
            assert!(header.segment_passes[1..].iter().all(|value| *value == 0));
            assert!(header.segment_lengths[1..].iter().all(|value| *value == 0));
            assert_eq!(
                (reader.byte_index, reader.bits_remaining, reader.bits_read),
                if repeated { (2, 3, 13) } else { (1, 1, 7) }
            );
            assert_eq!(
                subbands[0].inclusion_tree.nodes[0],
                TagTreeNode { low: 0, value: 0 }
            );
            assert_eq!(
                subbands[0].zero_bitplane_tree.nodes[0],
                TagTreeNode { low: 0, value: 0 }
            );
            if repeated {
                assert_eq!(
                    subbands[1].inclusion_tree.nodes[0],
                    TagTreeNode {
                        low: 0,
                        value: u32::MAX
                    }
                );
                assert_eq!(
                    subbands[1].zero_bitplane_tree.nodes[0],
                    TagTreeNode {
                        low: 0,
                        value: u32::MAX
                    }
                );
            }
        }
    }

    #[test]
    fn precinct_headers_keep_committed_header_before_late_count_or_slot_failure() {
        let limits = ResourceLimits::default();
        for overflow in [false, true] {
            let mut states = [code_block_packet_state_new()];
            let contexts = [literal_precinct_header_context()];
            let mut subbands = [literal_header_subband()];
            let mut contributions = vec![None; usize::from(overflow)];
            let mut reader = packet_reader_prefix(&[0xc2], &limits);
            let mut progress = PrecinctHeaderProgress {
                subband_index: 0,
                local_index: 0,
                contribution_count: if overflow { u32::MAX } else { 0 },
            };
            assert_eq!(
                decode_precinct_contribution_headers(
                    &mut states,
                    &contexts,
                    &mut subbands,
                    &mut contributions,
                    &mut reader,
                    PrecinctHeaderParameters {
                        layer: 0,
                        style: Tier1CodingStyle::default()
                    },
                    &mut progress,
                ),
                Err(if overflow {
                    packet_arithmetic_overflow()
                } else {
                    invalid_packet_header()
                })
            );
            assert_eq!(
                (
                    progress.subband_index,
                    progress.local_index,
                    progress.contribution_count
                ),
                (0, 0, if overflow { u32::MAX } else { 1 })
            );
            assert_eq!(states[0].total_passes, 1);
            assert!(states[0].included);
            assert_eq!(states[0].zero_bitplanes, Some(0));
            assert_eq!(
                (reader.byte_index, reader.bits_remaining, reader.bits_read),
                (1, 1, 7)
            );
            assert!(contributions.iter().all(Option::is_none));
            assert_eq!(
                subbands[0].inclusion_tree.nodes[0],
                TagTreeNode { low: 0, value: 0 }
            );
            assert_eq!(
                subbands[0].zero_bitplane_tree.nodes[0],
                TagTreeNode { low: 0, value: 0 }
            );
        }
    }

    fn literal_precinct_body_descriptors() -> [Option<CodeBlockContribution>; 3] {
        let mut ht = one_ff_legacy_contribution();
        ht.high_throughput = true;
        ht.data_length = 3;
        ht.segment_lengths[0] = 3;
        [Some(ht), None, Some(one_ff_legacy_contribution())]
    }

    #[test]
    fn precinct_body_preflight_reports_exact_cursor_before_any_execution() {
        let contributions = literal_precinct_body_descriptors();
        for (data, expected_end, expected_index, expected_result) in [
            (&[0, 0x63, 0, 0xff][..], 4, 3, Ok(())),
            (
                &[0, 0x63, 0][..],
                4,
                2,
                Err(DecodeError::MalformedInput {
                    offset: 71,
                    kind: MalformedKind::Truncated,
                }),
            ),
        ] {
            let mut cursor = PacketBodyPreflight { index: 0, end: 0 };
            assert_eq!(
                preflight_packet_body_ranges(&contributions, data, &mut cursor, (71, 0)),
                expected_result
            );
            assert_eq!((cursor.index, cursor.end), (expected_index, expected_end));
        }
        let mut cursor = PacketBodyPreflight {
            index: 0,
            end: usize::MAX,
        };
        assert_eq!(
            preflight_packet_body_ranges(&contributions, &[], &mut cursor, (71, 0)),
            Err(packet_arithmetic_overflow())
        );
        assert_eq!((cursor.index, cursor.end), (0, usize::MAX));
        let mut cursor = PacketBodyPreflight {
            index: usize::MAX,
            end: 19,
        };
        assert_eq!(
            preflight_packet_body_ranges(&contributions, &[], &mut cursor, (71, 0)),
            Ok(())
        );
        assert_eq!((cursor.index, cursor.end), (usize::MAX, 19));
    }

    #[test]
    fn precinct_skipped_execution_consumes_ranges_without_decoder_shape_or_counter_changes() {
        let contributions = literal_precinct_body_descriptors();
        for (data, expected_offset, expected_index, expected_result) in [
            (&[0, 0x63, 0, 0xff][..], 4, 3, Ok(())),
            (
                &[0, 0x63, 0][..],
                3,
                2,
                Err(DecodeError::MalformedInput {
                    offset: 71,
                    kind: MalformedKind::Truncated,
                }),
            ),
        ] {
            let mut progress = PacketBodyExecutionProgress {
                index: 0,
                offset: 0,
                segments: u32::MAX,
                passes: u32::MAX,
            };
            assert_eq!(
                execute_packet_body_contributions(
                    &mut [],
                    &contributions,
                    data,
                    &mut progress,
                    (71, 0),
                    false,
                    &ResourceLimits::default(),
                ),
                expected_result
            );
            assert_eq!(
                (
                    progress.index,
                    progress.offset,
                    progress.segments,
                    progress.passes
                ),
                (expected_index, expected_offset, u32::MAX, u32::MAX)
            );
        }
    }

    #[test]
    fn precinct_execution_retains_real_prior_coefficients_and_late_partial_counters() {
        let contributions = literal_precinct_body_descriptors();
        let data = [0, 0x63, 0, 0xff];
        let style = Tier1CodingStyle::from_code_block_style(0xc0).unwrap();
        let decoder =
            || Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
        let mut decoders = vec![decoder()];
        let mut progress = PacketBodyExecutionProgress {
            index: 0,
            offset: 0,
            segments: 0,
            passes: 0,
        };
        assert_eq!(
            execute_packet_body_contributions(
                &mut decoders,
                &contributions,
                &data,
                &mut progress,
                (71, 0),
                true,
                &ResourceLimits::default(),
            ),
            Err(invalid_packet_header())
        );
        assert_eq!(
            (
                progress.index,
                progress.offset,
                progress.segments,
                progress.passes
            ),
            (2, 3, 1, 1)
        );
        assert_eq!(decoders[0].plane().signed_coefficient(0, 0).unwrap(), -1);
        assert_eq!(
            (decoders[0].next_pass(), decoders[0].decoded_bytes()),
            (1, 3)
        );
        for (segments, passes, expected_segments) in [(u32::MAX, 7, u32::MAX), (9, u32::MAX, 10)] {
            let mut decoders = vec![decoder()];
            let mut progress = PacketBodyExecutionProgress {
                index: 0,
                offset: 0,
                segments,
                passes,
            };
            assert_eq!(
                execute_packet_body_contributions(
                    &mut decoders,
                    &contributions,
                    &data,
                    &mut progress,
                    (71, 0),
                    true,
                    &ResourceLimits::default(),
                ),
                Err(packet_arithmetic_overflow())
            );
            assert_eq!(
                (
                    progress.index,
                    progress.offset,
                    progress.segments,
                    progress.passes
                ),
                (0, 0, expected_segments, passes)
            );
            assert_eq!(decoders[0].plane().signed_coefficient(0, 0).unwrap(), -1);
            assert_eq!(
                (
                    decoders[0].next_pass(),
                    decoders[0].decoded_segments(),
                    decoders[0].decoded_bytes()
                ),
                (1, 1, 3)
            );
        }
    }

    fn one_ff_legacy_contribution() -> CodeBlockContribution {
        let mut contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 1,
            high_throughput: false,
            segment_count: 1,
            segment_passes: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
            segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
        };
        contribution.segment_passes[0] = 1;
        contribution.segment_lengths[0] = 1;
        contribution
    }

    fn one_bit_legacy_decoder(force_high_throughput: bool) -> Tier1CodeBlockDecoder {
        Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle {
                force_high_throughput,
                ..Tier1CodingStyle::default()
            },
        )
        .unwrap()
    }

    fn expected_one_ff_decoder(before: &Tier1CodeBlockDecoder, header_prepared: bool) -> String {
        let mut contexts = crate::mq::MqDecoder::new(&[], &ResourceLimits::default()).unwrap();
        for index in 0..19 {
            contexts
                .set_context(
                    index,
                    match index {
                        0 => 5,
                        17 => 3,
                        18 => 46,
                        _ => 0,
                    },
                    false,
                )
                .unwrap();
        }
        let mut expected = format!("{before:?}")
            .replacen("next_pass: 0,", "next_pass: 1,", 1)
            .replacen("decoded_segments: 0,", "decoded_segments: 1,", 1)
            .replacen("decoded_bytes: 0,", "decoded_bytes: 1,", 1)
            .replacen("legacy_decode_work: 0,", "legacy_decode_work: 2,", 1)
            .replacen(
                "mq_context_state: None,",
                &format!("mq_context_state: Some({:?}),", contexts.context_state()),
                1,
            );
        if header_prepared {
            expected = expected.replacen("zero_bitplanes: None,", "zero_bitplanes: Some(0),", 1);
        }
        expected
    }

    #[test]
    fn legacy_packet_body_routes_real_mq_bytes_and_retains_late_total_error_mutations() {
        for mismatch in 0..3 {
            let mut decoder = one_bit_legacy_decoder(false);
            let expected = expected_one_ff_decoder(&decoder, false);
            let mut contribution = one_ff_legacy_contribution();
            let body: &[u8] = if mismatch == 2 { &[0xff, 0] } else { &[0xff] };
            if mismatch == 1 {
                contribution.new_passes = 2;
            }
            let result = decode_legacy_code_block_contribution_body(
                &mut decoder,
                &contribution,
                body,
                &ResourceLimits::default(),
            );
            assert_eq!(format!("{decoder:?}"), expected);
            assert_eq!(
                result,
                if mismatch == 0 {
                    Ok(CodeBlockBodyDecode {
                        segments: 1,
                        passes: 1,
                        bytes: 1,
                    })
                } else {
                    Err(packet_invalid_code_block())
                }
            );
        }
        let mut decoder = one_bit_legacy_decoder(false);
        let before = format!("{decoder:?}");
        let mut contribution = one_ff_legacy_contribution();
        contribution.segment_count = 0;
        contribution.new_passes = 0;
        contribution.data_length = u32::MAX;
        contribution.high_throughput = true;
        assert_eq!(
            decode_legacy_code_block_contribution_body(
                &mut decoder,
                &contribution,
                &[],
                &ResourceLimits::default(),
            ),
            Ok(CodeBlockBodyDecode {
                segments: 0,
                passes: 0,
                bytes: u32::MAX
            })
        );
        assert_eq!(format!("{decoder:?}"), before);
    }

    #[test]
    fn legacy_packet_segment_checks_real_range_and_counter_priority_without_input_invariants() {
        let limits = ResourceLimits::default();
        let mut contribution = one_ff_legacy_contribution();
        for offset in [0, usize::MAX] {
            let mut decoder = one_bit_legacy_decoder(false);
            let before = format!("{decoder:?}");
            let expected_decoded = expected_one_ff_decoder(&decoder, false);
            let mut index = 0;
            let mut current_offset = offset;
            let mut passes = u32::MAX;
            assert_eq!(
                decode_legacy_code_block_segment(
                    &mut decoder,
                    &contribution,
                    &[0xff],
                    &limits,
                    &mut index,
                    &mut current_offset,
                    &mut passes,
                ),
                Err(packet_arithmetic_overflow())
            );
            assert_eq!((index, current_offset, passes), (0, offset, u32::MAX));
            assert_eq!(
                format!("{decoder:?}"),
                if offset == 0 {
                    expected_decoded
                } else {
                    before
                }
            );
        }
        contribution.segment_count = u8::MAX;
        let mut decoder = one_bit_legacy_decoder(false);
        let before = format!("{decoder:?}");
        let (mut index, mut offset, mut passes) = (164, usize::MAX, u32::MAX);
        assert_eq!(
            decode_legacy_code_block_segment(
                &mut decoder,
                &contribution,
                &[],
                &limits,
                &mut index,
                &mut offset,
                &mut passes,
            ),
            Err(invalid_packet_header())
        );
        assert_eq!((index, offset, passes), (164, usize::MAX, u32::MAX));
        assert_eq!(format!("{decoder:?}"), before);
    }

    #[test]
    fn real_packet_prefix_and_outer_clone_commit_preserve_order_and_full_rollback() {
        for force in [false, true] {
            for wrong_length in [false, true] {
                let mut decoder = one_bit_legacy_decoder(force);
                let before = format!("{decoder:?}");
                let contribution = one_ff_legacy_contribution();
                let body: &[u8] = if wrong_length { &[] } else { &[0xff] };
                let expected = if !force && !wrong_length {
                    before.replacen("zero_bitplanes: None,", "zero_bitplanes: Some(0),", 1)
                } else {
                    before
                };
                assert_eq!(
                    prepare_code_block_contribution_body(&mut decoder, &contribution, body),
                    if force || wrong_length {
                        Err(packet_invalid_code_block())
                    } else {
                        Ok(())
                    }
                );
                assert_eq!(format!("{decoder:?}"), expected);
            }
        }
        for wrong_total in [false, true] {
            let mut decoder = one_bit_legacy_decoder(false);
            let before = format!("{decoder:?}");
            let decoded = expected_one_ff_decoder(&decoder, true);
            let mut contribution = one_ff_legacy_contribution();
            if wrong_total {
                contribution.new_passes = 2;
            }
            let result = decode_code_block_contribution_body(
                &mut decoder,
                &contribution,
                &[0xff],
                &ResourceLimits::default(),
            );
            assert_eq!(
                result,
                if wrong_total {
                    Err(packet_invalid_code_block())
                } else {
                    Ok(CodeBlockBodyDecode {
                        segments: 1,
                        passes: 1,
                        bytes: 1,
                    })
                }
            );
            assert_eq!(
                format!("{decoder:?}"),
                if wrong_total { before } else { decoded }
            );
        }
    }

    #[test]
    fn native_contribution_segment_lookup_covers_all_counts_indices_and_full_stored_arrays() {
        let mut contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: u16::MAX,
            new_passes: u8::MAX,
            data_length: u32::MAX,
            high_throughput: true,
            segment_count: 0,
            segment_passes: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
            segment_lengths: [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION],
        };
        for index in 0..MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION {
            contribution.segment_passes[index] = u8::MAX - index as u8;
            contribution.segment_lengths[index] = u32::MAX - index as u32;
        }
        for count in 0..=u8::MAX {
            contribution.segment_count = count;
            let before = contribution;
            assert_eq!(contribution.segment_count(), count);
            for index in 0..=u8::MAX {
                let expected = if index < count
                    && usize::from(index) < MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION
                {
                    Ok(CodeBlockSegmentContribution {
                        passes: u8::MAX - index,
                        data_length: u32::MAX - u32::from(index),
                    })
                } else {
                    Err(invalid_packet_header())
                };
                assert_eq!(contribution.segment(index), expected);
                assert_eq!(contribution, before);
            }
        }
    }

    #[test]
    fn readonly_precinct_decoder_accessors_use_actual_vec_and_entire_native_indices() {
        for count in 0..=4 {
            let mut decoders = Vec::with_capacity(count + 8);
            for index in 0..count {
                decoders.push(
                    Tier1CodeBlockDecoder::new(
                        u16::try_from(index + 1).unwrap(),
                        1,
                        1,
                        SubbandOrientation::Ll,
                        Tier1CodingStyle::default(),
                    )
                    .unwrap(),
                );
            }
            let precinct = PacketPrecinctDecoder {
                component: u16::MAX,
                resolution: u8::MAX,
                precinct: u32::MAX,
                states: Vec::new(),
                contexts: Vec::new(),
                decoders,
                subbands: Vec::new(),
            };
            assert_eq!(precinct.decoder_count(), count);
            assert_eq!(precinct.decoders().len(), count);
            for index in (0..count + 9).chain([usize::MAX / 2, usize::MAX - 1, usize::MAX]) {
                match precinct.decoder(index) {
                    Ok(value) => {
                        assert!(index < count);
                        assert!(core::ptr::eq(value, &precinct.decoders()[index]));
                    }
                    Err(error) => {
                        assert!(index >= count);
                        assert_eq!(
                            error,
                            DecodeError::MalformedInput {
                                offset: 0,
                                kind: MalformedKind::InvalidPacketHeader
                            }
                        );
                    }
                }
            }
        }
    }
    use crate::codestream::{
        CodingStyle, ComponentCodingStyles, ComponentQuantizations, Quantization, WaveletTransform,
    };
    use std::collections::HashSet;

    fn coding_style(sop_markers: bool, eph_markers: bool) -> CodingStyle {
        CodingStyle {
            progression_order: ProgressionOrder::Lrcp,
            layers: 2,
            multiple_component_transform: false,
            decomposition_levels: 0,
            decomposition_structure: None,
            decomposition_directions: [crate::codestream::DecompositionDirection::TwoDimensional;
                32],
            code_block_width: 1,
            code_block_height: 1,
            code_block_style: 0,
            transform: WaveletTransform::Reversible5x3,
            precincts_defined: false,
            sop_markers,
            eph_markers,
            precinct_exponents: [(15, 15); 33],
        }
    }

    fn component_styles(style: CodingStyle) -> (ComponentCodingStyles, ComponentQuantizations) {
        (
            ComponentCodingStyles::uniform(1, style).unwrap(),
            ComponentQuantizations::uniform(1, Quantization::reversible_default(style)).unwrap(),
        )
    }

    fn pack_packet_bits(bits: &[bool]) -> Vec<u8> {
        let mut bytes = Vec::new();
        let mut current = 0_u8;
        let mut used = 0_u8;
        let mut capacity = 8_u8;
        for bit in bits {
            current <<= 1;
            current |= u8::from(*bit);
            used += 1;
            if used == capacity {
                bytes.push(current);
                capacity = if current == 0xff { 7 } else { 8 };
                current = 0;
                used = 0;
            }
        }
        if used != 0 {
            current <<= capacity - used;
            bytes.push(current);
        }
        bytes
    }

    fn two_block_first_layer_header() -> Vec<u8> {
        pack_packet_bits(&[
            true, // non-empty packet
            true, true, // block 0 inclusion tree: root, leaf
            true, true,  // block 0 zero-bitplane tree: root, leaf
            false, // one coding pass
            false, // no Lblock increment
            false, true, false, // two body bytes
            true,  // block 1 inclusion leaf
            true,  // block 1 zero-bitplane leaf
            false, // one coding pass
            false, // no Lblock increment
            false, true, false, // two body bytes
        ])
    }

    #[test]
    fn decodes_every_packet_coding_pass_count_and_length_width() {
        for passes in 1_u32..=164 {
            let (mut bits, suffix, count) = match passes {
                1 => (vec![false], 0, 0),
                2 => (vec![true, false], 0, 0),
                3..=5 => (vec![true, true], passes - 3, 2),
                6..=36 => (vec![true; 4], passes - 6, 5),
                _ => (vec![true; 9], passes - 37, 7),
            };
            for bit in (0..count).rev() {
                bits.push(suffix & (1 << bit) != 0);
            }
            bits.push(true);
            let bytes = pack_packet_bits(&bits);
            let mut reader = PacketBitReader::new(&bytes, &ResourceLimits::default()).unwrap();
            assert_eq!(u32::from(read_new_passes(&mut reader).unwrap()), passes);
            assert!(
                reader.read_bit().unwrap(),
                "pass count consumed the next field"
            );
            assert_eq!(u32::from(floor_log2(passes)), 31 - passes.leading_zeros());
        }
    }

    #[test]
    fn reads_bits_most_significant_first() {
        let mut reader = PacketBitReader::new(&[0b1010_0000], &ResourceLimits::default()).unwrap();
        assert!(reader.read_bit().unwrap());
        assert!(!reader.read_bit().unwrap());
        assert!(reader.read_bit().unwrap());
        assert_eq!(reader.bits_read(), 3);
        assert_eq!(reader.bytes_consumed(), 1);
    }

    #[test]
    fn enforces_stuffed_bit_after_ff() {
        let mut reader = PacketBitReader::new(&[0xff, 0x7f], &ResourceLimits::default()).unwrap();
        assert_eq!(reader.read_bits(8).unwrap(), 0xff);
        assert!(reader.read_bit().unwrap());
        assert_eq!(reader.bits_read(), 9);

        let mut invalid = PacketBitReader::new(&[0xff, 0x80], &ResourceLimits::default()).unwrap();
        assert_eq!(invalid.read_bits(8).unwrap(), 0xff);
        assert!(matches!(
            invalid.read_bit(),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::InvalidBitStuffing,
                ..
            })
        ));
    }

    #[test]
    fn aligns_and_reports_truncation() {
        let mut reader = PacketBitReader::new(&[0b1000_0000], &ResourceLimits::default()).unwrap();
        assert!(reader.read_bit().unwrap());
        reader.align_to_byte();
        assert!(reader.is_byte_aligned());
        assert!(matches!(
            reader.read_bit(),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::Truncated,
                ..
            })
        ));
    }

    #[test]
    fn rejects_excessive_bit_counts_and_header_bytes() {
        let mut reader = PacketBitReader::new(&[0; 4], &ResourceLimits::default()).unwrap();
        assert!(reader.read_bits(33).is_err());
        let limits = ResourceLimits::default()
            .with_maximum_packet_header_bytes(1)
            .unwrap();
        assert!(matches!(
            PacketBitReader::new(&[0; 4], &limits),
            Err(DecodeError::LimitExceeded {
                resource: Resource::PacketHeaderBytes,
                ..
            })
        ));
    }

    #[test]
    fn constructs_bounded_tag_tree_topology() {
        let tree = TagTree::new(3, 2, &ResourceLimits::default()).unwrap();
        assert_eq!(tree.leaf_count().unwrap(), 6);
        assert_eq!(tree.node_count(), 9);
    }

    #[test]
    fn decodes_and_reuses_monotonic_tag_tree_state() {
        let mut tree = TagTree::new(1, 1, &ResourceLimits::default()).unwrap();
        let mut reader = PacketBitReader::new(&[0b0010_0000], &ResourceLimits::default()).unwrap();
        let value = tree.decode(0, 0, 3, &mut reader).unwrap();
        assert_eq!(value.value, Some(2));
        assert!(value.is_below_threshold);
        assert_eq!(reader.bits_read(), 3);

        let repeated = tree.decode(0, 0, 4, &mut reader).unwrap();
        assert_eq!(repeated.value, Some(2));
        assert_eq!(reader.bits_read(), 3);
    }

    #[test]
    fn rejects_invalid_tag_tree_coordinates() {
        let mut tree = TagTree::new(2, 2, &ResourceLimits::default()).unwrap();
        let mut reader = PacketBitReader::new(&[0], &ResourceLimits::default()).unwrap();
        assert!(matches!(
            tree.decode(2, 0, 1, &mut reader),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::InvalidTagTree,
                ..
            })
        ));
    }

    #[test]
    fn preserves_descendants_when_ancestor_is_not_below_threshold() {
        let mut tree = TagTree::new(2, 1, &ResourceLimits::default()).unwrap();
        let mut reader = PacketBitReader::new(&[0b0110_0000], &ResourceLimits::default()).unwrap();
        let first = tree.decode(0, 0, 1, &mut reader).unwrap();
        assert!(!first.is_below_threshold);
        assert_eq!(reader.bits_read(), 1);

        let second = tree.decode(0, 0, 2, &mut reader).unwrap();
        assert_eq!(second.value, Some(1));
        assert_eq!(reader.bits_read(), 3);
    }

    #[test]
    fn all_progression_orders_emit_identical_packet_sets() {
        let grid = PacketGrid::new(2, 2, 2, vec![1, 2, 3, 1], &ResourceLimits::default()).unwrap();
        assert_eq!(grid.packet_count(), 14);
        let orders = [
            ProgressionOrder::Lrcp,
            ProgressionOrder::Rlcp,
            ProgressionOrder::Rpcl,
            ProgressionOrder::Pcrl,
            ProgressionOrder::Cprl,
        ];
        let mut baseline = None;
        for order in orders {
            let mut iterator = PacketIterator::new(&grid, order);
            let packets = iterator
                .by_ref()
                .collect::<Result<HashSet<PacketCoordinate>, _>>()
                .unwrap();
            assert_eq!(packets.len(), 14);
            assert_eq!(iterator.emitted(), 14);
            if let Some(expected) = &baseline {
                assert_eq!(&packets, expected);
            } else {
                baseline = Some(packets);
            }
        }
    }

    #[test]
    fn progression_iteration_is_order_specific_and_bounded() {
        let grid = PacketGrid::new(2, 2, 1, vec![1, 1], &ResourceLimits::default()).unwrap();
        let mut lrcp = PacketIterator::new(&grid, ProgressionOrder::Lrcp);
        assert_eq!(
            lrcp.next_packet().unwrap(),
            Some(PacketCoordinate {
                layer: 0,
                resolution: 0,
                component: 0,
                precinct: 0,
            })
        );
        assert_eq!(
            lrcp.next_packet().unwrap(),
            Some(PacketCoordinate {
                layer: 0,
                resolution: 0,
                component: 1,
                precinct: 0,
            })
        );

        let limits = ResourceLimits::default().with_maximum_packets(1).unwrap();
        assert!(matches!(
            PacketGrid::new(2, 1, 1, vec![1], &limits),
            Err(DecodeError::LimitExceeded {
                resource: Resource::Packets,
                ..
            })
        ));
    }

    #[test]
    fn progression_change_windows_emit_each_packet_once_in_window_order() {
        let limits = ResourceLimits::default();
        let grid = PacketGrid::new(2, 2, 1, vec![1, 1], &limits).unwrap();
        let changes = ProgressionChanges::from_records(vec![
            ProgressionChange {
                resolution_start: 0,
                component_start: 0,
                layer_end: 2,
                resolution_end: 1,
                component_end: 1,
                progression_order: ProgressionOrder::Lrcp,
            },
            ProgressionChange {
                resolution_start: 0,
                component_start: 1,
                layer_end: 2,
                resolution_end: 1,
                component_end: 2,
                progression_order: ProgressionOrder::Rlcp,
            },
        ]);
        let mut iterator =
            ProgressionPacketIterator::new(&grid, ProgressionOrder::Cprl, &changes, &limits)
                .unwrap();
        let mut packets = Vec::new();
        while let Some(packet) = iterator.next_packet().unwrap() {
            packets.push(packet);
        }
        assert_eq!(
            packets,
            vec![
                PacketCoordinate {
                    layer: 0,
                    resolution: 0,
                    component: 0,
                    precinct: 0,
                },
                PacketCoordinate {
                    layer: 1,
                    resolution: 0,
                    component: 0,
                    precinct: 0,
                },
                PacketCoordinate {
                    layer: 0,
                    resolution: 0,
                    component: 1,
                    precinct: 0,
                },
                PacketCoordinate {
                    layer: 1,
                    resolution: 0,
                    component: 1,
                    precinct: 0,
                },
            ]
        );
        assert_eq!(iterator.emitted(), grid.packet_count());
    }

    #[test]
    fn overlapping_progression_windows_skip_previously_emitted_packets() {
        let limits = ResourceLimits::default();
        let grid = PacketGrid::new(2, 1, 1, vec![1], &limits).unwrap();
        let changes = ProgressionChanges::from_records(vec![
            ProgressionChange {
                resolution_start: 0,
                component_start: 0,
                layer_end: 1,
                resolution_end: 1,
                component_end: 1,
                progression_order: ProgressionOrder::Rlcp,
            },
            ProgressionChange {
                resolution_start: 0,
                component_start: 0,
                layer_end: 2,
                resolution_end: 1,
                component_end: 1,
                progression_order: ProgressionOrder::Lrcp,
            },
        ]);
        let mut iterator =
            ProgressionPacketIterator::new(&grid, ProgressionOrder::Cprl, &changes, &limits)
                .unwrap();
        let mut unique = HashSet::new();
        while let Some(packet) = iterator.next_packet().unwrap() {
            assert!(unique.insert(packet));
        }
        assert_eq!(unique.len() as u64, grid.packet_count());
    }

    #[test]
    fn decodes_code_block_packet_contributions() {
        let limits = ResourceLimits::default();
        let mut inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut state = CodeBlockPacketState::new();
        let mut first_reader = PacketBitReader::new(&[0xca], &limits).unwrap();
        let first = decode_code_block_contribution(
            &mut state,
            &mut inclusion,
            &mut zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 8,
                tier1_style: Tier1CodingStyle::default(),
            },
            &mut first_reader,
        )
        .unwrap()
        .unwrap();
        assert!(first.first_inclusion);
        assert_eq!(first.zero_bitplanes, 0);
        assert_eq!(first.new_passes, 1);
        assert_eq!(first.data_length, 5);
        assert_eq!(first.segment_count(), 1);
        assert_eq!(
            first.segment(0).unwrap(),
            CodeBlockSegmentContribution {
                passes: 1,
                data_length: 5,
            }
        );
        assert_eq!(state.total_passes(), 1);

        let mut second_reader = PacketBitReader::new(&[0xd0, 0xc0], &limits).unwrap();
        let second = decode_code_block_contribution(
            &mut state,
            &mut inclusion,
            &mut zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 1,
                maximum_zero_bitplanes: 8,
                tier1_style: Tier1CodingStyle::default(),
            },
            &mut second_reader,
        )
        .unwrap()
        .unwrap();
        assert!(!second.first_inclusion);
        assert_eq!(second.new_passes, 2);
        assert_eq!(second.data_length, 3);
        assert_eq!(second.segment_count(), 1);
        assert_eq!(second.segment(0).unwrap().passes, 2);
        assert_eq!(state.total_passes(), 3);
        assert_eq!(state.lblock(), 4);

        let previous = state;
        let mut absent_reader = PacketBitReader::new(&[0], &limits).unwrap();
        assert!(
            decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero_bitplanes,
                CodeBlockPacketContext {
                    leaf_x: 0,
                    leaf_y: 0,
                    layer: 2,
                    maximum_zero_bitplanes: 8,
                    tier1_style: Tier1CodingStyle::default(),
                },
                &mut absent_reader,
            )
            .unwrap()
            .is_none()
        );
        assert_eq!(state, previous);
    }

    #[test]
    fn preserves_code_block_state_on_invalid_length() {
        let limits = ResourceLimits::default();
        let mut inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut state = CodeBlockPacketState::new();
        let initial = state;
        let mut reader = PacketBitReader::new(&[0xc0], &limits).unwrap();
        assert!(matches!(
            decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero_bitplanes,
                CodeBlockPacketContext {
                    leaf_x: 0,
                    leaf_y: 0,
                    layer: 0,
                    maximum_zero_bitplanes: 8,
                    tier1_style: Tier1CodingStyle::default(),
                },
                &mut reader,
            ),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::InvalidPacketHeader,
                ..
            })
        ));
        assert_eq!(state, initial);
    }

    #[test]
    fn permits_zero_byte_legacy_continuation_without_accepting_an_empty_initial_segment() {
        let limits = ResourceLimits::default();
        let mut inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut state = CodeBlockPacketState {
            included: true,
            zero_bitplanes: Some(0),
            lblock: 3,
            total_passes: 9,
            high_throughput: Some(false),
        };
        let mut reader = PacketBitReader::new(&[0x80], &limits).unwrap();
        let contribution = decode_code_block_contribution(
            &mut state,
            &mut inclusion,
            &mut zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 1,
                maximum_zero_bitplanes: 8,
                tier1_style: Tier1CodingStyle::from_code_block_style(1).unwrap(),
            },
            &mut reader,
        )
        .unwrap()
        .unwrap();
        assert!(!contribution.first_inclusion);
        assert_eq!(contribution.new_passes, 1);
        assert_eq!(contribution.data_length, 0);
        assert_eq!(contribution.segment_count(), 1);
        assert_eq!(contribution.segment(0).unwrap().data_length, 0);
        assert_eq!(state.total_passes(), 10);

        let initial = CodeBlockPacketState::new();
        state = initial;
        let mut reader = PacketBitReader::new(&[0xc0], &limits).unwrap();
        assert!(
            decode_code_block_contribution(
                &mut state,
                &mut inclusion,
                &mut zero_bitplanes,
                CodeBlockPacketContext {
                    leaf_x: 0,
                    leaf_y: 0,
                    layer: 0,
                    maximum_zero_bitplanes: 8,
                    tier1_style: Tier1CodingStyle::default(),
                },
                &mut reader,
            )
            .is_err()
        );
        assert_eq!(state, initial);
    }

    #[test]
    fn mixed_mode_routes_from_first_nonzero_segment_length() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0xc0).unwrap();

        let mut ht_inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut ht_zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut ht_state = CodeBlockPacketState::new();
        let ht_header =
            pack_packet_bits(&[true, true, false, true, false, false, true, false, false]);
        let mut ht_reader = PacketBitReader::new(&ht_header, &limits).unwrap();
        let ht = decode_code_block_contribution(
            &mut ht_state,
            &mut ht_inclusion,
            &mut ht_zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 3,
                tier1_style: style,
            },
            &mut ht_reader,
        )
        .unwrap()
        .unwrap();
        assert!(ht.high_throughput);
        assert_eq!(ht_state.high_throughput(), Some(true));
        assert_eq!(ht.data_length, 4);

        let mut legacy_inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut legacy_zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut legacy_state = CodeBlockPacketState::new();
        let legacy_header = pack_packet_bits(&[true, true, false, false, false, true, false]);
        let mut legacy_reader = PacketBitReader::new(&legacy_header, &limits).unwrap();
        let legacy = decode_code_block_contribution(
            &mut legacy_state,
            &mut legacy_inclusion,
            &mut legacy_zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 3,
                tier1_style: style,
            },
            &mut legacy_reader,
        )
        .unwrap()
        .unwrap();
        assert!(!legacy.high_throughput);
        assert_eq!(legacy_state.high_throughput(), Some(false));
        assert_eq!(legacy.data_length, 2);

        let mut extended_inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut extended_zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let mut extended_state = CodeBlockPacketState::new();
        let extended_header =
            pack_packet_bits(&[true, true, true, false, false, false, false, false, true]);
        let mut extended_reader = PacketBitReader::new(&extended_header, &limits).unwrap();
        let extended = decode_code_block_contribution(
            &mut extended_state,
            &mut extended_inclusion,
            &mut extended_zero_bitplanes,
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 3,
                tier1_style: style,
            },
            &mut extended_reader,
        )
        .unwrap()
        .unwrap();
        assert!(!extended.high_throughput);
        assert_eq!(extended.new_passes, 2);
        assert_eq!(extended.segment(0).unwrap().passes, 2);
        assert_eq!(extended.data_length, 1);
    }

    #[test]
    fn continues_one_legacy_coding_segment_across_quality_layers() {
        let limits = ResourceLimits::default();
        let contribution = |passes: u8, bytes: u32, first_inclusion: bool| {
            let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            segment_passes[0] = passes;
            segment_lengths[0] = bytes;
            CodeBlockContribution {
                first_inclusion,
                zero_bitplanes: 2,
                new_passes: passes,
                data_length: bytes,
                high_throughput: false,
                segment_count: 1,
                segment_passes,
                segment_lengths,
            }
        };
        let mut whole = Tier1CodeBlockDecoder::new(
            1,
            1,
            9,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let mut layered = whole.clone();
        decode_code_block_contribution_body(
            &mut whole,
            &contribution(19, 2, true),
            &[0x04, 0x4f],
            &limits,
        )
        .unwrap();
        decode_code_block_contribution_body(
            &mut layered,
            &contribution(1, 1, true),
            &[0x04],
            &limits,
        )
        .unwrap();
        let before = layered.plane().coefficients().to_vec();
        let tight = limits.with_maximum_work_units(22).unwrap();
        assert!(matches!(
            decode_code_block_contribution_body(
                &mut layered,
                &contribution(18, 1, false),
                &[0x4f],
                &tight,
            ),
            Err(DecodeError::LimitExceeded {
                resource: crate::Resource::WorkUnits,
                ..
            })
        ));
        assert_eq!(layered.plane().coefficients(), before);
        assert_eq!(layered.next_pass(), 1);
        decode_code_block_contribution_body(
            &mut layered,
            &contribution(18, 1, false),
            &[0x4f],
            &limits,
        )
        .unwrap();
        assert_eq!(layered.plane().coefficients(), whole.plane().coefficients());
        assert_eq!(layered.decoded_bytes(), 2);
        assert_eq!(layered.next_pass(), 19);
    }

    #[test]
    fn decodes_bounded_code_block_contribution_body() {
        let limits = ResourceLimits::default();
        let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        segment_passes[0] = 1;
        segment_lengths[0] = 2;
        let contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 2,
            high_throughput: false,
            segment_count: 1,
            segment_passes,
            segment_lengths,
        };
        let mut decoder = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let decoded = decode_code_block_contribution_body(
            &mut decoder,
            &contribution,
            &[0x01, 0xae],
            &limits,
        )
        .unwrap();
        assert_eq!(
            decoded,
            CodeBlockBodyDecode {
                segments: 1,
                passes: 1,
                bytes: 2,
            }
        );
        assert!(decoder.is_complete());

        let mut truncated_decoder = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        assert!(
            decode_code_block_contribution_body(
                &mut truncated_decoder,
                &contribution,
                &[0x01],
                &limits,
            )
            .is_err()
        );
        assert_eq!(truncated_decoder.next_pass(), 0);
    }

    #[test]
    fn decodes_ht_cleanup_with_packet_missing_msbs() {
        // Independently encoded one-pixel residuals from OpenJPH 0.33.0.
        for (body, magnitude) in [
            ([0x8e, 0x01, 0x07, 0x74, 0x00], 72),
            ([0xfc, 0x01, 0x07, 0x74, 0x00], 127),
        ] {
            let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            segment_passes[0] = 1;
            segment_lengths[0] = 5;
            let contribution = CodeBlockContribution {
                first_inclusion: true,
                zero_bitplanes: 6,
                new_passes: 1,
                data_length: 5,
                high_throughput: true,
                segment_count: 1,
                segment_passes,
                segment_lengths,
            };
            let mut decoder = Tier1CodeBlockDecoder::new(
                1,
                1,
                7,
                crate::tier1::SubbandOrientation::Ll,
                Tier1CodingStyle::from_code_block_style(0x40).unwrap(),
            )
            .unwrap();
            decoder.set_ht_magnitude_bound(8).unwrap();
            decode_code_block_contribution_body(
                &mut decoder,
                &contribution,
                &body,
                &ResourceLimits::default(),
            )
            .unwrap();
            let coefficient = decoder.plane().coefficient(0, 0).unwrap();
            assert!(coefficient.significant);
            assert!(!coefficient.negative);
            assert_eq!(coefficient.magnitude, magnitude);
            assert_eq!(decoder.next_pass(), 1);
        }
    }

    #[test]
    fn decodes_ht_embedded_precision_separately_from_value() {
        let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        segment_passes[0] = 1;
        segment_lengths[0] = 8;
        let contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 6,
            new_passes: 1,
            data_length: 8,
            high_throughput: true,
            segment_count: 1,
            segment_passes,
            segment_lengths,
        };
        let mut decoder = Tier1CodeBlockDecoder::new(
            2,
            2,
            7,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::from_code_block_style(0x40).unwrap(),
        )
        .unwrap();
        decoder.set_ht_magnitude_bound(8).unwrap();
        let body = [0x00, 0x82, 0xc0, 0xf1, 0x00, 0x43, 0x94, 0x00];
        decode_code_block_contribution_body(
            &mut decoder,
            &contribution,
            &body,
            &ResourceLimits::default(),
        )
        .unwrap();
        for (x, y, value) in [(0, 0, 1), (1, 0, 2), (0, 1, 3), (1, 1, 72)] {
            assert_eq!(decoder.plane().signed_coefficient(x, y).unwrap(), value);
        }
    }

    #[test]
    fn ht_final_magnitude_refinement_truncates_the_integer_half_bin() {
        for (bit, magnitude) in [(0, 2), (1, 3)] {
            let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
            segment_passes[0] = 1;
            segment_passes[1] = 2;
            segment_lengths[0] = 4;
            segment_lengths[1] = 1;
            let contribution = CodeBlockContribution {
                first_inclusion: true,
                zero_bitplanes: 5,
                new_passes: 3,
                data_length: 5,
                high_throughput: true,
                segment_count: 2,
                segment_passes,
                segment_lengths,
            };
            let mut decoder = Tier1CodeBlockDecoder::new(
                1,
                1,
                7,
                crate::tier1::SubbandOrientation::Ll,
                Tier1CodingStyle::from_code_block_style(0x40).unwrap(),
            )
            .unwrap();
            decoder.set_ht_magnitude_bound(8).unwrap();
            let body = [0xfe, 0x00, 0x63, 0x00, bit];
            decode_code_block_contribution_body(
                &mut decoder,
                &contribution,
                &body,
                &ResourceLimits::default(),
            )
            .unwrap();
            assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), magnitude);
            assert!(decoder.plane().coefficient(0, 0).unwrap().refined);
        }
    }

    #[test]
    fn routes_valid_ht_body_after_grouping_to_coefficient_boundary() {
        let limits = ResourceLimits::default();
        let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        segment_passes[0] = 1;
        segment_lengths[0] = 3;
        segment_passes[1] = 1;
        segment_lengths[1] = 0;
        let contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 2,
            data_length: 3,
            high_throughput: true,
            segment_count: 2,
            segment_passes,
            segment_lengths,
        };
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut decoder =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();
        let decoded = decode_code_block_contribution_body(
            &mut decoder,
            &contribution,
            &[0x00, 0x63, 0x00],
            &limits,
        )
        .unwrap();
        assert_eq!(decoded.passes, 2);
        assert_eq!(decoded.segments, 2);
        assert_eq!(decoder.next_pass(), 2);
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), -6);

        let mut malformed_decoder =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();
        assert!(matches!(
            decode_code_block_contribution_body(
                &mut malformed_decoder,
                &contribution,
                &[0x01, 0x00, 0x00],
                &limits,
            ),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::InvalidCodeBlock,
                ..
            })
        ));
    }

    #[test]
    fn routes_cleanup_only_ht_body_into_coefficient_plane() {
        let limits = ResourceLimits::default();
        let mut segment_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut segment_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        segment_passes[0] = 1;
        segment_lengths[0] = 4;
        let contribution = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 4,
            high_throughput: true,
            segment_count: 1,
            segment_passes,
            segment_lengths,
        };
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut decoder =
            Tier1CodeBlockDecoder::new(1, 1, 1, SubbandOrientation::Ll, style).unwrap();
        let decoded = decode_code_block_contribution_body(
            &mut decoder,
            &contribution,
            &[0xfe, 0x00, 0x63, 0x00],
            &limits,
        )
        .unwrap();
        assert_eq!(
            decoded,
            CodeBlockBodyDecode {
                segments: 1,
                passes: 1,
                bytes: 4,
            }
        );
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), 1);
        assert!(decoder.is_complete());
    }

    #[test]
    fn routes_ht_refinement_across_layer_contributions() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut decoder =
            Tier1CodeBlockDecoder::new(1, 1, 2, SubbandOrientation::Ll, style).unwrap();

        let mut cleanup_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut cleanup_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        cleanup_passes[0] = 1;
        cleanup_lengths[0] = 3;
        let cleanup = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 3,
            high_throughput: true,
            segment_count: 1,
            segment_passes: cleanup_passes,
            segment_lengths: cleanup_lengths,
        };
        decode_code_block_contribution_body(&mut decoder, &cleanup, &[0x00, 0x63, 0x00], &limits)
            .unwrap();
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), -3);

        let mut refinement_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let refinement_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        refinement_passes[0] = 1;
        let significance = CodeBlockContribution {
            first_inclusion: false,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 0,
            high_throughput: true,
            segment_count: 1,
            segment_passes: refinement_passes,
            segment_lengths: refinement_lengths,
        };
        decode_code_block_contribution_body(&mut decoder, &significance, &[], &limits).unwrap();
        assert_eq!(decoder.next_pass(), 2);

        let mut magnitude_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        magnitude_lengths[0] = 1;
        let magnitude = CodeBlockContribution {
            data_length: 1,
            segment_lengths: magnitude_lengths,
            ..significance
        };
        decode_code_block_contribution_body(&mut decoder, &magnitude, &[0x01], &limits).unwrap();
        assert_eq!(decoder.next_pass(), 3);
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), -3);
        assert_eq!(decoder.decoded_segments(), 3);
        assert_eq!(decoder.decoded_bytes(), 4);
    }

    #[test]
    fn routes_placeholder_passes_before_first_ht_cleanup() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let mut decoder =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();

        let mut placeholder_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let placeholder_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        placeholder_passes[0] = 1;
        placeholder_passes[1] = 2;
        let placeholders = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 3,
            data_length: 0,
            high_throughput: true,
            segment_count: 2,
            segment_passes: placeholder_passes,
            segment_lengths: placeholder_lengths,
        };
        decode_code_block_contribution_body(&mut decoder, &placeholders, &[], &limits).unwrap();
        assert_eq!(decoder.next_pass(), 3);
        assert_eq!(decoder.plane().signed_coefficient(0, 0).unwrap(), 0);

        let mut cleanup_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut cleanup_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        cleanup_passes[0] = 1;
        cleanup_lengths[0] = 4;
        let cleanup = CodeBlockContribution {
            first_inclusion: false,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 4,
            high_throughput: true,
            segment_count: 1,
            segment_passes: cleanup_passes,
            segment_lengths: cleanup_lengths,
        };
        decode_code_block_contribution_body(
            &mut decoder,
            &cleanup,
            &[0xfe, 0x00, 0x63, 0x00],
            &limits,
        )
        .unwrap();
        assert_eq!(decoder.next_pass(), 4);
        assert_ne!(decoder.plane().signed_coefficient(0, 0).unwrap(), 0);
    }

    #[test]
    fn enforces_singleht_and_routes_multiple_ht_sets_transactionally() {
        let limits = ResourceLimits::default();
        let style = Tier1CodingStyle::from_code_block_style(0x40).unwrap();
        let cleanup_bytes = [0xfe, 0x00, 0x63, 0x00];
        let mut set_passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        let mut set_lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
        set_passes[0] = 1;
        set_lengths[0] = 4;
        set_passes[1] = 2;
        let first_set = CodeBlockContribution {
            first_inclusion: true,
            zero_bitplanes: 0,
            new_passes: 3,
            data_length: 4,
            high_throughput: true,
            segment_count: 2,
            segment_passes: set_passes,
            segment_lengths: set_lengths,
        };
        let cleanup_only = CodeBlockContribution {
            new_passes: 1,
            segment_count: 1,
            ..first_set
        };
        let second_set = CodeBlockContribution {
            first_inclusion: false,
            zero_bitplanes: 0,
            new_passes: 1,
            data_length: 4,
            high_throughput: true,
            segment_count: 1,
            segment_passes: {
                let mut passes = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
                passes[0] = 1;
                passes
            },
            segment_lengths: {
                let mut lengths = [0; MAX_CODE_BLOCK_SEGMENTS_PER_CONTRIBUTION];
                lengths[0] = 4;
                lengths
            },
        };

        let mut single =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();
        let mut cleanup_reference =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();
        decode_code_block_contribution_body(
            &mut cleanup_reference,
            &cleanup_only,
            &cleanup_bytes,
            &limits,
        )
        .unwrap();
        decode_code_block_contribution_body(&mut single, &first_set, &cleanup_bytes, &limits)
            .unwrap();
        assert_eq!(
            single.plane().signed_coefficient(0, 0).unwrap(),
            cleanup_reference.plane().signed_coefficient(0, 0).unwrap()
        );
        let before_pass = single.next_pass();
        let before_value = single.plane().signed_coefficient(0, 0).unwrap();
        assert!(
            decode_code_block_contribution_body(&mut single, &second_set, &cleanup_bytes, &limits,)
                .is_err()
        );
        assert_eq!(single.next_pass(), before_pass);
        assert_eq!(
            single.plane().signed_coefficient(0, 0).unwrap(),
            before_value
        );

        let mut multiple =
            Tier1CodeBlockDecoder::new(1, 1, 3, SubbandOrientation::Ll, style).unwrap();
        multiple.set_multiple_ht_sets_allowed(true);
        decode_code_block_contribution_body(&mut multiple, &first_set, &cleanup_bytes, &limits)
            .unwrap();
        decode_code_block_contribution_body(&mut multiple, &second_set, &cleanup_bytes, &limits)
            .unwrap();
        assert_eq!(multiple.next_pass(), 4);
        assert_eq!(multiple.decoded_segments(), 3);
    }

    #[test]
    fn executes_retained_multi_code_block_packet_and_advances_by_prefix() {
        let limits = ResourceLimits::default();
        let mut data = two_block_first_layer_header();
        data.extend_from_slice(&[0x01, 0xae, 0x01, 0xae]);
        data.push(0);
        let tile_part = TilePartPayload {
            tile_index: 0,
            tile_part_index: 0,
            tile_part_count: 1,
            coding_style: coding_style(false, false),
            quantization: Quantization::reversible_default(coding_style(false, false)),
            component_coding_styles: component_styles(coding_style(false, false)).0,
            component_quantizations: component_styles(coding_style(false, false)).1,
            roi_shifts: crate::codestream::RoiShifts::none(),
            progression_changes: ProgressionChanges::none(),
            multiple_component_transform: None,
            part2_extensions: crate::codestream::Part2Extensions::default(),
            packet_lengths: crate::codestream::PacketLengths::none(),
            packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
            has_functional_header_marker: false,
            has_roi_marker: false,
            data: &data,
        };
        let mut states = [CodeBlockPacketState::new(), CodeBlockPacketState::new()];
        let mut inclusion = TagTree::new(2, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(2, 1, &limits).unwrap();
        let contexts = [
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 1,
                tier1_style: Tier1CodingStyle::default(),
            },
            CodeBlockPacketContext {
                leaf_x: 1,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 1,
                tier1_style: Tier1CodingStyle::default(),
            },
        ];
        let first = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let second = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let mut decoders = [first, second];
        let decoded = decode_multi_code_block_packet(
            &tile_part,
            0,
            PacketCodeBlockExecution {
                states: &mut states,
                inclusion_tree: &mut inclusion,
                zero_bitplane_tree: &mut zero_bitplanes,
                contexts: &contexts,
                decoders: &mut decoders,
            },
            &limits,
        )
        .unwrap();
        assert_eq!(
            decoded,
            PacketBodyDecode {
                present: true,
                code_blocks: 2,
                contributions: 2,
                segments: 2,
                passes: 2,
                header_bytes: 3,
                body_bytes: 4,
                bytes_consumed: 7,
            }
        );
        assert!(states.iter().all(CodeBlockPacketState::included));
        assert!(decoders.iter().all(Tier1CodeBlockDecoder::is_complete));

        let absent = decode_multi_code_block_packet(
            &tile_part,
            usize::try_from(decoded.bytes_consumed).unwrap(),
            PacketCodeBlockExecution {
                states: &mut states,
                inclusion_tree: &mut inclusion,
                zero_bitplane_tree: &mut zero_bitplanes,
                contexts: &contexts,
                decoders: &mut decoders,
            },
            &limits,
        )
        .unwrap();
        assert_eq!(absent.bytes_consumed, 1);
        assert!(!absent.present);
        assert_eq!(absent.contributions, 0);
    }

    #[test]
    fn empty_resolution_precinct_consumes_either_packet_present_flag() {
        let limits = ResourceLimits::default();
        for header in [0_u8, 0x80] {
            let data = [header];
            let style = coding_style(false, false);
            let tile = TilePartPayload {
                tile_index: 0,
                tile_part_index: 0,
                tile_part_count: 1,
                coding_style: style,
                quantization: Quantization::reversible_default(style),
                component_coding_styles: component_styles(style).0,
                component_quantizations: component_styles(style).1,
                roi_shifts: crate::codestream::RoiShifts::none(),
                progression_changes: ProgressionChanges::none(),
                multiple_component_transform: None,
                part2_extensions: crate::codestream::Part2Extensions::default(),
                packet_lengths: crate::codestream::PacketLengths::none(),
                packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
                has_functional_header_marker: false,
                has_roi_marker: false,
                data: &data,
            };
            let mut precinct = PacketPrecinctDecoder::new_subbands(
                0,
                1,
                0,
                Tier1CodingStyle::default(),
                Vec::new(),
                &limits,
            )
            .unwrap();
            let (decoded, consumed, packed) =
                decode_precinct_packet(&tile, 0, &[], 0, Some(1), 0, &mut precinct, true, &limits)
                    .unwrap();
            assert_eq!(decoded.present, header != 0);
            assert_eq!(decoded.code_blocks, 0);
            assert_eq!(decoded.passes, 0);
            assert_eq!(consumed, 1);
            assert_eq!(packed, 0);
            assert!(
                decode_precinct_packet(&tile, 0, &[], 0, Some(2), 0, &mut precinct, true, &limits,)
                    .is_err()
            );
        }
    }

    #[test]
    fn validates_packet_markers_and_preflights_all_bodies() {
        let limits = ResourceLimits::default();
        let marker_data = [0xff, 0x91, 0, 4, 0x12, 0x34, 0, 0xff, 0x92];
        let marked_tile = TilePartPayload {
            tile_index: 0,
            tile_part_index: 0,
            tile_part_count: 1,
            coding_style: coding_style(true, true),
            quantization: Quantization::reversible_default(coding_style(true, true)),
            component_coding_styles: component_styles(coding_style(true, true)).0,
            component_quantizations: component_styles(coding_style(true, true)).1,
            roi_shifts: crate::codestream::RoiShifts::none(),
            progression_changes: ProgressionChanges::none(),
            multiple_component_transform: None,
            part2_extensions: crate::codestream::Part2Extensions::default(),
            packet_lengths: crate::codestream::PacketLengths::none(),
            packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
            has_functional_header_marker: false,
            has_roi_marker: false,
            data: &marker_data,
        };
        let mut states = [CodeBlockPacketState::new()];
        let mut inclusion = TagTree::new(1, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(1, 1, &limits).unwrap();
        let contexts = [CodeBlockPacketContext {
            leaf_x: 0,
            leaf_y: 0,
            layer: 0,
            maximum_zero_bitplanes: 1,
            tier1_style: Tier1CodingStyle::default(),
        }];
        let decoder = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let mut decoders = [decoder];
        let empty = decode_multi_code_block_packet(
            &marked_tile,
            0,
            PacketCodeBlockExecution {
                states: &mut states,
                inclusion_tree: &mut inclusion,
                zero_bitplane_tree: &mut zero_bitplanes,
                contexts: &contexts,
                decoders: &mut decoders,
            },
            &limits,
        )
        .unwrap();
        assert_eq!(empty.bytes_consumed, 9);
        assert_eq!(empty.header_bytes, 1);
        assert!(!empty.present);

        let mut truncated = two_block_first_layer_header();
        truncated.extend_from_slice(&[0x01, 0xae]);
        let truncated_tile = TilePartPayload {
            tile_index: 0,
            tile_part_index: 0,
            tile_part_count: 1,
            coding_style: coding_style(false, false),
            quantization: Quantization::reversible_default(coding_style(false, false)),
            component_coding_styles: component_styles(coding_style(false, false)).0,
            component_quantizations: component_styles(coding_style(false, false)).1,
            roi_shifts: crate::codestream::RoiShifts::none(),
            progression_changes: ProgressionChanges::none(),
            multiple_component_transform: None,
            part2_extensions: crate::codestream::Part2Extensions::default(),
            packet_lengths: crate::codestream::PacketLengths::none(),
            packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
            has_functional_header_marker: false,
            has_roi_marker: false,
            data: &truncated,
        };
        let mut states = [CodeBlockPacketState::new(), CodeBlockPacketState::new()];
        let mut inclusion = TagTree::new(2, 1, &limits).unwrap();
        let mut zero_bitplanes = TagTree::new(2, 1, &limits).unwrap();
        let contexts = [
            CodeBlockPacketContext {
                leaf_x: 0,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 1,
                tier1_style: Tier1CodingStyle::default(),
            },
            CodeBlockPacketContext {
                leaf_x: 1,
                leaf_y: 0,
                layer: 0,
                maximum_zero_bitplanes: 1,
                tier1_style: Tier1CodingStyle::default(),
            },
        ];
        let first = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let second = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let mut decoders = [first, second];
        assert!(matches!(
            decode_multi_code_block_packet(
                &truncated_tile,
                0,
                PacketCodeBlockExecution {
                    states: &mut states,
                    inclusion_tree: &mut inclusion,
                    zero_bitplane_tree: &mut zero_bitplanes,
                    contexts: &contexts,
                    decoders: &mut decoders,
                },
                &limits,
            ),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::Truncated,
                ..
            })
        ));
        assert!(decoders.iter().all(|decoder| decoder.next_pass() == 0));

        let limits = limits.with_maximum_code_blocks(1).unwrap();
        assert!(matches!(
            decode_multi_code_block_packet(
                &truncated_tile,
                0,
                PacketCodeBlockExecution {
                    states: &mut states,
                    inclusion_tree: &mut inclusion,
                    zero_bitplane_tree: &mut zero_bitplanes,
                    contexts: &contexts,
                    decoders: &mut decoders,
                },
                &limits,
            ),
            Err(DecodeError::LimitExceeded {
                resource: Resource::CodeBlocks,
                ..
            })
        ));
    }

    #[test]
    fn traverses_retained_tile_parts_and_preserves_precinct_state() {
        let limits = ResourceLimits::default();
        let mut first_data = pack_packet_bits(&[
            true,  // non-empty packet
            true,  // first inclusion
            true,  // zero bitplanes
            false, // one pass
            false, // no Lblock increment
            true, false, true, // five body bytes
        ]);
        first_data.extend_from_slice(&[0; 5]);
        let second_data = [0];
        let style = coding_style(false, false);
        let tile_parts = [
            TilePartPayload {
                tile_index: 3,
                tile_part_index: 0,
                tile_part_count: 2,
                coding_style: style,
                quantization: Quantization::reversible_default(style),
                component_coding_styles: component_styles(style).0,
                component_quantizations: component_styles(style).1,
                roi_shifts: crate::codestream::RoiShifts::none(),
                progression_changes: ProgressionChanges::none(),
                multiple_component_transform: None,
                part2_extensions: crate::codestream::Part2Extensions::default(),
                packet_lengths: crate::codestream::PacketLengths::none(),
                packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
                has_functional_header_marker: false,
                has_roi_marker: false,
                data: &first_data,
            },
            TilePartPayload {
                tile_index: 3,
                tile_part_index: 1,
                tile_part_count: 2,
                coding_style: style,
                quantization: Quantization::reversible_default(style),
                component_coding_styles: component_styles(style).0,
                component_quantizations: component_styles(style).1,
                roi_shifts: crate::codestream::RoiShifts::none(),
                progression_changes: ProgressionChanges::none(),
                multiple_component_transform: None,
                part2_extensions: crate::codestream::Part2Extensions::default(),
                packet_lengths: crate::codestream::PacketLengths::none(),
                packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
                has_functional_header_marker: false,
                has_roi_marker: false,
                data: &second_data,
            },
        ];
        let grid = PacketGrid::new(2, 1, 1, vec![1], &limits).unwrap();
        let decoder = Tier1CodeBlockDecoder::new(
            1,
            1,
            1,
            crate::tier1::SubbandOrientation::Ll,
            Tier1CodingStyle::default(),
        )
        .unwrap();
        let precinct = PacketPrecinctDecoder::new(
            PacketPrecinctGeometry {
                component: 0,
                resolution: 0,
                precinct: 0,
                code_blocks_across: 1,
                code_blocks_down: 1,
                maximum_zero_bitplanes: 1,
            },
            Tier1CodingStyle::default(),
            vec![decoder],
            &limits,
        )
        .unwrap();
        let mut precincts = [precinct];
        let decoded =
            decode_progression_tile_packets(&tile_parts, &grid, &mut precincts, &limits).unwrap();
        assert_eq!(
            decoded,
            TilePacketDecode {
                tile_index: 3,
                tile_parts: 2,
                packets: 2,
                present_packets: 1,
                contributions: 1,
                segments: 1,
                passes: 1,
                packet_header_bytes: 2,
                packet_body_bytes: 5,
                payload_bytes: 7,
            }
        );
        assert_eq!(precincts[0].coordinate(), (0, 0, 0));
        assert!(precincts[0].states()[0].included());
        assert_eq!(precincts[0].states()[0].total_passes(), 1);
        assert!(precincts[0].decoders()[0].is_complete());
    }

    #[test]
    fn progression_traversal_requires_exact_payload_and_tile_part_sequence() {
        let limits = ResourceLimits::default();
        let style = coding_style(false, false);
        let grid = PacketGrid::new(2, 1, 1, vec![1], &limits).unwrap();
        let make_precinct = || {
            let decoder = Tier1CodeBlockDecoder::new(
                1,
                1,
                1,
                crate::tier1::SubbandOrientation::Ll,
                Tier1CodingStyle::default(),
            )
            .unwrap();
            PacketPrecinctDecoder::new(
                PacketPrecinctGeometry {
                    component: 0,
                    resolution: 0,
                    precinct: 0,
                    code_blocks_across: 1,
                    code_blocks_down: 1,
                    maximum_zero_bitplanes: 1,
                },
                Tier1CodingStyle::default(),
                vec![decoder],
                &limits,
            )
            .unwrap()
        };

        let trailing_data = [0, 0, 0];
        let trailing_part = [TilePartPayload {
            tile_index: 0,
            tile_part_index: 0,
            tile_part_count: 1,
            coding_style: style,
            quantization: Quantization::reversible_default(style),
            component_coding_styles: component_styles(style).0,
            component_quantizations: component_styles(style).1,
            roi_shifts: crate::codestream::RoiShifts::none(),
            progression_changes: ProgressionChanges::none(),
            multiple_component_transform: None,
            part2_extensions: crate::codestream::Part2Extensions::default(),
            packet_lengths: crate::codestream::PacketLengths::none(),
            packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
            has_functional_header_marker: false,
            has_roi_marker: false,
            data: &trailing_data,
        }];
        assert!(matches!(
            decode_progression_tile_packets(&trailing_part, &grid, &mut [make_precinct()], &limits,),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::TrailingData,
                ..
            })
        ));

        let truncated_data = [0];
        let truncated_part = [TilePartPayload {
            tile_index: 0,
            tile_part_index: 0,
            tile_part_count: 1,
            coding_style: style,
            quantization: Quantization::reversible_default(style),
            component_coding_styles: component_styles(style).0,
            component_quantizations: component_styles(style).1,
            roi_shifts: crate::codestream::RoiShifts::none(),
            progression_changes: ProgressionChanges::none(),
            multiple_component_transform: None,
            part2_extensions: crate::codestream::Part2Extensions::default(),
            packet_lengths: crate::codestream::PacketLengths::none(),
            packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
            has_functional_header_marker: false,
            has_roi_marker: false,
            data: &truncated_data,
        }];
        assert!(matches!(
            decode_progression_tile_packets(
                &truncated_part,
                &grid,
                &mut [make_precinct()],
                &limits,
            ),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::Truncated,
                ..
            })
        ));

        let empty = [];
        let invalid_parts = [
            TilePartPayload {
                tile_index: 0,
                tile_part_index: 0,
                tile_part_count: 2,
                coding_style: style,
                quantization: Quantization::reversible_default(style),
                component_coding_styles: component_styles(style).0,
                component_quantizations: component_styles(style).1,
                roi_shifts: crate::codestream::RoiShifts::none(),
                progression_changes: ProgressionChanges::none(),
                multiple_component_transform: None,
                part2_extensions: crate::codestream::Part2Extensions::default(),
                packet_lengths: crate::codestream::PacketLengths::none(),
                packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
                has_functional_header_marker: false,
                has_roi_marker: false,
                data: &empty,
            },
            TilePartPayload {
                tile_index: 0,
                tile_part_index: 2,
                tile_part_count: 2,
                coding_style: style,
                quantization: Quantization::reversible_default(style),
                component_coding_styles: component_styles(style).0,
                component_quantizations: component_styles(style).1,
                roi_shifts: crate::codestream::RoiShifts::none(),
                progression_changes: ProgressionChanges::none(),
                multiple_component_transform: None,
                part2_extensions: crate::codestream::Part2Extensions::default(),
                packet_lengths: crate::codestream::PacketLengths::none(),
                packed_packet_headers: crate::codestream::PackedPacketHeaders::none(),
                has_functional_header_marker: false,
                has_roi_marker: false,
                data: &empty,
            },
        ];
        assert!(matches!(
            decode_progression_tile_packets(&invalid_parts, &grid, &mut [make_precinct()], &limits,),
            Err(DecodeError::MalformedInput {
                kind: MalformedKind::InvalidTilePart,
                ..
            })
        ));
    }
}
