# Two independently reproduced transform discrepancies

Upstream revision: `69fe0bce9024ab5a4cb6556e3ebdf91134324148`.
Production code is unchanged. Only an additive test registration and
`src/codestream/wave86_transform_witnesses.rs` were added.

| Finding | Standard citation | Deviating code | Small native witness |
|---|---|---|---|
| Arbitrary lifting uses the wrong neighbour when the signal starts at an odd coordinate. | T.801 (06/2021), H.2.5.1 equation H-3; H.2.4.3 boundary extension; H.2.1 singleton rule. T.800 (06/2019), F.3.2 axis order. | `src/transform.rs:846-905`, `lifting_source_sum`: uses local parity rather than absolute-coordinate parity. | A reversible 1x3 level should produce `[118,208,168]`; it produces `[218,308,268]`. The kernel is decoded by the production ATK payload parser, not fabricated with test-only constructors. An even-origin control passes. |
| Irreversible synthesis leaves odd-origin singletons unchanged instead of halving them. | T.800 (06/2019), F.3.6, printed page120. | `src/transform.rs:461-469`, `inverse_9_7`: returns immediately for length<=1; reached through `inverse_horizontal_9_7` at line1304. | One Q16 sample, `131072`, should become `65536`; it remains `131072`. |

## Run

With Rust1.93.1 installed, from this directory:

```sh
cargo +1.93.1 test --locked --offline --lib wave86_ -- --nocapture --test-threads=1
```

The reference run produced **one passing control and two failing standards
assertions**, with Cargo exit101. This is the expected reproduction result, not a
passing conformance suite. `native-replay.log` contains the original output.
An offline run requires Cargo's locked dependency metadata to be available.

These are bounded native API tests, not complete encoded-image decoding or
official conformance assets. The arbitrary kernel uses a legal decoded ATK
payload (`Satk=0x10ff`); capability signalling and a complete marker/header route
are not tested. No completed Verus proof is claimed. The cited editions are the
acquired2019/2021 texts, not the repository's newer selected editions.

**Contract attribution:** the arbitrary result is also a Core
agent-assessed reproduced deviation (`482b542f6def2f270392639d`), independently
confirmed here at the standards-behaviour level. The horizontal clause explicitly
promises the project's unchanged-singleton model: this standards witness does
not falsify that narrower written clause. Its Core diagnosis remains partial
review, and both original tests and results are retained.
