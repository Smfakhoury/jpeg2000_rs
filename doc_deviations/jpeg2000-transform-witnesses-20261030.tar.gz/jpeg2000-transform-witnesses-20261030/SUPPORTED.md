# Supported decoder profiles

This document describes implementation scope, not certification. JPEG 2000 is
the ISO/IEC 15444 and corresponding ITU-T T.8xx standards family. It is not a
single RFC, and this library does not implement every part of that family.

## Inputs and outputs

| Interface | Behavior |
|---|---|
| Raw codestream | Component decoding and metadata inspection |
| JP2 | Container validation, typed component output, palette/channel mapping, and explicit color conversion |
| JPH | Branding/capability inspection and legacy/HT/mixed component decoding |
| JPX | Explicit indexed codestream, layer, composition, and frame APIs; no implicit first-codestream selection |
| JPIP | Binary messages, sparse databins, range/completeness status, reconstructed decoder inputs, and progressive updates |

Output retains component precision and signedness, image origins, subsampling,
and channel association metadata. Component sample output and converted color
output are distinct interfaces.
Selected color conversion preserves the full-image sampling phase at the
requested native DWT resolution, including regions starting between component
samples. It may decode bounded left/top context from neighboring tiles before
cropping the converted output; resource limits include that context. Component
selection continues to return the requested native component grids.

## Coding features

The implementation contains:

- Multiple tiles, components, tile parts, and quality layers.
- Signed/unsigned components with nominal precision from 1 to 38 bits.
- LRCP, RLCP, RPCL, PCRL, and CPRL progression and POC windows.
- Precincts, inclusion/zero-bitplane tag trees, coding-pass and segment lengths.
- Main/tile COD, COC, QCD, QCC, and RGN state and precedence.
  Main-header QCD may precede COD; its quantization parameters are validated
  once the coding style is available, matching tile-header handling.
- PLM/PLT packet lengths, PPM/PPT packed headers, SOP/EPH, and TLM checks.
- The five Part 1 progression orders and POC sequencing, not additional Part 2
  progression-order extensions.
- Legacy MQ and raw-bypass Tier-1 passes, coding-style routing, and Maxshift undo.
- HT cleanup, significance propagation, magnitude refinement, placeholder and
  replacement pass sets, and mixed legacy/HT routing.
- Reversible 5/3 and fixed-point irreversible 9/7 synthesis.
- Part 2 MCT/MCC/MCO transforms and segmented records; directional/general
  decomposition and kernel metadata via DFS/ADS/ATK; CRG, NLT, and CBD handling.

Every feature is subject to resource, geometry, numeric-range, and profile
validation. A list of implemented code paths is not an independent proof that
every normative requirement of their standard editions is represented.
The independent generated legacy numerical suite covers selected signed
1/2/4/7/8/9/12/16/17/24-bit monochrome profiles and unsigned
1/2/4/7/8/12/16/20/24-bit profiles. Selected signed/unsigned 25-bit cases are
qualified only at zero DWT decomposition, including tiled, layered and JP2
variants. Its RGB cases remain unsigned 8/16-bit. This evidence does not qualify the
entire implemented 1..38-bit range. See [validation](validation/VALIDATION.md)
for exact cases, metadata checks, reference-roundtrip guards and limitations.
The legacy RGB16 cases explicitly check enabled/disabled component transforms
with exact reversible output, plus enabled-transform irreversible output with
maximum error 8 and per-component RMSE 2.0. The latter budget is applied to both
the original/reference prequalification and reference/subject comparison.
Independent fixtures also check selected component-wide Maxshift upshifts and
binary-complement NLT type 3 on finite IEEE binary32 bit patterns, including
negative zero. The latter checks exact integer bit representations, not a
floating-point image API or arbitrary 32-bit pixel/color conformance.
Selected live HT RGB16 profiles also qualify enabled/disabled component
transforms, sparse/multi-code-block images, tiled nonzero origins and JPH,
with exact lossless planes and explicit engineering budgets for irreversible
output. These do not qualify every higher-precision multicomponent profile.
Additional full-range HT monochrome profiles cover signed/unsigned
25/26/28/31-bit integers at exactly two DWT decomposition levels, with exact
original/reference and reference/subject equality. Their canonical PGX originals
are transported as little-endian native RAW samples to the pinned scalar
OpenJPH tools; source, encoder input, codestream and tool hashes are recorded.
The runner validates actual SIZ geometry, component count, precision, signedness
and sampling, and COD decomposition, wavelet and explicitly requested component
transform settings before numerical comparison.

These additions came from a finite 44-candidate precision/component
qualification matrix, including zero/two-level DWT, 25/26/28/31-bit full-range
monochrome, selected higher-precision RGB and fixed irreversible budgets.
Thirteen candidates qualified, including two existing 25-bit zero-DWT legacy
controls; eleven add regression coverage. The other 31 remain unqualified
reference paths, not subject defects, passing cases or skipped qualification
tests. In particular, legacy 25-bit DWT and higher full-range precision,
HT zero-DWT at these precisions, and selected RGB17/RGB24 paths remain outside
this independent evidence. No thresholds were relaxed to admit them.
This is not completion of broader precision/component qualification: those
reference gaps remain open, and local measurements do not replace exact-candidate
three-OS evidence or the remaining integration/publication gates.

Broader selected-profile qualification retains fourteen additional qualified
profiles from a predeclared twenty-candidate matrix: component-wide Maxshift
on 20-bit grayscale and independently coded RGB16, a fixed-budget irreversible
gray16 Maxshift case, tiled/layered RGB16 with all legacy coding-style flags,
independent native-resolution sRGB/sYCC expectations,
gray/global-alpha straight and premultiplied containers/composition, and
nonzero mixed legacy/HT tiles in raw/JPH. Full/region/tile/native-resolution
checks use independently decoded native planes, never subject full-image
output as expected pixels. Color normalization and source-over expectations
use wide rational arithmetic without calling the decoder's color/composition
implementation. Exactness and fixed engineering budgets are detailed in
[validation](validation/VALIDATION.md).

The selected 47x35 RGB16, origin (3,5), 16x16-tile, three-layer
`-r 8,3,1 -M 63 -mct 1` legacy profile now requires exact independent
original/reference/subject output and full/region/tile/native-resolution
selections. This does **not** qualify every combination of coding styles,
quality layers and tiles. Selected signed12 Maxshift/layers and RGB8
irreversible layer candidates fail original/reference
budgets, and two selected three-layer prefixes are degenerate. They are not
passing or skipped qualification tests. Independent native JPX frame rendering
and ICC execution remain unavailable/excluded; selected rational composition
fixtures do not qualify arbitrary native container semantics.

## Containers, color, and JPIP

JP2 supports component bit depths, palette mappings, channel definitions,
resolution metadata, and ICC profile retention. Color execution is pinned to
enumerated values 16 (sRGB), 17 (grayscale), and 18 (sYCC), including signed,
subsampled, and origin-aware channels and alpha handling.

JPX exposes codestream/header association, layer registration, channel
association, opacity, composition instructions, timing, and indexed frame
rendering. Rendering is bounded and deterministic; it does not provide a
wall-clock animation player or interpret arbitrary application metadata.
Single-layer output retains its straight/premultiplied color samples and the
corresponding alpha flag, consistent with color conversion. Composition/frame
output is straight alpha, with transparent composed pixels represented as
transparent black. Selected global-alpha RGBA profiles are checked against
an exact rational source-over oracle; this is not colorimetric certification.

JPIP supports checked binary message headers and VBAS fields, out-of-order
fragments, duplicate/overlap consistency, final-length/completeness queries,
metadata placeholders, precinct mapping, packet reconstruction, and
transactional progressive decode. Availability and missing-range results
distinguish incomplete data from successful reconstruction.

Explicit `JpipPrecinctCodestreamPlan` transcodes are restricted to a single
tile-part with LRCP progression, inline packet headers, and no POC, PLT, or PPT
in the reconstructed input. Those plans require already-reframed headers;
original packet-length declarations must not be copied into a shortened
quality prefix. Automatic reconstruction performs its own header normalization.

## Selection

Selected APIs accept a tile index or a unique rectangular tile set, an absolute
image-reference-grid region, and a native resolution reduction. They validate
component origins/subsampling and skip unnecessary tiles or high-resolution
bodies before Tier-1. Packet framing that must be parsed is still accounted
as input/work.

## Deliberate exclusions

- Encoding.
- JPEG 2000 parts other than the selected decoder families below.
- Network transport, HTTP client/server behavior, TLS, authentication, request
  scheduling, and JPIP cache-model signaling syntax.
- An ICC color-management engine. Profiles are retained without execution.
- Implicit execution of unknown enumerated color spaces or external
  profile-number registry values.
- Arbitrary semantic interpretation of XML, UUID, and application metadata.
- General streaming incremental decoder state and internal parallelism.

Unsupported capabilities remain typed errors. Reserved fields, contradictory
signaling, and malformed structures are not accepted as supported extensions.

## Selected standards and traceability limits

| Part | Reference edition | Scope |
|---|---|---|
| 1 | ISO/IEC 15444-1:2024 / ITU-T T.800 (2024-07) | Core codestream and JP2 |
| 2 | ISO/IEC 15444-2:2023 / ITU-T T.801 (2023-08) | Codestream extensions and JPX |
| 4 | ISO/IEC 15444-4:2024 / ITU-T T.803 (2024-02) | Conformance validation target |
| 9 | ISO/IEC 15444-9:2026 / ITU-T T.808 (2026-06 catalog record) | Selected non-network JPIP behavior |
| 15 | ISO/IEC 15444-15:2019 / ITU-T T.814 (2019-06) | HTJ2K |

Part 2 implementation references include the separately acquired T.801
06/2021 text. That source is not a byte-for-byte record of the selected
08/2023 consolidation; reconciling edition differences remains a traceability
requirement. Confirm the final Part 9 publication record before claiming
edition-level conformance.

Official Part 4 assets are not bundled. Passing unit tests, generated fixtures,
or Verus does not establish official conformance. Fixed-point numerical models
need independently measured tolerances for lossy output.

See [references](REFERENCES.md), [proof boundaries](PROOFS.md), and
[validation instructions](validation/VALIDATION.md).
