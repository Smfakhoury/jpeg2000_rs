import copy
import json
import os
import re
import shutil
import subprocess
import sys
import unittest
import uuid
from pathlib import Path
from unittest import mock

from jsonschema import SchemaError

VALIDATION = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(VALIDATION))

import framework


class WorkingFiles(unittest.TestCase):
    def setUp(self):
        self.work = framework.RESULTS_DIR / "test-work" / uuid.uuid4().hex
        self.work.mkdir(parents=True)
        self.addCleanup(shutil.rmtree, self.work)

    def subject(self):
        path = self.work / "subject"
        accepted = {
            entry["id"] for entry in framework.load_manifest()["entries"]
            if entry["expected"] == "accept"
        }
        path.write_text(
            f"#!{sys.executable}\n"
            "import sys\nfrom pathlib import Path\n"
            f"accepted = {accepted!r}\n"
            "if Path(sys.argv[-1]).stem in accepted:\n"
            "    print('IMAGE\\n1 1 1\\n1\\t1\\t8\\t0\\tunsigned\\t128')\n"
            "else:\n"
            "    print('ERR\\tMalformedInput\\texpected rejection')\n"
            "    raise SystemExit(1)\n"
        )
        path.chmod(0o700)
        return path

    def oracle_config(self):
        config = json.loads((framework.VALIDATION / "oracles.json").read_text())
        config["oracles"] = config["oracles"][:1]
        path = self.work / "oracles.json"
        path.write_text(json.dumps(config))
        return path

    def external_manifest(self):
        archive = self.work / "suite.bin"
        vector = self.work / "vector.j2k"
        archive.write_bytes(b"synthetic archive fixture, not an official asset")
        vector.write_bytes(b"synthetic vector fixture, not an official asset")
        manifest = {
            "schema_version": 1,
            "profile_id": framework.PROFILE_ID,
            "suite": {
                "source_url": "https://example.invalid/synthetic-suite",
                "acquired_at": "2026-10-18T00:00:00Z",
                "access_status": "authorized-internal",
                "license": {
                    "status": "approved-internal-use",
                    "reviewed_at": "2026-10-18T00:00:00Z",
                    "redistribution_permitted": False,
                    "basis": "synthetic test fixture",
                },
                "archive": {
                    "path": archive.name,
                    "bytes": archive.stat().st_size,
                    "sha256": framework.sha256_file(archive),
                },
                "selection": {
                    "complete": True,
                    "applicable_vector_count": 1,
                    "basis": "synthetic test fixture",
                },
            },
            "entries": [{
                "id": "private-fixture-id",
                "identifier_public": False,
                "path": vector.name,
                "sha256": framework.sha256_file(vector),
                "bytes": vector.stat().st_size,
                "format": "raw",
                "operation": "decode",
                "applicable": True,
                "expected": {"accepted": False, "category": "MalformedInput"},
            }],
        }
        path = self.work / "official-vector-manifest.json"
        path.write_text(json.dumps(manifest))
        return path, manifest


class FrameworkTests(WorkingFiles):
    def test_inventory_source_indexes_are_fresh_per_call_and_preserve_const_functions(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = coverage["requirements"][:1]
        entry = coverage["requirements"][0]
        reference = {**entry["proof_refs"][0], "symbol": "coverage_cache_overlap"}
        entry["proof_refs"].append(reference)
        source = (framework.ROOT / reference["path"]).resolve()
        original = source.read_text()
        read_text = Path.read_text
        current = original + "\npub const fn coverage_cache_overlap() -> bool { true }\n"
        reads = []

        def altered(path, *args, **kwargs):
            if path == source:
                reads.append(path)
                return current
            return read_text(path, *args, **kwargs)

        with mock.patch.object(Path, "read_text", altered):
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            self.assertEqual(len(reads), 1)
            current = original + "\npub const fn coverage_cache_overlap_suffix() -> bool { true }\n"
            with self.assertRaisesRegex(ValueError, "missing normative evidence symbol"):
                framework.validate_normative_coverage(coverage)
            current = original + "\npub const fn coverage_cache_overlap() -> bool { true }\n"
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            self.assertEqual(len(reads), 3)

    def test_schema_cache_is_content_bound_and_validates_every_instance(self):
        schema = self.work / "changing.schema.json"
        schema.write_text(json.dumps({"type": "integer"}))
        framework.validate_schema(schema, 7)
        with self.assertRaises(ValueError):
            framework.validate_schema(schema, "not-an-integer")
        schema.write_text(json.dumps({"type": "string"}))
        framework.validate_schema(schema, "now-a-string")
        with self.assertRaises(ValueError):
            framework.validate_schema(schema, 7)
        schema.write_text(json.dumps({"type": "invalid-schema-type"}))
        with self.assertRaises(SchemaError):
            framework.validate_schema(schema, 7)

    def test_inventory_caller_indexes_are_fresh_and_preserve_original_word_matching(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in coverage["requirements"]
                     if item["id"] == "part1-complete-native-packet-length-admission")
        coverage["requirements"] = [entry]
        entry["implementation_refs"] = [{"path": "src/decode.rs", "symbol": "coverage_index_caller"}]
        source = (framework.ROOT / "src/decode.rs").resolve()
        original = source.read_text()
        self.assertNotRegex(original, r"\bparse_plm\s*\(")
        read_text = Path.read_text
        current = original
        reads = []

        def altered(path, *args, **kwargs):
            if path == source:
                reads.append(path)
                return current
            return read_text(path, *args, **kwargs)

        cases = [
            ("parse_plm ()", True),
            ("r#parse_plm\n()", True),
            ('"parse_plm()"', True),
            ("misparse_plm()", False),
            ("parse_plm_suffix()", False),
            ("\u00e9parse_plm()", False),
            ("parse_plm::<T>()", False),
            ("parse_plm()", True),
        ]
        with mock.patch.object(Path, "read_text", altered):
            for expression, accepted in cases:
                with self.subTest(expression=expression):
                    current = original + (
                        "\nfn coverage_index_caller() {\n"
                        f"    validate_packet_lengths(); {expression};\n"
                        "}\n"
                    )
                    if accepted:
                        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
                    else:
                        with self.assertRaisesRegex(ValueError, "not used by claimed implementation: parse_plm"):
                            framework.validate_normative_coverage(coverage)
        self.assertEqual(len(reads), len(cases))

    def test_generation_is_deterministic_and_complete(self):
        first = framework.build_manifest(framework.generated_cases())
        self.assertEqual(first, framework.build_manifest(framework.generated_cases()))
        self.assertEqual(len(first["entries"]), 17)
        self.assertEqual({entry["format"] for entry in first["entries"]}, {"raw", "jp2", "jph", "jpx", "jpip"})
        framework.generate_corpus(check=True)
        self.assertEqual(framework.verify_manifest()["status"], "passed")

    def test_manifest_rejects_bad_hash_and_restricted_assets(self):
        for field, value in (("sha256", "0" * 64), ("classification", "restricted")):
            manifest = framework.load_manifest()
            manifest["entries"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                framework.verify_manifest(manifest)

    def test_normalization_is_stable(self):
        output = b"IMAGE\n1 1 1\n1\t1\t8\t0\tunsigned\t128\n"
        parsed = framework.parse_subject_output(output, b"", 0)
        self.assertTrue(parsed["accepted"])
        self.assertEqual(framework.normalized_hash(parsed), framework.normalized_hash(parsed))
        first = framework.parse_subject_output(b"ERR\tMalformedInput\tat byte 1\n", b"", 1)
        second = framework.parse_subject_output(b"ERR\tMalformedInput\tat byte 9\n", b"", 1)
        self.assertEqual(first, second)

    def test_binary_pnm_normalization(self):
        path = self.work / "output.pnm"
        path.write_bytes(b"P6\n1 1\n255\n\x01\x02\x03")
        parsed = framework.parse_pnm(path)
        self.assertEqual([c["samples"] for c in parsed["image"]["components"]], [[1], [2], [3]])

    def test_inventory_checks_present_items_without_exact_progress_counts(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        coverage["requirements"] = coverage["requirements"][:1]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")

    def test_inventory_rejects_missing_evidence_and_shadow_only_links(self):
        original = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        for field in ("implementation_refs", "spec_refs", "contract_refs", "proof_refs", "test_refs"):
            coverage = copy.deepcopy(original)
            coverage["requirements"][0][field][0]["symbol"] = "unchecked_shadow"
            with self.subTest(field=field), self.assertRaises(ValueError):
                framework.validate_normative_coverage(coverage)
        coverage = copy.deepcopy(original)
        coverage["requirements"][0]["implementation_refs"] = [{"path": "src/error.rs", "symbol": "DecodeError"}]
        with self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
            framework.validate_normative_coverage(coverage)

    def test_inventory_checks_named_result_equalities_not_just_model_mentions(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("verus_spec(output =>", "verus_spec(unrelated =>"),
            ("ensures output as nat ==", "ensures 0 as nat <="),
            ("ensures output as nat == crate::specs::part2_source_over_alpha_numerator",
             "ensures output as nat == crate::specs::unlisted_model"),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/refinement.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_requires_named_result_and_final_state_in_mutation_relation(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        coverage["requirements"][0]["contract_refs"] = [{
            "path": "src/refinement.rs", "symbol": "try_store_composition_sample",
        }]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("verus_spec(stored =>", "verus_spec(unrelated =>"),
            ("ensures (stored, final(samples)@)", "ensures (true, final(samples)@)"),
            ("ensures (stored, final(samples)@)", "ensures (stored, old(samples)@)"),
            ("ensures (stored, final(samples)@)", "ensures stored"),
            ("== crate::specs::part2_composition_store", "== crate::specs::unlisted_model"),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/refinement.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_requires_known_complete_projection_of_the_bound_result(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-layer-input-construction"
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("ensures layer_channels_outcome(result)", "ensures layer_channels_outcome(unrelated)"),
            ("ensures layer_channels_outcome(result)", "ensures unlisted_projection(result)"),
            ("ensures layer_channels_outcome(result)", "ensures owned_layer_outcome(result)"),
            ("ensures owned_layer_outcome(result)", "ensures layer_channels_outcome(result)"),
            ("ensures owned_layer_outcome(result)", "ensures owned_layer_outcome(unrelated)"),
            ("== crate::specs::part2_layer_input(", "== crate::specs::unlisted_model("),
            ("== crate::specs::part2_owned_layer_input(", "== crate::specs::unlisted_model("),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/jpx.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_checks_each_complete_frame_stage_result_projection(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-normalized-layer-frame-stages"
        ]
        requirement = coverage["requirements"][0]
        requirement["implementation_refs"] = [
            {"path": "src/jpx.rs", "symbol": "inspect_file"},
            {"path": "src/jpx.rs", "symbol": "render_inspected_frame"},
            {"path": "src/jpx.rs", "symbol": "render_normalized_frame"},
            {"path": "src/jpx.rs", "symbol": "render_decoded_layers"},
            {"path": "src/color.rs", "symbol": "from_composited"},
        ]
        read_text = Path.read_text
        for relative, symbol, projection in (
            ("src/jpx.rs", "render_decoded_layers", "crate::color::converted_image_result"),
            ("src/jpx.rs", "select_frame_instructions", "frame_selection_result"),
            ("src/jpx.rs", "build_timeline", "timeline_frames_result"),
            ("src/jpx.rs", "render_normalized_frame", "crate::color::converted_image_result"),
            ("src/color.rs", "from_layer", "converted_image_result"),
            ("src/color.rs", "from_composited", "converted_image_result"),
        ):
            requirement["contract_refs"] = [{"path": relative, "symbol": symbol}]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            text = read_text(framework.ROOT / relative)
            signature = re.search(rf"\bfn\s+{re.escape(symbol)}\b", text).start()
            start = text.rfind("#[cfg_attr", 0, signature)
            contract = text[start:signature]
            for before, after in (
                (f"ensures {projection}(result)", f"ensures {projection}(unrelated)"),
                (f"ensures {projection}(result)", "ensures unlisted_projection(result)"),
                (f"ensures {projection}(result)", "ensures owned_layer_outcome(result)"),
                ("== crate::specs::", "<= crate::specs::"),
            ):
                self.assertIn(before, contract)
                replacement = contract.replace(before, after)

                def altered(path, *args, **kwargs):
                    original = read_text(path, *args, **kwargs)
                    if path == framework.ROOT / relative:
                        return original[:start] + replacement + original[signature:]
                    return original

                with self.subTest(symbol=symbol, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_checks_complete_reconstruction_and_sequence_projections(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        names = {"inverse_quantize_values", "inverse_quantize_plane", "inverse_5_3", "interleave"}
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if any(ref["path"] == "src/transform.rs"
                   and ref["symbol"].rsplit("::", 1)[-1] in names
                   for ref in item["contract_refs"])
        ]
        self.assertTrue(coverage["requirements"])
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        mutations = []
        for projection in ("reconstruction_outcome", "sequence_outcome"):
            mutations.extend((
                (f"ensures {projection}(result)", f"ensures {projection}(unrelated)"),
                (f"ensures {projection}(result)", "ensures unlisted_projection(result)"),
                (f"ensures {projection}(result)", "ensures owned_layer_outcome(result)"),
            ))
        for model in ("part1_inverse_integer_quantization", "part1_inverse_quantization",
                      "part1_inverse_five_three", "part1_interleaved"):
            mutations.append((f"== crate::specs::{model}(", "== crate::specs::unlisted_model("))
        original = read_text(framework.ROOT / "src/transform.rs")
        for before, after in mutations:
            self.assertIn(before, original)

            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/transform.rs" else text

            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_checks_standard_profile_bound_return_projections(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/transform.rs"
        original = source.read_text()
        read_text = Path.read_text
        for function, projection, model in (
            ("inverse_9_7", "sequence_outcome", "part1_inverse_nine_seven"),
            ("inverse_horizontal_5_3", "reconstruction_outcome", "part1_inverse_horizontal"),
            ("inverse_horizontal_9_7", "reconstruction_outcome", "part1_inverse_horizontal"),
            ("inverse_vertical_5_3", "reconstruction_outcome", "part1_inverse_vertical"),
            ("inverse_vertical_9_7", "reconstruction_outcome", "part1_inverse_vertical"),
            ("inverse_level_5_3", "reconstruction_outcome", "part1_inverse_level"),
            ("inverse_level_9_7", "reconstruction_outcome", "part1_inverse_level"),
            ("convert_samples", "sequence_outcome", "part1_convert_samples"),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if any(ref == {"path": "src/transform.rs", "symbol": function}
                       for ref in item["contract_refs"])
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            coverage["requirements"][0]["contract_refs"] = [
                {"path": "src/transform.rs", "symbol": function}
            ]
            with self.subTest(function=function, outcome="complete"):
                self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            end = original.index(f"pub fn {function}(")
            start = original.rfind("#[cfg_attr", 0, end)
            self.assertGreaterEqual(start, 0)
            contract = original[start:end]
            wrong_projection = (
                "sequence_outcome" if projection == "reconstruction_outcome"
                else "reconstruction_outcome"
            )
            for before, after in (
                (f"ensures {projection}(result)", f"ensures {projection}(unrelated)"),
                (f"ensures {projection}(result)", "ensures unlisted_projection(result)"),
                (f"ensures {projection}(result)", f"ensures {wrong_projection}(result)"),
                ("verus_spec(result =>", "verus_spec(unrelated =>"),
                (f"ensures {projection}(result)", "ensures result.is_ok()"),
                (f"== crate::specs::{model}(", "== crate::specs::unlisted_model("),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[end:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(function=function, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_requires_complete_normalized_plane_bound_result(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part1-complete-normalized-component-plane"
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("ensures normalized_plane_result(result)", "ensures normalized_plane_result(unrelated)"),
            ("ensures normalized_plane_result(result)", "ensures unlisted_projection(result)"),
            ("ensures normalized_plane_result(result)", "ensures converted_image_result(result)"),
            ("ensures normalized_plane_result(result)", "ensures result.is_ok()"),
            ("== crate::specs::color_normalize_component(", "== crate::specs::unlisted_model("),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/color.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_requires_complete_channel_layout_bound_result(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-complete-component-channel-layout"
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("ensures channel_layout_result(result)", "ensures channel_layout_result(unrelated)"),
            ("ensures channel_layout_result(result)", "ensures unlisted_projection(result)"),
            ("ensures channel_layout_result(result)", "ensures normalized_plane_result(result)"),
            ("ensures channel_layout_result(result)", "ensures result.is_ok()"),
            ("== crate::specs::color_channel_layout(", "== crate::specs::unlisted_model("),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/color.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_binds_all_complete_cleanup_plane_and_raw_interface_recipes(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        original = source.read_text()
        recipes = (
            ("reconstruct_ht_cleanup_plane", "ht_cleanup_plane", None),
            ("HtCleanupPlaneReconstruction::sample", "ht_plane_sample", "ht_plane_view"),
            ("HtCleanupPlaneReconstruction::quad", "ht_plane_quad", "ht_plane_view"),
            ("HtCleanupPlaneReconstruction::finish", "ht_plane_finish", "ht_plane_view"),
            ("complete_ht_kappa", "ht_complete_kappa", None),
            ("code_block_plane_from_dimensions", "tier1_empty_plane", None),
            ("coefficient_from_magnitude", "tier1_coefficient_new_outcome", None),
            ("CoefficientState::set_magnitude", "tier1_set_magnitude", "coefficient_state_view"),
            ("CodeBlockPlane::mark_significant_magnitude", "tier1_mark_coefficient", "code_block_plane_view"),
            ("ht_statistics_zero", "tier1_statistics_zero", None),
            ("Tier1PassStatistics::scanned", "tier1_statistics_increment", "*"),
            ("Tier1PassStatistics::decoded_symbols", "tier1_statistics_increment", "*"),
            ("Tier1PassStatistics::became_significant", "tier1_statistics_increment", "*"),
            ("CodeBlockPlane::width", "tier1_raw_plane_width", None),
            ("CodeBlockPlane::height", "tier1_raw_plane_height", None),
            ("CodeBlockPlane::coefficients", "tier1_raw_plane_coefficients", None),
            ("CodeBlockPlane::coefficient", "tier1_raw_plane_coefficient", None),
            ("CodeBlockPlane::index", "tier1_raw_plane_index", None),
            ("CoefficientState::wide_magnitude", "tier1_coefficient_limbs", None),
            ("CoefficientState::signed_magnitude", "tier1_raw_signed_coefficient", None),
        )
        self.assertEqual(len(recipes), 20)
        for symbol, model, view in recipes:
            reference = {"path": "src/tier1.rs", "symbol": symbol}
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"] if reference in item["contract_refs"]
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            entry = coverage["requirements"][0]
            entry["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(original, symbol)
            self.assertIsNotNone(header)
            signature = original.find("fn", header.start(), header.end())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            prefix, post = contract.split("ensures", 1)
            unbound, changed = re.subn(r"\bresult\b", "unrelated", post, count=1)
            self.assertEqual(changed, 1)
            partial, changed = re.subn(r"\bresult\b", "result.is_ok()", post, count=1)
            self.assertEqual(changed, 1)
            mutations = [
                ("unbound result", prefix + "ensures" + unbound),
                ("partial result", prefix + "ensures" + partial),
                ("unknown model", contract.replace(f"crate::specs::{model}(", "crate::specs::unlisted_model(")),
                ("inequality", contract.replace("== crate::specs::", "<= crate::specs::", 1)),
            ]
            wrong_model = next(item["symbol"] for item in entry["spec_refs"] if item["symbol"] != model)
            mutations.append(("wrong listed model", contract.replace(
                f"crate::specs::{model}(", f"crate::specs::{wrong_model}(", 1,
            )))
            if view is not None:
                final_pattern = (r"\*\s*final\(\s*self\s*\)" if view == "*"
                                 else re.escape(view) + r"\(\s*final\(\s*self\s*\)\s*\)")
                replacement = "*old(self)" if view == "*" else f"{view}(old(self))"
                altered, changed = re.subn(final_pattern, replacement, contract, count=1)
                self.assertEqual(changed, 1)
                mutations.append(("old instead of final state", altered))
                old_pattern = (r"\*\s*old\(\s*self\s*\)" if view == "*"
                               else re.escape(view) + r"\(\s*old\(\s*self\s*\)\s*\)")
                replacement = "*final(self)" if view == "*" else f"{view}(final(self))"
                altered, changed = re.subn(old_pattern, replacement, contract, count=1)
                self.assertEqual(changed, 1)
                mutations.append(("final instead of input state", altered))
            for label, modified_contract in mutations:
                self.assertNotEqual(modified_contract, contract)
                modified = original[:start] + modified_contract + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, mutation=label), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_binds_complete_palette_components_to_actual_results_and_inputs(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(
            item for item in original_coverage["requirements"]
            if item["id"] == "part2-complete-native-palette-component"
        )
        read_text = Path.read_text
        for relative, symbol, projection, model, arguments in (
            ("src/decode.rs", "copy_typed_component", "crate::image::typed_component_output",
             "part2_typed_component_copy", (
                ("typed_component_output_view(source)", "typed_component_output_view(unrelated)"),
            )),
            ("src/decode.rs", "map_palette_component", "crate::image::typed_component_output",
             "part2_palette_component", (
                ("typed_component_view(source)", "typed_component_view(unrelated)"),
                ("palette_view(palette)", "palette_view(unrelated)"),
                ("palette), column", "palette), 0"),
            )),
            ("src/decode.rs", "palette_modulus", None, "part2_palette_modulus", (
                ("part2_palette_modulus(precision)", "part2_palette_modulus(0)"),
            )),
            ("src/decode.rs", "invalid_jp2_output", None, "part2_color_input_error", ()),
            ("src/image.rs", "typed_component_from_parts", "typed_component_value_view",
             "part2_typed_component_from_parts", (
                ("width, height, info", "height, width, info"),
                ("typed_samples_view(&samples)", "typed_samples_view(&unrelated)"),
            )),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            reference = {"path": relative, "symbol": symbol}
            self.assertIn(reference, entry["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / relative
            original = source.read_text()
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            result = re.search(r"\bverus_spec\(\s*(\w+)\s*=>", contract)[1]
            expression = f"{projection}({result})" if projection else result
            wrong_model = (
                "part2_typed_component_copy" if model == "part2_palette_component"
                else "part2_palette_component"
            )
            mutations = [
                (f"ensures {expression}", "ensures unrelated"),
                (f"ensures {expression}", f"ensures {result}.is_ok()"),
                (f"ensures {expression}", f"ensures {result}.is_ok() ==> {expression}"),
                (f"crate::specs::{model}(", f"crate::specs::{wrong_model}("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *arguments,
            ]
            if projection:
                mutations.extend((
                    (f"ensures {expression}", f"ensures {projection}(unrelated)"),
                    (f"ensures {expression}", f"ensures unlisted_projection({result})"),
                ))
            for before, after in mutations:
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after, 1) + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_binds_complete_header_and_precinct_native_results(self):
        self._assert_complete_packet_contract_bindings({
            "part1-complete-native-header-tree-producers", "part1-complete-native-precinct-composition",
        }, framework._PACKET_HEADER_CONTRACTS, 39)

    def test_inventory_binds_actual_packed_inputs_and_full_progression_results(self):
        support = {
            ("src/packet.rs", "PacketGrid::selected_packet_count"),
            ("src/packet.rs", "decode_progression_tile_packets"),
        }
        recipes = {key: value for key, value in framework._PACKET_PROGRESSION_CONTRACTS.items() if key not in support}
        self._assert_complete_packet_contract_bindings({
            "part1-complete-native-packed-header-length-inputs", "part1-complete-native-grid-progression-composition",
        }, recipes, 40)
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in coverage["requirements"]
                     if item["id"] == "part1-complete-native-grid-progression-composition")
        for path, symbol in support:
            reference = {"path": path, "symbol": symbol}
            self.assertIn(reference, entry["proof_refs"])
            self.assertNotIn(reference, entry["contract_refs"])

    def test_inventory_binds_all_final_packet_wrappers_and_native_execution_bundle(self):
        self._assert_complete_packet_contract_bindings({
            "part1-complete-native-public-packet-boundaries",
        }, framework._PACKET_WRAPPER_CONTRACTS, 14)

    def test_inventory_binds_complete_coefficient_reconstruction_and_real_mct_owners(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-coefficient-component-reconstruction"},
            framework._RECONSTRUCTION_CONTRACTS, 15,
        )

    def test_inventory_binds_complete_native_chroma_key_owner_and_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-layer-chroma-key"},
            framework._LAYER_STATE_CONTRACTS, 1,
        )

    def test_inventory_binds_complete_native_registration_geometry_and_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-registration-geometry"},
            framework._LAYER_REGISTRATION_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_native_registration_sampling_and_all_mutable_buffers(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-registration-pixel"},
            framework._LAYER_SAMPLING_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_native_registration_rows_and_whole_producer(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-registration-raster"},
            framework._LAYER_TRAVERSAL_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_native_raw_chroma_key_normalization(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-chroma-normalization"},
            framework._LAYER_KEY_CONTRACTS, 1,
        )

    def test_inventory_binds_complete_native_component_key_preparation_and_mutable_offsets(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-component-chroma-preparation"},
            framework._LAYER_COMPONENT_KEY_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_native_local_opacity_and_missing_sample_policy(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-local-opacity"},
            framework._LAYER_OPACITY_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_native_external_alpha_and_all_scratch_state(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-external-alpha"},
            framework._LAYER_EXTERNAL_ALPHA_CONTRACTS, 3,
        )

    def test_inventory_binds_actual_decoder_style_and_component_depth_admission(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-decoder-style-admission"},
            framework._DECODER_ADMISSION_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_actual_layout_admission_and_native_header_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-layout-execution-admission"},
            framework._DECODER_LAYOUT_CONTRACTS, 4,
        )

    def test_inventory_binds_complete_raw_tile_component_geometry_and_shared_scalar(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-tile-component-geometry"},
            framework._TILE_COMPONENT_GEOMETRY_CONTRACTS, 3,
        )

    def test_inventory_binds_complete_raw_resolution_styles_and_ordered_scale_traversal(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-resolution-style"},
            framework._RESOLUTION_STYLE_CONTRACTS, 3,
        )

    def test_inventory_binds_complete_raw_resolution_geometry_and_public_boundary(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-resolution-geometry"},
            framework._RESOLUTION_GEOMETRY_CONTRACTS, 4,
        )

    def test_inventory_binds_complete_actual_component_packet_grid_producer_and_limits(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-component-packet-grid"},
            framework._PACKET_GRID_PRODUCER_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_raw_subband_admission_and_quantization_boundaries(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-subband-admission"},
            framework._SUBBAND_ADMISSION_CONTRACTS, 4,
        )

    def test_inventory_binds_complete_actual_subband_vectors_and_public_boundary(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-subband-vector"},
            framework._SUBBAND_VECTOR_CONTRACTS, 4,
        )

    def test_inventory_binds_complete_raw_decoder_initialization_and_all_policy_state(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-decoder-initialization"},
            framework._DECODER_INITIALIZATION_CONTRACTS, 4,
        )

    def test_decoder_unit_state_contracts_reject_nonunit_return_signatures(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        read_text = Path.read_text
        for relative, symbols in (
            ("src/tier1.rs", ("set_force_high_throughput", "set_multiple_ht_sets_allowed")),
            ("src/codestream.rs", ("replace_mct_array", "replace_mct_record")),
        ):
            source = framework.ROOT / relative
            original = source.read_text()
            for symbol in symbols:
                start = original.index(f"fn {symbol}(")
                end = original.index(")", start) + 1
                for return_type in ("u8", "()"):
                    modified = original[:end] + f" -> {return_type}" + original[end:]
                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)
                    with self.subTest(symbol=symbol, return_type=return_type), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "actual implicit unit return"):
                        framework.validate_normative_coverage(coverage)

    def test_inventory_binds_actual_codeblock_geometry_and_configured_decoder_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-codeblock-planning"},
            framework._CODEBLOCK_PLANNING_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_precinct_initialization_and_complete_owned_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-precinct-initialization"},
            framework._PRECINCT_INITIALIZATION_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_component_plan_metadata_raw_owners_and_selection(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-component-plan-metadata"},
            framework._COMPONENT_PLAN_METADATA_CONTRACTS, 3,
        )

    def test_inventory_binds_real_codeblock_vectors_owned_prefix_and_selected_limits(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-codeblock-vectors"},
            framework._CODEBLOCK_VECTOR_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_subband_lattice_execution_owned_prefix_and_limits(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-subband-execution"},
            framework._SUBBAND_EXECUTION_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_complete_precinct_plan_raw_source_range_and_all_owned_state(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-precinct-planning"},
            framework._PRECINCT_PLANNING_CONTRACTS, 1,
        )

    def test_inventory_binds_actual_resolution_plan_metadata_and_raw_precinct_origins(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-resolution-planning"},
            framework._RESOLUTION_PLANNING_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_raw_owner_component_and_selected_tile_plan_production(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-component-tile-planning"},
            framework._COMPONENT_TILE_PLANNING_CONTRACTS, 3,
        )

    def test_inventory_binds_actual_byte_execution_to_complete_reconstruction_without_plane_results(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-packet-reconstruction-join"},
            framework._PACKET_RECONSTRUCTION_CONTRACTS, 1,
        )

    def test_inventory_binds_actual_full_selected_global_accounting_and_raw_placement_counts(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-layout-accounting"},
            framework._LAYOUT_ACCOUNTING_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_raw_tile_metadata_mct_identity_and_reduction_policy(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-tile-decode-metadata"},
            framework._TILE_METADATA_CONTRACTS, 9,
        )

    def test_inventory_binds_actual_raw_capability_lookup_and_ht_profile_policy(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-ht-profile-policy"},
            framework._PROFILE_POLICY_CONTRACTS, 8,
        )

    def test_inventory_binds_complete_actual_raw_tile_decode_without_plan_or_sample_results(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-tile-decoding"},
            framework._RAW_TILE_DECODING_CONTRACTS, 1,
        )

    def test_inventory_binds_actual_owned_payload_copy_and_ordered_tile_collection(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-owned-tile-collection"},
            framework._TILE_COLLECTION_CONTRACTS, 2,
        )

    def test_contract_method_resolution_handles_clone_trait_and_rejects_other_or_ambiguous_impls(self):
        source = """impl<'a> Clone for TilePartPayload<'a> {
    fn clone(&self) -> Self { todo!() }
}
"""
        header = framework._coverage_function_header(source, "TilePartPayload::clone")
        self.assertIsNotNone(header)
        self.assertEqual(header.group().strip() if header is not None else None, "fn clone")
        self.assertIsNone(framework._coverage_function_header(source, "Other::clone"))
        self.assertIsNone(framework._coverage_function_header(source.replace("Clone for", "OtherTrait for"), "TilePartPayload::clone"))
        inherent = """impl<'a> TilePartPayload<'a> {
    fn clone(&self) -> Self { todo!() }
}
"""
        self.assertIsNone(framework._coverage_function_header(source + inherent, "TilePartPayload::clone"))

    def test_inventory_retains_raw_native_tile_contract_while_binding_owned_semantics(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-owned-payload-semantics"},
            framework._RAW_TILE_DECODING_CONTRACTS, 1,
        )

    def test_inventory_binds_complete_actual_full_selected_layouts_without_decoded_banks(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-full-selected-layout-decoding"},
            framework._LAYOUT_DECODING_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_typed_output_shape_admission_without_valid_image_premises(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-typed-output-shape-admission"},
            framework._OUTPUT_SHAPE_CONTRACTS, 1,
        )

    def test_inventory_binds_actual_source_derived_nonlinear_selection_and_complete_regions(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-region-production"},
            framework._NONLINEAR_REGIONS_CONTRACTS, 3,
        )

    def test_inventory_binds_actual_nonlinear_arithmetic_exact_results_and_error_frontiers(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-arithmetic"},
            framework._NONLINEAR_ARITHMETIC_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_raw_nonlinear_lut_samples_without_lookup_result_banks(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-lut"},
            framework._NONLINEAR_LUT_CONTRACTS, 5,
        )

    def test_inventory_binds_actual_nonlinear_log_exp_normalizers_series_and_reciprocal(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-log-exp"},
            framework._NONLINEAR_LOG_EXP_CONTRACTS, 6,
        )

    def test_inventory_binds_complete_actual_nonlinear_samples_without_supplied_parameter_or_sample_results(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-scalar"},
            framework._NONLINEAR_SCALAR_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_nonlinear_owner_mutation_and_failure_prefix_without_result_banks(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-nonlinear-owner-mutation"},
            framework._NONLINEAR_APPLICATION_CONTRACTS, 2,
        )

    def test_inventory_binds_complete_actual_full_selected_typed_layout_results_without_banks(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-full-selected-typed-layout-decoding"},
            framework._TYPED_LAYOUT_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_raw_codestream_reader_inputs_bytes_and_complete_error_state(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-codestream-reader"},
            framework._CODESTREAM_READER_CONTRACTS, 10,
        )

    def test_inventory_binds_actual_raw_siz_full_geometry_and_component_payload_result(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-siz-geometry"},
            framework._SIZ_GEOMETRY_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_raw_cod_bytes_to_complete_style_and_precinct_defaults(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-coding-style"},
            framework._CODING_STYLE_BYTES_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_raw_component_index_and_complete_coc_style(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-component-style"},
            framework._COMPONENT_STYLE_BYTES_CONTRACTS, 3,
        )

    def test_inventory_binds_actual_raw_qcd_qcc_results_and_all_unused_quantization_steps(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-quantization"},
            framework._QUANTIZATION_BYTES_CONTRACTS, 3,
        )

    def test_inventory_binds_raw_rgn_crg_metadata_budget_and_complete_owner_frames(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-component-markers"},
            framework._COMPONENT_MARKER_BYTES_CONTRACTS, 5,
        )

    def test_inventory_binds_raw_dfs_ads_payloads_first_replacement_and_all_owner_frames(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-decomposition-bytes"},
            framework._DECOMPOSITION_BYTES_CONTRACTS, 5,
        )

    def test_inventory_binds_raw_cbd_partial_depth_prefix_and_complete_owner_frames(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-component-depth-bytes"},
            framework._COMPONENT_DEPTH_BYTES_CONTRACTS, 1,
        )

    def test_inventory_binds_raw_cap_profile_words_and_actual_bit_count_without_parsed_banks(self):
        self._assert_complete_packet_contract_bindings(
            {"part15-complete-native-raw-profile-bytes"},
            framework._PROFILE_BYTES_CONTRACTS, 4,
        )

    def test_inventory_binds_raw_nlt_gamma_points_parameters_and_complete_registry_owner_frames(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-nonlinear-bytes"},
            framework._NONLINEAR_BYTES_CONTRACTS, 5,
        )

    def test_inventory_binds_raw_tlm_all_three_mutable_frames_and_partial_length_prefix(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-tile-length-bytes"},
            framework._TILE_LENGTH_BYTES_CONTRACTS, 1,
        )

    def test_inventory_binds_raw_atk_all_coefficient_bytes_steps_and_complete_registry_owner_frames(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-kernel-bytes"},
            framework._KERNEL_BYTES_CONTRACTS, 4,
        )

    def test_inventory_binds_raw_poc_all_record_fields_width_fallback_and_error_inputs(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-raw-progression-bytes"},
            framework._PROGRESSION_BYTES_CONTRACTS, 3,
        )

    def test_inventory_binds_actual_progression_shape_bitmap_failure_frames_and_complete_admission(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-progression-admission"},
            framework._PROGRESSION_ADMISSION_CONTRACTS, 6,
        )

    def test_inventory_binds_raw_mco_mcc_routes_membership_and_complete_failure_cursor(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-transform-routing-bytes"},
            framework._TRANSFORM_ROUTING_BYTES_CONTRACTS, 3,
        )

    def test_inventory_binds_raw_mcc_complete_collections_signed_offsets_limits_and_parallel_checks(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-transform-collection-bytes"},
            framework._TRANSFORM_COLLECTION_BYTES_CONTRACTS, 5,
        )

    def test_inventory_binds_actual_mcc_fragment_pending_completed_and_real_record_results(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-mcc-fragment-production"},
            framework._COLLECTION_FRAGMENT_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_mct_fragment_descriptors_frames_limits_and_real_array_results(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-mct-fragment-production"},
            framework._TRANSFORM_FRAGMENT_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_mct_registry_last_only_admission_replacement_and_unique_reference(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-mct-registry-production"},
            framework._TRANSFORM_REGISTRY_CONTRACTS, 7,
        )

    def test_inventory_binds_actual_mct_graph_raw_parameters_checked_shapes_and_complete_resolved_fields(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-mct-graph-production"},
            framework._TRANSFORM_GRAPH_CONTRACTS, 4,
        )

    def test_inventory_binds_actual_packed_fragment_counters_bytes_work_and_ppm_frame_producers(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-packed-header-byte-production"},
            framework._PACKED_HEADER_BYTES_CONTRACTS, 2,
        )

    def test_inventory_binds_actual_packet_length_admission_full_reader_and_plm_group_production(self):
        self._assert_complete_packet_contract_bindings(
            {"part1-complete-native-packet-length-admission"},
            framework._PACKET_LENGTH_ADMISSION_CONTRACTS, 2,
        )

    def test_inventory_tracks_relocated_parser_tests_and_rejects_stale_or_missing_bindings(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in coverage["requirements"]
                     if item["id"] == "part1-complete-native-packet-length-admission")
        coverage["requirements"] = [entry]
        self.assertTrue(entry["test_refs"])
        self.assertTrue(all(ref["path"] == "src/codestream/tests.rs" for ref in entry["test_refs"]))
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")

        stale = copy.deepcopy(coverage)
        stale["requirements"][0]["test_refs"][0]["path"] = "src/codestream.rs"
        with self.assertRaises(ValueError):
            framework.validate_normative_coverage(stale)

        moved = framework.ROOT / "src/codestream/tests.rs"
        symbol = entry["test_refs"][0]["symbol"]
        read_text = Path.read_text

        def missing_symbol(path, *args, **kwargs):
            text = read_text(path, *args, **kwargs)
            if path == moved:
                return text.replace(f"fn {symbol}(", f"fn removed_{symbol}(", 1)
            return text

        with mock.patch.object(Path, "read_text", missing_symbol), self.assertRaises(ValueError):
            framework.validate_normative_coverage(coverage)

    def test_inventory_binds_actual_mct_all_numeric_bytes_rounding_limits_and_complete_array_fields(self):
        self._assert_complete_packet_contract_bindings(
            {"part2-complete-native-raw-transform-array-bytes"},
            framework._TRANSFORM_ARRAY_BYTES_CONTRACTS, 7,
        )

    def _assert_complete_packet_contract_bindings(self, entry_ids, recipes, expected_count):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        self.assertEqual(framework.validate_normative_coverage(original_coverage)["status"], "passed")
        entries = [entry for entry in original_coverage["requirements"] if entry["id"] in entry_ids]
        references = [reference for entry in entries for reference in entry["contract_refs"]]
        references.extend(reference for entry in entries for reference in entry["proof_refs"]
                          if (reference["path"], reference["symbol"]) in recipes and reference not in references)
        self.assertEqual(len(entries), len(entry_ids))
        self.assertEqual(len(references), expected_count)
        self.assertEqual({(ref["path"], ref["symbol"]) for ref in references}, set(recipes))
        read_text = Path.read_text

        def closing_parenthesis(text, opening):
            depth = 0
            for index in range(opening, len(text)):
                if text[index] == "(":
                    depth += 1
                elif text[index] == ")":
                    depth -= 1
                    if depth == 0:
                        return index
            self.fail("Unbalanced actual model invocation")

        for reference in references:
            key = (reference["path"], reference["symbol"])
            model = recipes[key][0]
            entry = next(entry for entry in entries if reference in entry["contract_refs"] or reference in entry["proof_refs"])
            claimed_consumer = reference in entry["contract_refs"]
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            coverage["requirements"][0]["contract_refs"] = [reference] if claimed_consumer else entry["contract_refs"][:1]
            source = framework.ROOT / reference["path"]
            original = source.read_text()
            actual_callers = [caller for caller in entry["implementation_refs"] if caller != reference and (
                re.search(rf"\b{re.escape(reference['symbol'].rsplit('::', 1)[-1])}\s*\(",
                          (framework.ROOT / caller["path"]).read_text())
                if caller["path"] != reference["path"] else framework._coverage_same_file_call(
                    original, caller["symbol"], reference["symbol"].rsplit("::", 1)[-1],
                )

            )]
            isolated = coverage["requirements"][0]
            if claimed_consumer:
                self.assertTrue(actual_callers)
                isolated["implementation_refs"] = actual_callers[:1]
                isolated["spec_refs"] = [item for item in entry["spec_refs"] if item["symbol"] == model]
            isolated["proof_refs"] = [reference]
            isolated["test_refs"] = entry["test_refs"][:1]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(original, reference["symbol"])
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            body_start = original.find("{", signature)
            native_signature = original[signature:body_start]
            model_start = contract.index(f"crate::specs::{model}")
            opening = contract.index("(", model_start)
            closing = closing_parenthesis(contract, opening)
            expression_start = contract.index("ensures") + len("ensures")
            original_expression = contract[expression_start:closing + 1]
            primary_arguments = contract[opening + 1:closing]
            alternate = "part1_header_floor_log2" if model != "part1_header_floor_log2" else "part1_packet_reader_error"
            mutations = [
                contract.replace("ensures", "requires false, ensures", 1),
                contract.replace("ensures", "ensures result.is_ok() ==>", 1),
                contract.replace("ensures", "ensures unrelated", 1),
                contract.replace(f"crate::specs::{model}", f"crate::specs::{alternate}", 1),
                contract[:opening + 1] + "unrelated" + contract[closing:],
            ]
            parameter_names = set(re.findall(r"\b(\w+)\s*:(?!:)\s*", native_signature))
            if re.search(r"&\s*(?:'\w+\s+)?(?:mut\s+)?self\b", native_signature):
                parameter_names.add("self")
            argument_mutations = ["unrelated"]
            for parameter in sorted(parameter_names):
                changed, replacements = re.subn(
                    rf"(?<!:)\b{re.escape(parameter)}\b", "unrelated", primary_arguments, count=1,
                )
                if replacements:
                    argument_mutations.append(changed)
            for match in re.finditer(r"\bcrate::limits::(resource_\w+_limit)\s*\(", primary_arguments):
                argument_mutations.append(primary_arguments[:match.start(1)] + "unlisted_cap" + primary_arguments[match.end(1):])
            for arguments in argument_mutations:
                changed = contract[:opening + 1] + arguments + contract[closing:]
                mutations.append(changed)
                changed_closing = closing_parenthesis(changed, opening)
                mutations.append(changed[:changed_closing + 1] + ",\n" + original_expression + changed[changed_closing + 1:])
            for match in re.finditer(r"\bold\s*\(\s*(\w+(?:\.\w+)?)\s*\)", primary_arguments):
                arguments = primary_arguments[:match.start()] + f"final({match[1]})" + primary_arguments[match.end():]
                mutations.append(contract[:opening + 1] + arguments + contract[closing:])
            for match in re.finditer(r"\b(?:0|None|true|false)\b", primary_arguments):
                replacement = {"0": "1", "None": "Some(unrelated)", "true": "false", "false": "true"}[match[0]]
                arguments = primary_arguments[:match.start()] + replacement + primary_arguments[match.end():]
                mutations.append(contract[:opening + 1] + arguments + contract[closing:])
            primary_left = contract[expression_start:model_start]
            for view in set(re.findall(r"\b(\w+_view|code_block_header_outcome|header_segments_outcome)\s*\(", primary_left)):
                mutations.append(contract.replace(view, "unlisted_state_projection", 1))
            for parameter in set(re.findall(r"\bfinal\s*\(\s*(\w+(?:\.\w+)?)\s*\)", primary_left)):
                mutations.append(re.sub(rf"\bfinal\s*\(\s*{re.escape(parameter)}\s*\)", "final(unrelated)", contract, count=1))
            for number, changed in enumerate(mutations):
                modified = original[:start] + changed + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=reference["symbol"], mutation=number), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
            no_caller = copy.deepcopy(coverage)
            no_caller["requirements"][0]["contract_refs"] = [reference]
            no_caller["requirements"][0]["implementation_refs"] = [reference]
            with self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(no_caller)
            if reference["symbol"] == "decode_multi_code_block_packet":
                definition = re.search(r"\bstruct\s+PacketCodeBlockExecution\b[^{]*\{([^}]*)\}", original)
                self.assertIsNotNone(definition)
                changed_definition = definition[0].replace("{", "{ unexpected: &'a mut u64,", 1)
                variants = [
                    original[:definition.start()] + changed_definition + original[definition.end():],
                    original[:signature] + original[signature:].replace(
                        "execution: PacketCodeBlockExecution", "execution: UnlistedExecution", 1),
                ]
                for modified in variants:
                    def altered_bundle(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)
                    with mock.patch.object(Path, "read_text", altered_bundle), \
                            self.assertRaisesRegex(ValueError, "unknown execution bundle"):
                        framework.validate_normative_coverage(coverage)

    def test_inventory_binds_all_native_arbitrary_kernel_and_preparation_results(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in original_coverage["requirements"]
                     if item["id"] == "part2-complete-native-arbitrary-kernel-preparation")
        read_text = Path.read_text
        cases = (
            ("src/transform.rs", "inverse_arbitrary", "sequence_outcome", "part2_inverse_arbitrary",
             (("low@, high@", "high@, low@"), ("low_pass_first,", "false,"), ("raw_kernel_view(*kernel)", "raw_kernel_view(*unrelated)"))),
            ("src/transform.rs", "inverse_horizontal_arbitrary", "reconstruction_outcome", "part2_atk_inverse_horizontal",
             (("wavelet_band_view(low)", "wavelet_band_view(high)"), ("output_width,", "0,"), ("!crate::codestream::raw_kernel_view(*kernel).0", "false"), ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"))),
            ("src/transform.rs", "inverse_vertical_arbitrary", "reconstruction_outcome", "part2_atk_inverse_vertical",
             (("wavelet_band_view(high)", "wavelet_band_view(low)"), ("output_height,", "0,"), ("!crate::codestream::raw_kernel_view(*kernel).0", "false"), ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"))),
            ("src/transform.rs", "inverse_level_arbitrary", "reconstruction_outcome", "part2_atk_inverse_level",
             (("wavelet_level_view(level)", "wavelet_level_view(unrelated)"), ("raw_kernel_view(*kernel)", "raw_kernel_view(*unrelated)"), ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"))),
            ("src/transform.rs", "apply_arbitrary_steps", None, "part2_atk_steps",
             (("old(output)@", "unrelated@"), ("raw_kernel_view(*kernel).6.len()", "0"), ("low_pass_first,", "false,"))),
            ("src/transform.rs", "apply_arbitrary_step", None, "part2_atk_step",
             (("old(output)@", "unrelated@"), ("raw_kernel_step_view(*step)", "raw_kernel_step_view(*unrelated)"), ("low_pass_first, update_odd", "update_odd, low_pass_first"))),
            ("src/transform.rs", "arbitrary_reversible_target", None, "part2_atk_reversible_target",
             (("output@, target", "output@, 0"), ("raw_kernel_step_view(*step)", "raw_kernel_step_view(*unrelated)"), ("raw_kernel_view(*kernel)", "raw_kernel_view(*unrelated)"))),
            ("src/transform.rs", "arbitrary_irreversible_target", None, "part2_atk_irreversible_target",
             (("output@, target", "output@, 0"), ("raw_kernel_step_view(*step)", "raw_kernel_step_view(*unrelated)"), ("raw_kernel_view(*kernel)", "raw_kernel_view(*unrelated)"))),
            ("src/transform.rs", "lifting_source_sum", None, "part2_atk_source_sum",
             (("samples@", "unrelated@"), ("target, coefficient, offset", "coefficient, target, offset"), ("whole_sample_filter, whole_sample_extension", "whole_sample_extension, whole_sample_filter"))),
            ("src/transform.rs", "extended_sample", None, "part2_atk_extended",
             (("samples@", "unrelated@"), ("original_index,", "0,"), ("whole_sample_extension)", "false)"))),
            ("src/transform.rs", "coefficient_integer", None, "part2_atk_integer",
             (("raw_kernel_coefficient_view(coefficient)", "raw_kernel_coefficient_view(unrelated)"), ("coefficient_type)", "0)"))),
            ("src/transform.rs", "coefficient_fixed", None, "part2_atk_fixed_coefficient",
             (("raw_kernel_coefficient_view(coefficient)", "raw_kernel_coefficient_view(unrelated)"), ("coefficient_type)", "0)"))),
            ("src/transform.rs", "bytes_to_u128", None, "part2_atk_bytes_prefix",
             (("bytes@, 16", "bytes@, 0"), ("bytes@", "unrelated@"))),
            ("src/transform.rs", "binary_to_fixed", None, "part2_atk_binary_format",
             (("bits, total_bits", "0, total_bits"), ("exponent_bits, fraction_bits", "fraction_bits, exponent_bits"), ("fraction_bits, bias", "fraction_bits, 0"))),
            ("src/transform.rs", "fixed_from_binary_q32", None, "part2_atk_binary_q32",
             (("negative,", "false,"), ("significand,", "0,"), ("binary_exponent)", "0)"))),
            ("src/transform.rs", "fixed_mul_q32", None, "part2_atk_fixed_mul",
             (("value, factor", "factor, value"), ("value, factor", "value, 0"))),
            ("src/transform.rs", "fixed_div_q32", None, "part2_atk_fixed_div",
             (("value, divisor", "divisor, value"), ("value, divisor", "value, 0"))),
            ("src/transform.rs", "round_shift_i128", None, "part2_atk_round_shift",
             (("value, shift", "value, 0"), ("value, shift", "0, shift"))),
            ("src/decode.rs", "prepare_tile_component_with_kernel", "prepared_component_outcome", "part2_prepare_component",
             (("prepare_plan_view(plan)", "prepare_plan_view(unrelated)"), ("prepare_precincts_view(precincts@)", "prepare_precincts_view(unrelated@)"), ("arbitrary_kernel_option(kernel)", "arbitrary_kernel_option(None)"), ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"))),
            ("src/decode.rs", "reconstruct_prepare_working", "prepare_fold_outcome", "part2_prepare_reconstruct",
             (("working_bands_view(working@)", "working_bands_view(unrelated@)"), ("arbitrary_kernel_option(kernel)", "arbitrary_kernel_option(None)"), ("reversible,", "true,"))),
            ("src/decode.rs", "reconstruct_prepare_resolution", "prepare_fold_outcome", "part2_prepare_resolution",
             (("before@", "unrelated@"), ("plan.subbands@", "unrelated@"), ("direction, reversible", "direction, true"), ("arbitrary_kernel_option(kernel)", "arbitrary_kernel_option(None)"))),
        )
        self.assertEqual(len(cases), 21)
        for relative, symbol, projection, model, arguments in cases:
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            reference = {"path": relative, "symbol": symbol}
            self.assertIn(reference, entry["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / relative
            original = source.read_text()
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            mutable = symbol in ("apply_arbitrary_steps", "apply_arbitrary_step")
            expression = "(result, final(output)@)" if mutable else f"{projection}(result)" if projection else "result"
            mutations = [
                (f"ensures {expression}", "ensures result.is_ok()"),
                (f"ensures {expression}", f"ensures result.is_ok() ==> {expression}"),
                (f"ensures {expression}", "ensures unrelated"),
                (f"crate::specs::{model}(", "crate::specs::part2_atk_fixed_mul(" if model != "part2_atk_fixed_mul" else "crate::specs::part2_atk_fixed_div("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *arguments,
            ]
            if projection:
                mutations.extend(((expression, f"{projection}(unrelated)"), (expression, "unlisted_projection(result)")))
            if mutable:
                mutations.extend((("final(output)@", "old(output)@"), ("final(output)@", "final(unrelated)@")))
            for before, after in mutations:
                self.assertIn(before, contract)
                changed = contract.replace(before, after, 1)
                variants = [changed]
                if (before, after) in arguments:
                    closing = re.search(r"\)\s*,?\s*\)\s*\]", changed)
                    original_closing = re.search(r"\)\s*,?\s*\)\s*\]", contract)
                    assert closing is not None and original_closing is not None
                    variants.append(changed[:closing.start()] + "\n"
                        + contract[contract.index("ensures") + len("ensures"):original_closing.start()]
                        + changed[closing.start():])
                for variant in variants:
                    modified = original[:start] + variant + original[signature:]

                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)

                    with self.subTest(symbol=symbol, after=after, duplicate=variant != changed), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                        framework.validate_normative_coverage(coverage)

    def test_inventory_binds_actual_selection_association_and_output_native_inputs(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in original_coverage["requirements"]
                     if item["id"] == "part2-complete-native-container-selection-output")
        read_text = Path.read_text
        cases = (
            ("src/codestream.rs", "ImageSize::tile_count", None, "part2_selection_tile_count", ("selection_geometry_view(&self)", "selection_geometry_view(unrelated)")),
            ("src/codestream.rs", "ImageSize::tile_bounds", None, "part2_selection_tile_bounds", ("self), tile_index", "self), 0")),
            ("src/options.rs", "selection_from_parts", "decode_selection_value_view", "part2_selection_from_parts", ("region, discard_levels", "region, 0")),
            ("src/decode.rs", "ceil_div_u32", None, "part2_selection_ceil", ("value, divisor", "divisor, value")),
            ("src/decode.rs", "tile_list_contains", None, "part2_tile_list_contains", ("tiles@, tile", "unrelated@, tile")),
            ("src/decode.rs", "selection_rectangle_area", None, "part2_rectangle_area", ("part2_rectangle_area(bounds)", "part2_rectangle_area(unrelated)")),
            ("src/decode.rs", "validate_explicit_tile_indices", None, "part2_explicit_tile_prefix", ("explicit_tiles@.len()", "0")),
            ("src/decode.rs", "validate_selection_tile_rectangle", None, "part2_validate_tile_rectangle", ("explicit_tiles@, tiles_across", "explicit_tiles@, 0")),
            ("src/decode.rs", "validate_selection_rectangle_cells", None, "part2_rectangle_rows", ("bounds.2 as nat - bounds.0 as nat + 1", "bounds.3 as nat - bounds.1 as nat + 1")),
            ("src/decode.rs", "selection_region", "selection_region_outcome", "part2_selection_region", ("requested, image_x1, image_y1", "requested, image_y1, image_x1")),
            ("src/decode.rs", "select_intersecting_tiles", "selected_tiles_outcome", "part2_select_intersecting_tiles", ("region@, tile_count", "unrelated@, tile_count")),
            ("src/decode.rs", "explicit_tiles_from_selection", "selected_tiles_outcome", "part2_selection_explicit", ("tile_selection_view(selection)", "tile_selection_view(unrelated)")),
            ("src/decode.rs", "validate_selection", "validated_selection_outcome", "part2_validate_selection", ("decode_selection_view(selection)", "decode_selection_view(unrelated)")),
            ("src/decode.rs", "color_selection_from_validated", "color_selection_outcome", "part2_color_selection_context", ("size.x_origin, size.y_origin", "size.y_origin, size.x_origin")),
            ("src/decode.rs", "color_selection_for_size", "color_selection_outcome", "part2_color_selection_requested", ("decode_selection_view(requested)", "decode_selection_view(unrelated)")),
            ("src/decode.rs", "apply_associated_output", "associated_typed_outcome", "part2_apply_associated_output", ("typed_image_value_view(decoded)", "typed_image_value_view(unrelated)")),
            ("src/decode.rs", "convert_associated_color", "crate::color::converted_image_result", "part2_convert_associated", ("typed_image_value_view(*image)", "typed_image_value_view(*unrelated)")),
            ("src/decode.rs", "convert_associated_selected_color", "crate::color::converted_image_result", "part2_convert_associated_selected", ("header), target", "header), unrelated")),
            ("src/decode.rs", "finish_associated_selected_output", "crate::color::converted_image_result", "part2_finish_associated_selected_output", ("typed_image_value_view(decoded)", "typed_image_value_view(unrelated)")),
            ("src/jp2.rs", "associated_header_for_codestream", "associated_header_outcome", "part2_associated_codestream_header", ("associated_header_view(fallback)", "associated_header_view(unrelated)")),
            ("src/jp2.rs", "validate_container_codestream", None, "part2_validate_selected_header", ("header.image, codestream.image_size.width", "header.image, 0")),
            ("src/jp2.rs", "validate_selected_header", None, "part2_validate_selected_header", ("codestream.image_size.uniform_signed, offset", "codestream.image_size.uniform_signed, 0")),
        )
        self.assertEqual(len(cases), 22)
        for relative, symbol, projection, model, argument in cases:
            reference = {"path": relative, "symbol": symbol}
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / relative
            original = source.read_text()
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            expression = f"{projection}(result)" if projection else "result"
            inputs = [argument]
            for parameter in ("size", "header", "limits"):
                pattern = rf"\(\s*{parameter}\s*\)"
                if re.search(pattern, contract):
                    matched = re.search(pattern, contract)[0]
                    pair = (matched, "(unrelated)")
                    if pair not in inputs:
                        inputs.append(pair)
            mutations = [
                (f"ensures {expression}", "ensures unrelated"),
                (f"ensures {expression}", "ensures result.is_ok()"),
                (f"ensures {expression}", f"ensures result.is_ok() ==> {expression}"),
                (f"crate::specs::{model}(", "crate::specs::part2_typed_component_copy("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *inputs,
            ]
            if projection:
                mutations.extend(((expression, f"{projection}(unrelated)"), (expression, "unlisted_projection(result)")))
            for before, after in mutations:
                self.assertIn(before, contract)
                changed = contract.replace(before, after, 1)
                variants = [changed]
                if (before, after) in inputs:
                    closing = re.search(r"\)\s*,?\s*\)\s*\]", changed)
                    original_closing = re.search(r"\)\s*,?\s*\)\s*\]", contract)
                    assert closing is not None and original_closing is not None
                    variants.append(changed[:closing.start()] + "\n"
                        + contract[contract.index("ensures") + len("ensures"):original_closing.start()]
                        + changed[closing.start():])
                for variant in variants:
                    modified = original[:start] + variant + original[signature:]

                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)

                    with self.subTest(symbol=symbol, after=after, duplicate=variant != changed), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                        framework.validate_normative_coverage(coverage)
            no_caller = copy.deepcopy(coverage)
            no_caller["requirements"][0]["implementation_refs"] = [reference]
            with self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(no_caller)

    def test_inventory_binds_native_ht_continuation_placeholder_and_staged_groups(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        read_text = Path.read_text
        for symbol, model, arguments in (
            ("decode_high_throughput_refinement", "ht_decode_refinement_contribution", (
                ("input@", "unrelated@"), ("input@, passes", "input@, 0"),
                ("resource_code_block_byte_limit(limits)", "resource_code_block_byte_limit(unrelated)"),
                ("resource_work_limit(limits)", "resource_work_limit(unrelated)"),
                ("resource_code_block_byte_limit(limits)", "resource_work_limit(limits)"),
            )),
            ("skip_high_throughput_segment", "ht_skip_segment", (
                ("old(self)), passes", "old(self)), 0"),
                ("resource_code_block_pass_limit(limits)", "resource_code_block_pass_limit(unrelated)"),
            )),
            ("run_ht_placeholder_groups", "ht_placeholder_group_run", (
                ("placeholder_passes as nat", "0"),
                ("resource_code_block_pass_limit(limits)", "resource_code_block_pass_limit(unrelated)"),
            )),
            ("decode_ht_staged_group", "ht_decode_staged_group", (
                ("input@", "unrelated@"), ("input@, passes", "input@, 0"),
                ("resource_code_block_pass_limit(limits)", "resource_code_block_pass_limit(unrelated)"),
                ("resource_code_block_byte_limit(limits)", "resource_work_limit(limits)"),
                ("resource_work_limit(limits)", "resource_work_limit(unrelated)"),
            )),
        ):
            reference = {"path": "src/tier1.rs", "symbol": f"Tier1CodeBlockDecoder::{symbol}"}
            entry = next(item for item in original_coverage["requirements"] if reference in item["contract_refs"])
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / reference["path"]
            original = source.read_text()
            header = framework._coverage_function_header(original, reference["symbol"])
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            complete = "(result, tier1_decoder_state(final(self)))"
            mutations = [
                (f"ensures {complete}", "ensures result.is_ok()"),
                (f"ensures {complete}", f"ensures result.is_ok() ==> {complete}"),
                (complete, "(unrelated, tier1_decoder_state(final(self)))"),
                ("tier1_decoder_state(final(self))", "tier1_decoder_state(old(self))"),
                ("tier1_decoder_state(final(self))", "unlisted_view(final(self))"),
                ("tier1_decoder_state(old(self))", "tier1_decoder_state(unrelated)"),
                (f"crate::specs::{model}(", "crate::specs::ht_decode_segments("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *arguments,
            ]
            for before, after in mutations:
                self.assertIn(before, contract)
                changed = contract.replace(before, after, 1)
                variants = [changed]
                if (before, after) in arguments:
                    closing = re.search(r"\)\s*,?\s*\)\s*\]", changed)
                    original_closing = re.search(r"\)\s*,?\s*\)\s*\]", contract)
                    assert closing is not None and original_closing is not None
                    variants.append(changed[:closing.start()] + "\n"
                        + contract[contract.index("ensures") + len("ensures"):original_closing.start()]
                        + changed[closing.start():])
                for variant in variants:
                    modified = original[:start] + variant + original[signature:]

                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)

                    with self.subTest(symbol=symbol, after=after, duplicate=variant != changed), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                        framework.validate_normative_coverage(coverage)
            body = original.find("{", signature)
            modified = original[:signature] + original[signature:body].replace(
                "&mut self,", "&mut self, unrelated: &mut u64,", 1,
            ) + original[body:]
            self.assertNotEqual(modified, original)

            def extra_mutable(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(symbol=symbol, mutation="unbound additional mutable state"), \
                    mock.patch.object(Path, "read_text", extra_mutable), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)
            wrong_owner = copy.deepcopy(coverage)
            wrong_owner["requirements"][0]["contract_refs"][0]["symbol"] = f"OtherDecoder::{symbol}"
            with self.assertRaisesRegex(ValueError, "missing linked contract function"):
                framework.validate_normative_coverage(wrong_owner)
            no_caller = copy.deepcopy(coverage)
            no_caller["requirements"][0]["implementation_refs"] = [reference]
            with self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(no_caller)

    def test_inventory_binds_complete_native_mixed_packet_body_and_all_mutable_progress(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(item for item in original_coverage["requirements"]
                     if item["id"] == "part1-complete-native-mixed-code-block-body")
        read_text = Path.read_text
        cases = (
            ("CodeBlockContribution::segment", "part1_code_block_segment"),
            ("prepare_code_block_contribution_body", "part1_code_block_body_prepare"),
            ("decode_legacy_code_block_segment", "part1_legacy_code_block_segment"),
            ("decode_legacy_code_block_contribution_body", "part1_legacy_code_block_body"),
            ("decode_ht_segment_route", "ht_packet_segment_route"),
            ("decode_ht_segment_body", "ht_packet_segment_body"),
            ("run_ht_contribution_segments", "ht_packet_body_run"),
            ("decode_ht_contribution_segments", "ht_packet_body_segments"),
            ("decode_code_block_contribution_body_staged", "part1_code_block_body_staged"),
            ("decode_code_block_contribution_body", "part1_code_block_body_transaction"),
        )
        for symbol, model in cases:
            reference = {"path": "src/packet.rs", "symbol": symbol}
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / reference["path"]
            original = source.read_text()
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            inputs = [
                (r"code_block_contribution_view\(\s*contribution\s*\)", "code_block_contribution_view(unrelated)"),
                (r"\bbody@", "unrelated@"),
                (r"old\(\s*decoder\s*\)", "old(unrelated)"),
                (r"resource_code_block_pass_limit\(\s*limits\s*\)", "resource_code_block_pass_limit(unrelated)"),
                (r"resource_code_block_byte_limit\(\s*limits\s*\)", "resource_work_limit(limits)"),
                (r"resource_input_byte_limit\(\s*limits\s*\)", "resource_input_byte_limit(unrelated)"),
                (r"resource_work_limit\(\s*limits\s*\)", "resource_work_limit(unrelated)"),
                (r"old\(\s*offset\s*\)", "old(unrelated)"),
                (r"old\(\s*decoded_passes\s*\)", "old(unrelated)"),
                (r"old\(\s*segment_index\s*\)", "old(unrelated)"),
                (r"ht_body_progress_view\(\s*old\(\s*progress\s*\)\s*\)", "ht_body_progress_view(old(unrelated))"),
            ]
            if symbol == "CodeBlockContribution::segment":
                inputs = [
                    (r"code_block_contribution_view\(\s*self\s*\)", "code_block_contribution_view(unrelated)"),
                    (r"\bindex\s*\)", "0)"),
                ]
            else:
                inputs.extend((
                    (r"body@\s*,\s*passes\b", "body@, 0"),
                    (r"\bsegment\s*,\s*body@", "unrelated, body@"),
                ))
            inputs = [(before, after) for before, after in inputs if re.search(before, contract)]
            self.assertGreaterEqual(len(inputs), 2)
            mutations = [
                (r"\bensures\s+", "ensures result.is_ok() ==> "),
                (rf"crate::specs::{model}\(", "crate::specs::ht_decode_segments("),
                (rf"crate::specs::{model}\(", "crate::specs::unlisted_model("),
                *inputs,
            ]
            if symbol != "CodeBlockContribution::segment":
                mutations.extend((
                    (r"\bensures\s*\(\s*result\s*,", "ensures (unrelated,"),
                    (r"final\(\s*decoder\s*\)", "old(decoder)"),
                    (r"final\(\s*decoder\s*\)", "final(unrelated)"),
                ))
                for parameter in ("segment_index", "offset", "decoded_passes", "progress"):
                    if re.search(rf"final\(\s*{parameter}\s*\)", contract):
                        mutations.append((rf"final\(\s*{parameter}\s*\)", f"old({parameter})"))
            for before, after in mutations:
                changed, count = re.subn(before, after, contract, count=1)
                self.assertEqual(count, 1)
                self.assertNotEqual(changed, contract)
                variants = [changed]
                if (before, after) in inputs:
                    closing = re.search(r"\)\s*,?\s*\)\s*\]", changed)
                    original_closing = re.search(r"\)\s*,?\s*\)\s*\]", contract)
                    assert closing is not None and original_closing is not None
                    variants.append(changed[:closing.start()] + "\n"
                        + contract[contract.index("ensures") + len("ensures"):original_closing.start()]
                        + changed[closing.start():])
                for variant in variants:
                    modified = original[:start] + variant + original[signature:]

                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)

                    with self.subTest(symbol=symbol, after=after, duplicate=variant != changed), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                        framework.validate_normative_coverage(coverage)
            if symbol != "CodeBlockContribution::segment":
                body = original.find("{", signature)
                prefix, count = re.subn(r"\(\s*", "(extra: &mut u64, ", original[signature:body], count=1)
                self.assertEqual(count, 1)
                modified = original[:signature] + prefix + original[body:]

                def extra_mutable(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, mutation="omitted mutable state"), \
                        mock.patch.object(Path, "read_text", extra_mutable), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
            no_caller = copy.deepcopy(coverage)
            no_caller["requirements"][0]["implementation_refs"] = [reference]
            with self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(no_caller)

    def test_inventory_binds_complete_header_to_actual_native_results_inputs_and_owner(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(
            item for item in original_coverage["requirements"]
            if item["id"] == "part2-complete-native-output-header"
        )
        read_text = Path.read_text
        for relative, symbol, projection, model, arguments in (
            ("src/decode.rs", "apply_jp2_output", "crate::image::decoded_typed_image_outcome",
             "part2_apply_output_header", (
                ("typed_image_value_view(decoded)", "typed_image_value_view(unrelated)"),
                ("output_header_view(header)", "output_header_view(unrelated)"),
                ("crate::limits::resource_component_limit(limits)", "0"),
                ("crate::limits::resource_decoded_bytes_limit(limits)", "0"),
            )),
            ("src/image.rs", "typed_image_from_components_with_origin", "decoded_typed_image_outcome",
             "part2_typed_image_from_parts", (
                ("width, height, x_origin, y_origin", "height, width, x_origin, y_origin"),
                ("width, height, x_origin, y_origin", "width, height, y_origin, x_origin"),
                ("typed_components_output_view(components@)", "typed_components_output_view(unrelated@)"),
                ("crate::limits::resource_component_limit(limits)", "0"),
                ("crate::limits::resource_decoded_bytes_limit(limits)", "0"),
            )),
            ("src/image.rs", "TypedImage::component", "typed_component_reference_output",
             "part2_typed_image_component", (
                ("typed_image_components(self)", "typed_image_components(unrelated)"),
                ("typed_image_components(self)), index", "typed_image_components(self)), 0"),
            )),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            reference = {"path": relative, "symbol": symbol}
            self.assertIn(reference, entry["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / relative
            original = source.read_text()
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            expression = f"{projection}(result)"
            mutations = [
                (f"ensures {expression}", "ensures unrelated"),
                (f"ensures {expression}", "ensures result.is_ok()"),
                (f"ensures {expression}", f"ensures result.is_ok() ==> {expression}"),
                (expression, f"{projection}(unrelated)"),
                (expression, "unlisted_projection(result)"),
                (f"crate::specs::{model}(", "crate::specs::part2_typed_component_copy("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *arguments,
            ]
            for before, after in mutations:
                self.assertIn(before, contract)
                changed = contract.replace(before, after, 1)
                variants = [changed]
                if (before, after) in arguments:
                    closing_match = re.search(r"\)\s*,?\s*\)\s*\]", changed)
                    original_closing_match = re.search(r"\)\s*,?\s*\)\s*\]", contract)
                    assert closing_match is not None and original_closing_match is not None
                    closing = closing_match.start()
                    original_closing = original_closing_match.start()
                    variants.append(
                        changed[:closing] + "\n" + contract[contract.index("ensures") + len("ensures"):original_closing]
                        + changed[closing:]
                    )
                for variant in variants:
                    modified = original[:start] + variant + original[signature:]

                    def altered(path, *args, **kwargs):
                        return modified if path == source else read_text(path, *args, **kwargs)

                    with self.subTest(symbol=symbol, after=after, duplicate=variant != changed), \
                            mock.patch.object(Path, "read_text", altered), \
                            self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                        framework.validate_normative_coverage(coverage)
        coverage["requirements"][0]["contract_refs"] = [{"path": "src/image.rs", "symbol": "DecodedImage::component"}]
        with self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
            framework.validate_normative_coverage(coverage)

    def test_qualified_coverage_resolves_unique_method_across_same_owner_impls(self):
        text = (
            "impl DecodedImage {\n"
            "    pub fn component(&self) {}\n"
            "}\n"
            "impl TypedImage {\n"
            "    pub fn unrelated(&self) {\n"
            "        fn component() {}\n"
            "    }\n"
            "}\n"
            "impl TypedImage {\n"
            "    pub fn component(&self) {}\n"
            "}\n"
        )
        header = framework._coverage_function_header(text, "TypedImage::component")
        self.assertIsNotNone(header)
        self.assertEqual(header.start(), text.rfind("    pub fn component"))
        self.assertIsNone(framework._coverage_function_header(text, "OtherImage::component"))
        without_method = text[:text.rfind("impl TypedImage")]
        self.assertIsNone(framework._coverage_function_header(without_method, "TypedImage::component"))
        duplicate = text + "impl TypedImage {\n    pub fn component(&self) {}\n}\n"
        self.assertIsNone(framework._coverage_function_header(duplicate, "TypedImage::component"))

    def test_qualified_raw_adapter_resolves_only_exact_symbol_decoder_trait_and_owner(self):
        correct = (
            "impl Tier1SymbolDecoder for RawBitReader<'_> {\n"
            "    fn decode(&mut self, context: usize) {\n"
            "        self.read_bit();\n"
            "    }\n"
            "}\n"
        )
        foreign_trait = correct.replace("Tier1SymbolDecoder", "OtherTrait")
        foreign_owner = correct.replace("RawBitReader", "OtherReader")
        text = foreign_trait + foreign_owner + correct
        header = framework._coverage_function_header(text, "RawBitReader::decode")
        self.assertIsNotNone(header)
        self.assertEqual(header.start(), text.rfind("    fn decode"))
        self.assertTrue(framework._coverage_same_file_call(text, "RawBitReader::decode", "read_bit"))
        self.assertIsNone(framework._coverage_function_header(foreign_trait + foreign_owner, "RawBitReader::decode"))
        self.assertIsNone(framework._coverage_function_header(correct, "Tier1SymbolDecoder::decode"))
        self.assertIsNone(framework._coverage_function_header(correct, "OtherReader::decode"))
        duplicate = correct + "impl RawBitReader<'_> {\n    fn decode(&mut self) {}\n}\n"
        self.assertIsNone(framework._coverage_function_header(duplicate, "RawBitReader::decode"))
        nested = "impl Tier1SymbolDecoder for RawBitReader<'_> {\n    fn unrelated() {\n        fn decode() {}\n    }\n}\n"
        self.assertIsNone(framework._coverage_function_header(nested, "RawBitReader::decode"))

    def test_qualified_impl_range_index_preserves_traits_duplicates_and_changed_text(self):
        trait = (
            "impl Tier1SymbolDecoder for RawBitReader<'_> {\n"
            "    fn decode(&mut self) {}\n"
            "    fn read_bit(&mut self) {}\n"
            "}\n"
        )
        inherent = "impl RawBitReader<'_> {\n    fn read_bit(&mut self) {}\n}\n"
        text = trait + inherent
        ranges = {}
        for source in [
            text, trait, text + inherent, text.replace("read_bit", "unrelated"), text,
            "impl RawBitReader<'_> {\n    fn read_bit(&mut self) {}\n",
        ]:
            for symbol in [
                "RawBitReader::decode", "RawBitReader::read_bit", "OtherReader::decode",
            ]:
                with self.subTest(source=source, symbol=symbol):
                    actual = framework._coverage_function_header(
                        source, symbol, implementation_ranges=ranges,
                    )
                    expected = framework._coverage_function_header(source, symbol)
                    self.assertEqual(actual.span() if actual else None, expected.span() if expected else None)
        self.assertEqual(
            framework._coverage_function_header(text, "RawBitReader::read_bit", implementation_ranges=ranges).start(),
            text.rfind("    fn read_bit"),
        )

    def test_inventory_binds_complete_standard_plan_to_actual_results_and_native_inputs(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        entry = next(
            item for item in original_coverage["requirements"]
            if item["id"] == "part1-complete-standard-plan-coordinator"
        )
        conditional = {"path": "src/decode.rs", "symbol": "prepare_tile_component_with_kernel"}
        self.assertNotIn(conditional, entry["contract_refs"])
        self.assertIn(conditional, entry["implementation_refs"])
        conditional_coverage = copy.deepcopy(original_coverage)
        conditional_coverage["requirements"] = [copy.deepcopy(entry)]
        conditional_coverage["requirements"][0]["contract_refs"] = [conditional]
        with self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
            framework.validate_normative_coverage(conditional_coverage)
        read_text = Path.read_text
        source = framework.ROOT / "src/decode.rs"
        original = source.read_text()
        for symbol, projection, model, arguments in (
            ("prepare_tile_component", "prepared_component_outcome", "part1_prepare_standard_component", (
                ("prepare_plan_view(plan)", "prepare_plan_view(unrelated)"),
                ("prepare_precincts_view(precincts@)", "prepare_precincts_view(unrelated@)"),
                ("prepare_style_view(coding_style)", "prepare_style_view(unrelated)"),
                ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"),
            )),
            ("initialize_prepare_working", "prepare_working_outcome", "part1_prepare_init_prefix", (
                ("bands@", "unrelated@"),
                ("fraction", "0"),
                ("selected as nat", "0"),
                ("resource_decoded_bytes_limit(limits)", "resource_decoded_bytes_limit(unrelated)"),
            )),
            ("collect_prepare_coefficients", "crate::transform::quantized_coefficients_outcome",
             "part1_prepare_collect_coefficients", (
                ("code_block_plane_view(plane)", "code_block_plane_view(unrelated)"),
            )),
            ("collect_prepare_cell", "prepare_cell_outcome", "part1_prepare_signed_cell", (
                ("code_block_plane_view(plane)", "code_block_plane_view(unrelated)"),
                ("plane), x, y", "plane), y, x"),
                ("plane), x, y", "plane), x, 0"),
            )),
            ("copy_prepare_plane", "prepare_fold_outcome", "part1_prepare_copy_plane", (
                ("reconstructed_plane_view(plane)", "reconstructed_plane_view(unrelated)"),
                ("first_detail", "0"),
            )),
            ("finish_prepared_component", "prepared_component_outcome", "part1_prepare_finish", (
                ("prepare_plan_view(plan)", "prepare_plan_view(unrelated)"),
                ("fraction", "0"),
                ("folded@", "unrelated@"),
            )),
            ("PreparedTileComponent::as_tile_component", "crate::image::assembly_tile_view",
             "part1_prepared_as_tile", (
                ("prepared_component_view(*self)", "prepared_component_view(unrelated)"),
            )),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entry)]
            reference = {"path": "src/decode.rs", "symbol": symbol}
            self.assertIn(reference, entry["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            wrong_model = (
                "part1_prepare_finish" if model == "part1_prepare_standard_component"
                else "part1_prepare_standard_component"
            )
            for before, after in (
                (f"{projection}(result)", f"{projection}(unrelated)"),
                (f"{projection}(result)", "unlisted_projection(result)"),
                (f"{projection}(result)", "result.is_ok()"),
                (f"ensures {projection}(result)", f"ensures result.is_ok() ==> {projection}(result)"),
                (f"crate::specs::{model}(", f"crate::specs::{wrong_model}("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
                *arguments,
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_binds_all_actual_refinement_frames_and_public_inputs(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        cases = (
            ("decode_ht_refinement_plane", "ht_refinement_plane", "ht_plane_outcome", None,
             ((r"code_block_plane_view\(cleanup_plane\)", "code_block_plane_view(unrelated)"),
              (r"resource_work_limit\(limits\)", "resource_work_limit(unrelated)"))),
            ("HtRefinementPlaneState::magnitude_sample", "ht_magref_sample", None, "ht_refinement_core_view",
             ((r"magnitude_value\(delta\)", "magnitude_limbs(delta)"),)),
            ("HtRefinementPlaneState::magnitude_column", "ht_magref_rows", None, "ht_refinement_core_view",
             ((r"\brows\s+as\s+nat\b", "0"), (r"\brows\s+as\s+nat\b", "rowsasnat"))),
            ("HtRefinementPlaneState::magnitude_stripe", "ht_magref_columns", None, "ht_refinement_core_view",
             ((r"\brows\s+as\s+nat\b", "0"),)),
            ("HtRefinementPlaneState::magnitude_pass", "ht_magref_stripes", None, "ht_refinement_core_view",
             ((r"\bwidth\s*,\s*height\b", "height, width"),)),
            ("HtSignificancePatchState::discover_sample", "ht_discover_sample", None, "ht_sigprop_patch_view",
             ((r"\bvertical_causal_context\b", "false"),)),
            ("HtSignificancePatchState::discover_column", "ht_discovery_rows", None, "ht_sigprop_patch_view",
             ((r"\brows\s+as\s+nat\b", "0"),)),
            ("HtSignificancePatchState::discover_patch", "ht_discovery_columns", None, "ht_sigprop_patch_view",
             ((r"\bstart\s+as\s+nat\b", "0"),)),
            ("HtSignificancePatchState::sign_sample", "ht_patch_sign_sample", None, "ht_sigprop_patch_view",
             ((r"\bindex\s+as\s+nat\b", "0"),)),
            ("HtSignificancePatchState::signs", "ht_pending_signs", None, "ht_sigprop_patch_view",
             ((r"ht_refinement_magnitude_view\(magnitude\)", "magnitude_value(magnitude)"),)),
            ("run_ht_significance_stripe", "ht_sigprop_patches", "ht_sigprop_plane_outcome", None,
             ((r"ht_sigprop_plane_view\(&input\)", "ht_sigprop_plane_view(&unrelated)"),
              (r"\brows\s+as\s+nat\b", "0"))),
            ("run_ht_significance_pass", "ht_sigprop_stripes", "ht_sigprop_plane_outcome", None,
             ((r"\bwidth\s*,\s*height\b", "height, width"),)),
            ("ht_significance_magnitude", "ht_significance_magnitude", "ht_refinement_magnitude_outcome", None,
             ((r"\bdecoded_bitplanes\b", "0"),)),
            ("ht_refinement_delta", "ht_refinement_delta", "ht_refinement_magnitude_outcome", None,
             ((r"\bdecoded_bitplanes\b", "0"),)),
            ("ht_collect_cleanup_significance", "ht_cleanup_significance", "ht_boolean_vector_view", None,
             ((r"coefficient_raw_views\(coefficients@\)", "coefficient_slice_view(coefficients@)"),)),
            ("CodeBlockPlane::apply_ht_refinement_decision", "ht_apply_refinement", None, "code_block_plane_view",
             ((r"\brefinement_bit\b", "false"),)),
            ("CodeBlockPlane::neighbor_summary_with_causality", "ht_neighbors", None, None,
             ((r"code_block_plane_view\(self\)", "code_block_plane_view(unrelated)"),
              (r"\bvertical_causal_context\b", "false"))),
            ("CodeBlockPlane::accumulate_neighbor", "ht_accumulate_neighbor", None, None,
             ((r"delta\.0\s*,\s*delta\.1", "delta.1, delta.0"),
              (r"\*old\(summary\)", "*final(summary)"))),
            ("ht_neighbor_summary_zero", "ht_neighbor_zero", None, None, ()),
            ("significant_neighbor_count", "ht_significant_neighbor_count", None, None,
             ((r"\bsummary\b", "unrelated"),)),
            ("Tier1PassStatistics::refined", "tier1_statistics_increment", None, None,
             ((r"\*old\(self\)\s*,\s*3\s*,\s*1", "*old(self), 0, 1"),
              (r"\*old\(self\)\s*,\s*3\s*,\s*1", "*old(self), 3, 2"))),
            ("Tier1CodeBlockDecoder::decode_high_throughput_segments", "ht_decode_segments", None, "tier1_decoder_state",
             ((r"ht_optional_bytes_view\(refinement\)", "ht_optional_bytes_view(None)"),
              (r"\bcleanup@", "cleanup@.take(0)"),
              (r"resource_code_block_pass_limit", "resource_code_block_byte_limit"),
              (r"resource_work_limit\(limits\)", "resource_work_limit(unrelated)"))),
            ("Tier1CodeBlockDecoder::decode_ht_coefficient_symbols", "ht_coefficient_symbols", None, "tier1_decoder_state",
             ((r"ht_block_segments_view\(&segments\)", "ht_block_segments_view(&unrelated)"),
              (r"\bskipped_bitplanes\b", "0"))),
            ("ht_significant_bitplanes", "ht_significant_bitplanes", None, None,
             ((r"\bmaximum_passes\b", "0"),)),
            ("Tier1BlockCoding::uses_high_throughput", "ht_block_coding_enabled", None, None,
             ((r"\bself\b", "unrelated"),)),
            ("copy_ht_refinement_bytes", "ht_copy_refinement_bytes", "ht_byte_vector_outcome", None,
             ((r"\binput@", "input@.take(0)"),)),
            ("Tier1PassStatistics::merge", "tier1_statistics_merge", None, None,
             ((r"\bother\b", "*old(self)"),)),
        )
        self.assertEqual(len(cases), 27)
        source = framework.ROOT / "src/tier1.rs"
        original = source.read_text()
        read_text = Path.read_text
        for symbol, model, projection, view, arguments in cases:
            entries = [
                item for item in original_coverage["requirements"]
                if {"path": "src/tier1.rs", "symbol": symbol} in item["contract_refs"]
            ]
            self.assertTrue(entries, symbol)
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [copy.deepcopy(entries[0])]
            reference = {"path": "src/tier1.rs", "symbol": symbol}
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            whole = re.search(
                r"\bensures\s+([\s\S]*?)\s*==\s*crate::specs::" + re.escape(model) + r"\(",
                contract,
            )
            self.assertIsNotNone(whole, symbol)
            lhs = whole[1]
            self.assertRegex(lhs, r"\bresult\b")
            if projection:
                self.assertRegex(lhs, re.escape(projection) + r"\(\s*result\s*\)")
            if view:
                self.assertRegex(lhs, re.escape(view) + r"\(\s*final\(\s*self\s*\)\s*\)")
            if symbol in (
                "decode_ht_refinement_plane",
                "Tier1CodeBlockDecoder::decode_high_throughput_segments",
                "Tier1CodeBlockDecoder::decode_ht_coefficient_symbols",
            ):
                self.assertNotRegex(contract, r"\brequires\b")
            wrong_model = next(
                ref["symbol"] for ref in entries[0]["spec_refs"] if ref["symbol"] != model
            )
            mutations = [
                ("unbound result", contract.replace(lhs, re.sub(r"\bresult\b", "unrelated", lhs), 1)),
                ("partial result", contract.replace(lhs, "result.is_ok()", 1)),
                ("success only", contract.replace(lhs, "result.is_ok() ==> " + lhs, 1)),
                ("wrong known model", contract.replace(
                    f"crate::specs::{model}(", f"crate::specs::{wrong_model}(")),
                ("unknown model", contract.replace(
                    f"crate::specs::{model}(", "crate::specs::unlisted_model(")),
            ]
            if projection:
                mutations.append(("unknown projection", contract.replace(projection, "unlisted_projection", 1)))
            for parameter in re.findall(r"\bfinal\(\s*(\w+)\s*\)", lhs):
                altered_lhs = re.sub(
                    r"\bfinal\(\s*" + re.escape(parameter) + r"\s*\)", f"old({parameter})", lhs,
                )
                mutations.append(("old output state", contract.replace(lhs, altered_lhs, 1)))
            if view:
                mutations.append(("unknown output view", contract.replace(
                    f"{view}(final(self))", "unlisted_view(final(self))", 1)))
                mutations.append(("wrong input state", contract.replace(
                    f"{view}(old(self))", f"{view}(final(self))")))
            elif "*old(self)" in contract:
                mutations.append(("wrong input state", contract.replace("*old(self)", "*final(self)")))
            for pattern, replacement in arguments:
                altered, count = re.subn(pattern, replacement, contract, count=1)
                self.assertEqual(count, 1, (symbol, pattern))
                mutations.append((pattern, altered))
            for label, modified_contract in mutations:
                self.assertNotEqual(modified_contract, contract, (symbol, label))
                modified = original[:start] + modified_contract + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, mutation=label), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
            wrong_caller = (
                "Tier1BlockCoding::uses_high_throughput" if symbol == "ht_neighbor_summary_zero"
                else "ht_neighbor_summary_zero"
            )
            wrong_callers = copy.deepcopy(coverage)
            wrong_callers["requirements"][0]["implementation_refs"] = [
                {"path": "src/tier1.rs", "symbol": wrong_caller}
            ]
            with self.subTest(symbol=symbol, mutation="wrong actual caller"), \
                    self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(wrong_callers)
            wrong_impl = copy.deepcopy(coverage)
            wrong_impl["requirements"][0]["contract_refs"] = [
                {"path": "src/tier1.rs", "symbol": "UnlistedImpl::" + symbol.rsplit("::", 1)[-1]}
            ]
            with self.subTest(symbol=symbol, mutation="wrong impl"), \
                    self.assertRaisesRegex(ValueError, "missing linked contract function"):
                framework.validate_normative_coverage(wrong_impl)

    def test_inventory_binds_complete_cleanup_caller_stages_to_exact_native_inputs(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        original = source.read_text()
        for symbol, model, mutations in (
            ("prepare_ht_cleanup_symbols", "ht_cleanup_prepare", (
                ("ht_cleanup_prepare_outcome(result)", "ht_cleanup_prepare_outcome(unrelated)"),
                ("ht_cleanup_prepare_outcome(result)", "code_block_plane_outcome(result)"),
                ("ht_cleanup_prepare_outcome(result)", "result.is_ok()"),
                ("code_block_plane_view(plane)", "code_block_plane_view(unrelated)"),
                ("resource_work_limit(limits)", "resource_work_limit(unrelated)"),
                ("skipped_bitplanes", "0"),
            )),
            ("Tier1CodeBlockDecoder::store_ht_coefficient_symbols", "ht_store_coefficient_symbols", (
                ("(result,", "(unrelated,"),
                ("(result,", "(result.is_ok(),"),
                ("tier1_decoder_state(final(self))", "tier1_decoder_state(old(self))"),
                ("tier1_decoder_state(old(self))", "tier1_decoder_state(final(self))"),
                ("code_block_plane_view(&output)", "code_block_plane_view(&cleanup_plane)"),
                ("has_refinement", "false"),
                ("decoded_bitplanes", "0"),
            )),
            ("CodeBlockPlane::duplicate", "tier1_duplicate_plane", (
                ("code_block_plane_outcome(result)", "code_block_plane_outcome(unrelated)"),
                ("code_block_plane_outcome(result)", "ht_cleanup_prepare_outcome(result)"),
                ("code_block_plane_outcome(result)", "result.is_ok()"),
                ("code_block_plane_view(self)", "code_block_plane_view(unrelated)"),
            )),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if item["id"] == "part15-cleanup-only-actual-symbol-caller"
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            reference = {"path": "src/tier1.rs", "symbol": symbol}
            self.assertIn(reference, coverage["requirements"][0]["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(original, symbol)
            signature = original.find("fn", header.start())
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            wrong_model = "ht_cleanup_prepare" if model != "ht_cleanup_prepare" else "tier1_duplicate_plane"
            for before, after in (
                *mutations,
                (f"crate::specs::{model}(", f"crate::specs::{wrong_model}("),
                (f"crate::specs::{model}(", "crate::specs::unlisted_model("),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
    def test_inventory_binds_complete_palette_lookup_to_actual_result_and_inputs(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-complete-native-palette-lookup"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        reference = {"path": "src/jp2.rs", "symbol": "Palette::value"}
        self.assertIn(reference, coverage["requirements"][0]["contract_refs"])
        coverage["requirements"][0]["contract_refs"] = [reference]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        source = framework.ROOT / reference["path"]
        read_text = Path.read_text
        original = source.read_text()
        signature = original.find(
            "fn", framework._coverage_function_header(original, reference["symbol"]).start(),
        )
        start = original.rfind("#[cfg_attr", 0, signature)
        contract = original[start:signature]
        for before, after in (
            ("ensures result ==", "ensures unrelated =="),
            ("ensures result ==", "ensures result.is_ok() =="),
            ("crate::specs::part2_palette_value(", "crate::specs::part2_composition_error("),
            ("crate::specs::part2_palette_value(", "crate::specs::unlisted_model("),
            ("palette_view(self)", "palette_view(unrelated)"),
            ("palette_view(self), entry, column", "palette_view(self), column, entry"),
            ("palette_view(self), entry, column", "palette_view(self), entry, 0"),
            ("ensures result ==", "ensures result.is_ok() ==> result =="),
        ):
            self.assertIn(before, contract)
            modified = original[:start] + contract.replace(before, after) + original[signature:]

            def altered(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(after=after), \
                    mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_binds_typed_conversion_and_packet_access_to_exact_results(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        read_text = Path.read_text
        for relative, symbol, projection, model, requirement in (
            ("src/image.rs", "DecodedComponent::typed_samples", "decoded_typed_samples_outcome",
             "part1_decoded_component_typed_samples", "part1-complete-decoded-typed-conversion"),
            ("src/image.rs", "DecodedImage::typed", "decoded_typed_image_outcome",
             "part1_decoded_image_typed", "part1-complete-decoded-typed-conversion"),
            ("src/packet.rs", "PacketPrecinctDecoder::decoder", "packet_decoder_outcome",
             "part1_packet_precinct_decoder", "part1-complete-raw-packet-decoder-access"),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"] if item["id"] == requirement
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            reference = {"path": relative, "symbol": symbol}
            self.assertIn(reference, coverage["requirements"][0]["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [reference]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            source = framework.ROOT / relative
            original = source.read_text()
            end = framework._coverage_function_header(original, symbol).start()
            signature = original.find("fn", end)
            start = original.rfind("#[cfg_attr", 0, signature)
            contract = original[start:signature]
            for before, after in (
                (f"{projection}(result)", f"{projection}(unrelated)"),
                (f"{projection}(result)", "unlisted_projection(result)"),
                (f"{projection}(result)", "decoded_image_outcome(result)"),
                (f"{projection}(result)", "result.is_ok()"),
                (f"== crate::specs::{model}(", "== crate::specs::unlisted_model("),
                (f"== crate::specs::{model}(", f"<= crate::specs::{model}("),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[signature:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_binds_complete_numeric_magnitude_and_every_reader_state(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part15-numeric-magnitude-reader-state"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        producer = {"path": "src/tier1.rs", "symbol": "reconstruct_ht_magnitude"}
        self.assertIn(producer, coverage["requirements"][0]["contract_refs"])
        coverage["requirements"][0]["contract_refs"] = [producer]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        source = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        original = source.read_text()
        end = re.search(r"\bfn\s+reconstruct_ht_magnitude\b", original).start()
        start = original.rfind("#[cfg_attr", 0, end)
        contract = original[start:end]
        for before, after in (
            ("ht_numeric_magnitude_outcome(result)", "ht_numeric_magnitude_outcome(unrelated)"),
            ("ht_numeric_magnitude_outcome(result)", "unlisted_projection(result)"),
            ("ht_numeric_magnitude_outcome(result)", "ht_block_segments_outcome(result)"),
            ("ht_numeric_magnitude_outcome(result)", "result.is_ok()"),
            ("ht_magsgn_view(final(reader))", "ht_magsgn_view(old(reader))"),
            ("ht_magsgn_view(final(reader))", "ht_reverse_vlc_view(final(reader))"),
            ("ht_magsgn_view(final(reader))", "ht_magsgn_view(final(unrelated))"),
            ("ht_magsgn_view(old(reader))", "ht_magsgn_view(final(reader))"),
            ("== crate::specs::ht_reconstruct_numeric_magnitude(", "== crate::specs::ht_numeric_center("),
            ("== crate::specs::ht_reconstruct_numeric_magnitude(", "== crate::specs::unlisted_model("),
        ):
            self.assertIn(before, contract)
            modified = original[:start] + contract.replace(before, after) + original[end:]

            def altered(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)
        for pattern, replacement in (
            (r"\bcompleted_u\s*,\s*embedded_bit", "unrelated_u, embedded_bit"),
            (r"\bembedded_bit\s*,\s*embedded_value", "embedded_value, embedded_bit"),
            (r"\bdecoded_bitplanes\s*,?\s*\)", "unrelated_planes)"),
        ):
            modified_contract, changed = re.subn(pattern, replacement, contract, count=1)
            self.assertEqual(changed, 1)
            modified = original[:start] + modified_contract + original[end:]
            with self.subTest(replacement=replacement), \
                    mock.patch.object(Path, "read_text",
                                      lambda path, *args, **kwargs:
                                      modified if path == source else read_text(path, *args, **kwargs)), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_retains_every_complete_assembly_helper_model_link(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part1-complete-registered-tile-image-assembly"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        for model in (
            "part1_assembly_component_dimensions", "part1_assembly_component_crop",
            "part1_assembly_tile_step", "part1_place_assembly_tile",
            "part1_place_selected_tile", "part1_assembly_rectangle",
            "part1_assembly_row_prefix", "part1_assembly_selected_header",
        ):
            altered = copy.deepcopy(coverage)
            reference = {"path": "specs/mod.rs", "symbol": model}
            self.assertIn(reference, altered["requirements"][0]["spec_refs"])
            altered["requirements"][0]["spec_refs"].remove(reference)
            with self.subTest(missing_model=model), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(altered)

    def test_inventory_binds_complete_assembly_to_full_result_and_exact_model(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/image.rs"
        read_text = Path.read_text
        original = source.read_text()
        for function, model, wrong_model in (
            ("assemble_image", "part1_assemble_image", "part1_assemble_selected_image"),
            ("assemble_selected_image", "part1_assemble_selected_image", "part1_assemble_image"),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if item["id"] == "part1-complete-registered-tile-image-assembly"
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            self.assertIn({"path": "src/image.rs", "symbol": function}, coverage["requirements"][0]["contract_refs"])
            coverage["requirements"][0]["contract_refs"] = [{"path": "src/image.rs", "symbol": function}]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            end = re.search(rf"\bfn\s+{re.escape(function)}\b", original).start()
            start = original.rfind("#[cfg_attr", 0, end)
            contract = original[start:end]
            for before, after in (
                ("ensures decoded_image_outcome(result)", "ensures decoded_image_outcome(unrelated)"),
                ("ensures decoded_image_outcome(result)", "ensures unlisted_projection(result)"),
                ("ensures decoded_image_outcome(result)", "ensures sequence_outcome(result)"),
                ("ensures decoded_image_outcome(result)", "ensures result.is_ok()"),
                ("ensures decoded_image_outcome(result)", "ensures result.is_err()"),
                (f"== crate::specs::{model}(", f"== crate::specs::{wrong_model}("),
                (f"== crate::specs::{model}(", "== crate::specs::unlisted_model("),
                (f"== crate::specs::{model}(", f"<= crate::specs::{model}("),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[end:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(function=function, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)

    def test_inventory_binds_complete_ht_metadata_to_actual_inputs_limit_and_caller(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part15-complete-cleanup-metadata"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        producer = {"path": "src/tier1.rs", "symbol": "decode_ht_cleanup_segment_metadata"}
        self.assertIn(producer, coverage["requirements"][0]["contract_refs"])
        coverage["requirements"][0]["contract_refs"] = [producer]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        source = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        original = source.read_text()
        end = re.search(r"\bfn\s+decode_ht_cleanup_segment_metadata\b", original).start()
        start = original.rfind("#[cfg_attr", 0, end)
        contract = original[start:end]
        for before, after in (
            ("ensures ht_cleanup_metadata_outcome(result)", "ensures ht_cleanup_metadata_outcome(unrelated)"),
            ("ensures ht_cleanup_metadata_outcome(result)", "ensures unlisted_projection(result)"),
            ("ensures ht_cleanup_metadata_outcome(result)", "ensures ht_block_segments_outcome(result)"),
            ("ensures ht_cleanup_metadata_outcome(result)", "ensures result.is_ok()"),
            ("== crate::specs::ht_cleanup_segment_metadata(", "== crate::specs::ht_decode_cleanup_metadata("),
            ("== crate::specs::ht_cleanup_segment_metadata(", "== crate::specs::ht_cleanup_quad_word("),
            ("== crate::specs::ht_cleanup_segment_metadata(", "<= crate::specs::ht_cleanup_segment_metadata("),
        ):
            self.assertIn(before, contract)
            modified = original[:start] + contract.replace(before, after) + original[end:]

            def altered(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)
        for pattern, replacement in (
            (r"ht_cleanup_segment_view\(\s*&\s*cleanup\s*\)", "ht_cleanup_segment_view(&unrelated)"),
            (r"crate::limits::resource_work_limit\(\s*limits\s*\)", "crate::limits::resource_work_limit(default_limits)"),
            (r"crate::limits::resource_work_limit\(\s*limits\s*\)", "crate::limits::resource_work_limit(old(limits))"),
            (r"\bwidth\s*,\s*height\s*,\s*maximum_u\b", "height, width, maximum_u"),
        ):
            modified_contract, changed = re.subn(pattern, replacement, contract, count=1)
            self.assertEqual(changed, 1)
            modified = original[:start] + modified_contract + original[end:]
            with self.subTest(replacement=replacement), \
                    mock.patch.object(Path, "read_text",
                                      lambda path, *args, **kwargs:
                                      modified if path == source else read_text(path, *args, **kwargs)), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)
        for caller in ("HtForwardRefinementReader::read_bit", "UnknownDecoder::decode_ht_coefficient_symbols"):
            wrong = copy.deepcopy(coverage)
            wrong["requirements"][0]["implementation_refs"] = [{"path": "src/tier1.rs", "symbol": caller}]
            with self.subTest(caller=caller), \
                    self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(wrong)

    def test_inventory_binds_complete_ht_parser_to_its_exact_outcome_and_model(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part15-cleanup-partition"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        coverage["requirements"][0]["contract_refs"] = [
            {"path": "src/tier1.rs", "symbol": "parse_ht_block_segments"}
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        source = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        original = source.read_text()
        end = re.search(r"\bfn\s+parse_ht_block_segments\b", original).start()
        start = original.rfind("#[cfg_attr", 0, end)
        contract = original[start:end]
        for before, after in (
            ("ensures ht_block_segments_outcome(result)", "ensures ht_block_segments_outcome(unrelated)"),
            ("ensures ht_block_segments_outcome(result)", "ensures unlisted_projection(result)"),
            ("ensures ht_block_segments_outcome(result)", "ensures raw_reader_outcome(result)"),
            ("ensures ht_block_segments_outcome(result)", "ensures result.is_ok()"),
            ("== crate::specs::ht_parse_block_segments(", "== crate::specs::unlisted_model("),
            ("== crate::specs::ht_parse_block_segments(", "== crate::specs::ht_scup("),
            ("== crate::specs::ht_parse_block_segments(", "<= crate::specs::ht_parse_block_segments("),
        ):
            self.assertIn(before, contract)
            modified = original[:start] + contract.replace(before, after) + original[end:]

            def altered(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_binds_connected_selected_color_to_actual_result_and_exact_model(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part1-connected-typed-color-selection"
        ]
        self.assertEqual(len(coverage["requirements"]), 1)
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        source = framework.ROOT / "src/decode.rs"
        read_text = Path.read_text
        original = source.read_text()
        end = re.search(r"\bfn\s+convert_selected_color\b", original).start()
        start = original.rfind("#[cfg_attr", 0, end)
        contract = original[start:end]
        for before, after in (
            ("ensures crate::color::converted_image_result(result)", "ensures crate::color::converted_image_result(unrelated)"),
            ("ensures crate::color::converted_image_result(result)", "ensures unlisted_projection(result)"),
            ("ensures crate::color::converted_image_result(result)", "ensures result.is_ok()"),
            ("== crate::specs::color_convert_selected(", "== crate::specs::unlisted_model("),
            ("== crate::specs::color_convert_selected(", "== crate::specs::color_crop_image("),
            ("== crate::specs::color_convert_selected(", "== crate::specs::color_convert_jp2("),
            ("== crate::specs::color_convert_selected(", "<= crate::specs::color_convert_selected("),
        ):
            self.assertIn(before, contract)
            modified = original[:start] + contract.replace(before, after) + original[end:]

            def altered(path, *args, **kwargs):
                return modified if path == source else read_text(path, *args, **kwargs)

            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_binds_complete_crop_to_exact_full_result_models(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/color.rs"
        original = source.read_text()
        read_text = Path.read_text
        for symbol, projection in (
            ("ConvertedImage::crop", "converted_image_result(result)"),
            ("crop_plane", "normalized_plane_result(result)"),
            ("crop_sample", "result"),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if item["id"] == "part1-complete-converted-selection-crop"
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            coverage["requirements"][0]["contract_refs"] = [{"path": "src/color.rs", "symbol": symbol}]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            short = symbol.rsplit("::", 1)[-1]
            end = re.search(rf"\bfn\s+{re.escape(short)}\b", original).start()
            start = original.rfind("#[cfg_attr", 0, end)
            contract = original[start:end]
            unbound = "unrelated" if projection == "result" else projection.replace("(result)", "(unrelated)")
            for before, after in (
                (f"ensures {projection}", f"ensures {unbound}"),
                (f"ensures {projection}", "ensures unlisted_projection(result)"),
                (f"ensures {projection}", "ensures result.is_ok()"),
                ("== crate::specs::", "<= crate::specs::"),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[end:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(symbol=symbol, after=after), mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
            wrong_model = "color_crop_plane" if short == "crop" else "color_crop_image"
            modified_contract = re.sub(r"== crate::specs::\w+\(", f"== crate::specs::{wrong_model}(", contract, count=1)
            self.assertNotEqual(modified_contract, contract)
            modified = original[:start] + modified_contract + original[end:]
            with mock.patch.object(Path, "read_text",
                                   lambda path, *args, **kwargs:
                                   modified if path == source else read_text(path, *args, **kwargs)), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_binds_each_complete_color_converter_result_to_its_exact_model(self):
        original_coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        source = framework.ROOT / "src/color.rs"
        original = source.read_text()
        read_text = Path.read_text
        for function, projection in (
            ("convert_jp2_color", "converted_image_result(result)"),
            ("convert_color_channel", "converted_channel_result(result)"),
            ("convert_alpha_channel", "converted_channel_result(result)"),
            ("convert_sycc_pixel", "result"),
            ("validate_components", "result"),
            ("validate_component_index", "result"),
            ("validate_component", "result"),
            ("validate_output_size", "result"),
        ):
            coverage = copy.deepcopy(original_coverage)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if item["id"] == "part1-complete-typed-color-conversion"
            ]
            self.assertEqual(len(coverage["requirements"]), 1)
            coverage["requirements"][0]["contract_refs"] = [
                {"path": "src/color.rs", "symbol": function}
            ]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            end = re.search(rf"\bfn\s+{re.escape(function)}\b", original).start()
            start = original.rfind("#[cfg_attr", 0, end)
            contract = original[start:end]
            wrong_model = "color_convert_channel" if function == "convert_jp2_color" else "color_convert_jp2"
            unbound = "unrelated" if projection == "result" else projection.replace("(result)", "(unrelated)")
            for before, after in (
                (f"ensures {projection}", f"ensures {unbound}"),
                (f"ensures {projection}", "ensures unlisted_projection(result)"),
                (f"ensures {projection}", "ensures normalized_plane_result(result)"),
                (f"ensures {projection}", "ensures result.is_ok()"),
                ("== crate::specs::", "<= crate::specs::"),
            ):
                self.assertIn(before, contract)
                modified = original[:start] + contract.replace(before, after) + original[end:]

                def altered(path, *args, **kwargs):
                    return modified if path == source else read_text(path, *args, **kwargs)

                with self.subTest(function=function, after=after), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
            modified_contract = re.sub(
                r"== crate::specs::\w+\(", f"== crate::specs::{wrong_model}(", contract, count=1,
            )
            self.assertNotEqual(modified_contract, contract)
            modified = original[:start] + modified_contract + original[end:]
            with self.subTest(function=function, wrong_listed_model=wrong_model), \
                    mock.patch.object(Path, "read_text",
                                      lambda path, *args, **kwargs:
                                      modified if path == source else read_text(path, *args, **kwargs)), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_requires_all_mutable_outputs_in_planar_state_relation(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        coverage["requirements"][0]["contract_refs"] = [
            {"path": "src/refinement.rs", "symbol": symbol}
            for symbol in ("scatter_composition_pixel", "compose_planar_pixel")
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("verus_spec(composed =>", "verus_spec(unrelated =>"),
            ("ensures (composed,", "ensures (true,"),
            ("part2_composition_planes(final(output_colors)@), final(output_alpha)@)",
             "part2_composition_planes(final(output_colors)@))"),
            ("part2_composition_planes(final(output_colors)@), final(output_alpha)@)",
             "part2_composition_planes(final(output_colors)@), final(output_colors)@)"),
            ("part2_composition_planes(final(output_colors)@)",
             "part2_composition_planes(old(output_colors)@)"),
            ("final(output_alpha)@", "old(output_alpha)@"),
            ("part2_composition_planes(final(output_colors)@)",
             "unlisted_projection(final(output_colors)@)"),
            ("== crate::specs::part2_composition_pixel_transition",
             "== crate::specs::unlisted_model"),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/refinement.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_requires_bound_result_and_complete_mutable_reader_view(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part1-raw-bitstream-state"
        ]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("ensures raw_reader_outcome(result)", "ensures raw_reader_outcome(unrelated)"),
            ("ensures raw_reader_outcome(result)", "ensures unlisted_projection(result)"),
            ("ensures (result, raw_bit_reader_view(final(self)))",
             "ensures (true, raw_bit_reader_view(final(self)))"),
            ("ensures (result, raw_bit_reader_view(final(self)))",
             "ensures (result, raw_bit_reader_view(old(self)))"),
            ("ensures (result, raw_bit_reader_view(final(self)))",
             "ensures (result, raw_bit_reader_view(final(self)).bits_remaining)"),
            ("ensures (result, raw_bit_reader_view(final(self)))",
             "ensures (result, unlisted_projection(final(self)))"),
            ("== crate::specs::part1_raw_reader_read(", "== crate::specs::unlisted_model("),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/tier1.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_resolves_duplicate_methods_inside_the_requested_impl(self):
        text = """impl Legacy {
    fn read_bit(&mut self) {
        legacy_marker();
    }
}
impl<'a> HtMelBitReader<'a> {
    fn read_bit(&mut self) {
        mel_marker();
    }
}
impl HtReverseVlcReader {
    fn read_bit(&mut self) {
        vlc_marker();
    }
}
"""
        self.assertTrue(framework._coverage_same_file_call(text, "Legacy::read_bit", "legacy_marker"))
        self.assertFalse(framework._coverage_same_file_call(text, "Legacy::read_bit", "mel_marker"))
        self.assertTrue(framework._coverage_same_file_call(text, "HtMelBitReader::read_bit", "mel_marker"))
        self.assertFalse(framework._coverage_same_file_call(text, "HtMelBitReader::read_bit", "vlc_marker"))
        self.assertTrue(framework._coverage_same_file_call(text, "HtReverseVlcReader::read_bit", "vlc_marker"))
        self.assertIsNone(framework._coverage_function_header(text, "Unknown::read_bit"))

    def test_inventory_requires_function_specific_complete_ht_reader_relations(self):
        original = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        original["requirements"] = [
            item for item in original["requirements"]
            if item["id"] in (
                "part15-cleanup-reader-single-bit-state", "part15-directional-word-event-state",
                "part15-uvlc-quad-word-state",
            )
        ]
        self.assertEqual(framework.validate_normative_coverage(original)["status"], "passed")
        source_path = framework.ROOT / "src/tier1.rs"
        read_text = Path.read_text
        source = read_text(source_path)
        entries = [
            ("ht_mel_from_input", "ht_mel_outcome", "ht_mel_initial", False),
            ("ht_reverse_vlc_from_input", "ht_reverse_vlc_outcome", "ht_reverse_vlc_initial", False),
            ("ht_cleanup_readers_from_inputs", "ht_cleanup_readers_outcome", "ht_cleanup_readers_initial", False),
            ("HtMelBitReader::load_byte", "ht_mel_view", "ht_mel_load", True),
            ("HtMelBitReader::read_bit", "ht_mel_view", "ht_mel_read", True),
            ("HtReverseVlcReader::load_previous_byte", "ht_reverse_vlc_view", "ht_reverse_vlc_load", True),
            ("HtReverseVlcReader::read_bit", "ht_reverse_vlc_view", "ht_reverse_vlc_read", True),
            ("HtCleanupReaders::tick", "ht_cleanup_readers_view", "ht_cleanup_reader_tick", True),
            ("HtCleanupReaders::read_mel_bit", "ht_cleanup_readers_view", "ht_cleanup_reader_read_mel", True),
            ("HtCleanupReaders::read_vlc_bit", "ht_cleanup_readers_view", "ht_cleanup_reader_read_vlc", True),
            ("ht_magsgn_from_input", "ht_magsgn_outcome", "ht_magsgn_initial", False),
            ("ht_forward_refinement_from_input", "ht_forward_refinement_outcome", "ht_forward_refinement_initial", False),
            ("ht_reverse_refinement_from_input", "ht_reverse_refinement_outcome", "ht_reverse_refinement_initial", False),
            ("ht_refinement_readers_from_inputs", "ht_refinement_readers_outcome", "ht_refinement_readers_initial", False),
            ("HtForwardMagSgnReader::load_byte", "ht_magsgn_view", "ht_magsgn_load", True),
            ("HtForwardMagSgnReader::read_bit", "ht_magsgn_view", "ht_magsgn_read", True),
            ("HtForwardMagSgnReader::read_bits", "ht_magsgn_view", "ht_magsgn_read_bits", True),
            ("HtForwardMagSgnReader::finish", "ht_magsgn_view", "ht_magsgn_finish", True),
            ("HtForwardRefinementReader::load_byte", "ht_forward_refinement_view", "ht_forward_refinement_load", True),
            ("HtForwardRefinementReader::read_positioned_bit", "ht_forward_refinement_view", "ht_forward_refinement_positioned", True),
            ("HtForwardRefinementReader::read_bit", "ht_forward_refinement_view", "ht_forward_refinement_read", True),
            ("HtReverseRefinementReader::load_previous_byte", "ht_reverse_refinement_view", "ht_reverse_refinement_load", True),
            ("HtReverseRefinementReader::read_positioned_bit", "ht_reverse_refinement_view", "ht_reverse_refinement_positioned", True),
            ("HtReverseRefinementReader::read_bit", "ht_reverse_refinement_view", "ht_reverse_refinement_read", True),
            ("HtRefinementReaders::claim", "ht_refinement_readers_view", "ht_refinement_claim", True),
            ("HtRefinementReaders::read_forward", "ht_refinement_readers_view", "ht_refinement_read_forward", True),
            ("HtRefinementReaders::read_reverse", "ht_refinement_readers_view", "ht_refinement_read_reverse", True),
            ("HtCleanupReaders::advance_vlc", "ht_cleanup_readers_view", "ht_cleanup_advance_vlc", True),
            ("HtCleanupReaders::mel_event", "ht_cleanup_readers_view", "ht_cleanup_mel_event", True),
            ("HtCleanupReaders::read_prefix", "ht_cleanup_readers_view", "ht_uvlc_prefix", True),
            ("HtCleanupReaders::read_suffix", "ht_cleanup_readers_view", "ht_uvlc_suffix", True),
            ("HtCleanupReaders::prefix_value", "ht_cleanup_readers_view", "ht_uvlc_prefix_value", True),
            ("HtCleanupReaders::decode_initial_u", "ht_cleanup_readers_view", "ht_uvlc_initial", True),
            ("HtCleanupReaders::decode_non_initial_u", "ht_cleanup_readers_view", "ht_uvlc_non_initial", True),
            ("HtCleanupReaders::decode_quad_word", "ht_cleanup_readers_view", "ht_cleanup_quad_word", True),
        ]
        for symbol, projection, model, stateful in entries:
            coverage = copy.deepcopy(original)
            coverage["requirements"] = [
                item for item in coverage["requirements"]
                if any(ref["symbol"] == model for ref in item["spec_refs"])
            ][:1]
            coverage["requirements"][0]["contract_refs"] = [{"path": "src/tier1.rs", "symbol": symbol}]
            if symbol in (
                "HtForwardRefinementReader::read_bit", "HtReverseRefinementReader::read_bit",
                "HtForwardMagSgnReader::read_bits",
            ):
                # These public adapters have real API tests, not internal decoder callers.
                coverage["requirements"][0]["implementation_refs"] = [{
                    "path": "src/tier1.rs",
                    "symbol": (
                        "ht_magsgn_words_have_exact_fill_and_physical_state"
                        if symbol == "HtForwardMagSgnReader::read_bits"
                        else "ht_refinement_counter_and_sum_overflow_preserve_ordered_cursor_updates"
                    ),
                }]
            self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
            header = framework._coverage_function_header(source, symbol)
            self.assertIsNotNone(header)
            signature = source.find("fn", header.start(), header.end())
            start = source.rfind("#[cfg_attr", 0, signature)
            contract = source[start:signature]
            binder = re.search(r"\bverus_spec\(\s*(\w+)\s*=>", contract)[1]
            call = re.escape(projection) + r"\(\s*" + (
                r"final\(\s*self\s*\)" if stateful else re.escape(binder)
            ) + r"\s*\)"
            wrong_view = "ht_reverse_vlc_view" if projection == "ht_mel_view" else "ht_mel_view"
            wrong_model = next(
                ref["symbol"] for ref in coverage["requirements"][0]["spec_refs"]
                if ref["symbol"] != model
            )
            replacements = [
                re.sub(r"\bverus_spec\(\s*\w+\s*=>", "verus_spec(unrelated =>", contract, count=1),
                re.sub(call, "unlisted_projection(" + ("final(self)" if stateful else binder) + ")", contract, count=1),
                contract.replace("crate::specs::" + model + "(", "crate::specs::" + wrong_model + "(", 1),
            ]
            if stateful:
                replacements.extend((
                    re.sub(call, projection + "(old(self))", contract, count=1),
                    re.sub(call, projection + "(final(self)).work_units", contract, count=1),
                    re.sub(call, wrong_view + "(final(self))", contract, count=1),
                    contract.replace("old(self)", "self", 1),
                ))
            else:
                replacements.append(re.sub(call, projection + "(unrelated)", contract, count=1))
            for replacement in replacements:
                self.assertNotEqual(replacement, contract)

                def altered(path, *args, **kwargs):
                    text = read_text(path, *args, **kwargs)
                    return text[:start] + replacement + text[signature:] if path == source_path else text

                with self.subTest(symbol=symbol, replacement=replacement[:120]), \
                        mock.patch.object(Path, "read_text", altered), \
                        self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                    framework.validate_normative_coverage(coverage)
        wrong = copy.deepcopy(original)
        wrong["requirements"][0]["contract_refs"] = [{
            "path": "src/tier1.rs", "symbol": "Unknown::read_bit",
        }]
        with self.assertRaisesRegex(ValueError, "missing linked contract function"):
            framework.validate_normative_coverage(wrong)

    def test_inventory_checks_success_guard_and_all_layer_outputs(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        coverage["requirements"][0]["contract_refs"] = [{
            "path": "src/jpx.rs", "symbol": "composite_placed_layer",
        }]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("verus_spec(result =>", "verus_spec(unrelated =>"),
            ("ensures result.is_ok() ==>", "ensures unrelated.is_ok() ==>"),
            ("ensures result.is_ok() ==>", "ensures"),
            ("(result.is_ok(), crate::specs::", "(true, crate::specs::"),
            (", *final(work_units) as nat)", ")"),
            ("*final(work_units) as nat", "*old(work_units) as nat"),
            ("*final(work_units) as nat", "final(output_alpha)@"),
            ("== crate::specs::part2_composition_layer_success", "== crate::specs::unlisted_model"),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/jpx.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_same_file_usage_requires_another_listed_function_body(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        entry = coverage["requirements"][0]
        entry["contract_refs"] = [{"path": "src/jpx.rs", "symbol": "composite_placed_layer"}]
        entry["implementation_refs"] = [{"path": "src/jpx.rs", "symbol": "render_decoded_layers"}]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        for symbol in ("index_of", "render_jpx_frame", "composite_placed_layer"):
            entry["implementation_refs"] = [{"path": "src/jpx.rs", "symbol": symbol}]
            with self.subTest(symbol=symbol), \
                    self.assertRaisesRegex(ValueError, "not used by claimed implementation"):
                framework.validate_normative_coverage(coverage)

    def test_inventory_checks_typed_result_model_equalities(self):
        coverage = json.loads((framework.VALIDATION / "normative-coverage.json").read_text())
        coverage["requirements"] = [
            item for item in coverage["requirements"]
            if item["id"] == "part2-jpx-composition-rendering"
        ]
        coverage["requirements"][0]["contract_refs"] = [{
            "path": "src/refinement.rs", "symbol": symbol,
        } for symbol in ("composition_clip", "composition_pixel_index", "composition_mapped_offset")]
        self.assertEqual(framework.validate_normative_coverage(coverage)["status"], "passed")
        read_text = Path.read_text
        for before, after in (
            ("verus_spec(index =>", "verus_spec(unrelated =>"),
            ("ensures index ==", "ensures index.is_some() =="),
            ("ensures index ==", "ensures None =="),
            ("ensures clipped ==", "ensures clipped >="),
            ("ensures mapped as nat ==", "requires mapped as nat =="),
            ("== crate::specs::part2_composition_pixel_index", "== crate::specs::unlisted_model"),
        ):
            def altered(path, *args, **kwargs):
                text = read_text(path, *args, **kwargs)
                return text.replace(before, after) if path == framework.ROOT / "src/refinement.rs" else text
            with self.subTest(after=after), mock.patch.object(Path, "read_text", altered), \
                    self.assertRaisesRegex(ValueError, "lacks executable Verus contract"):
                framework.validate_normative_coverage(coverage)

    def test_build_subject_is_locked(self):
        executable = self.work / "built-subject"
        executable.touch()
        with mock.patch.object(framework, "resolve_subject", return_value=executable), mock.patch.object(framework.subprocess, "run") as run:
            self.assertEqual(framework.build_subject(), executable)
        self.assertIn("--locked", run.call_args.args[0])

    def test_run_outputs_are_redirectable_and_schemas_accept_new_results(self):
        subject = self.subject()
        result = framework.run_validation(subject, include_external=False, output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "passed")
        self.assertEqual(result["summary"]["external_oracles_available"], 0)
        adjudications = json.loads((self.work / "oracle-adjudications.json").read_text())
        self.assertEqual(adjudications["status"], "skipped")
        self.assertRegex(result["provenance"]["git_commit"], r"^[a-f0-9]{40,64}$")
        self.assertIsInstance(result["provenance"]["git_dirty"], bool)
        self.assertTrue(result["provenance"]["tool_hashes"])
        self.assertTrue((self.work / result["$schema"]).is_file())
        budget = framework.run_budget(subject, output_dir=self.work)
        self.assertEqual(budget["summary"]["status"], "passed")
        self.assertEqual(framework.validate_evidence_schemas(self.work)["status"], "passed")
        self.assertFalse((framework.VALIDATION / "results/validation-results.json").exists())

    def test_default_output_is_ignored_and_tracked_overwrites_are_refused(self):
        self.assertEqual(framework.RESULTS_DIR, framework.ROOT / "target/validation")
        path = framework.report_path(None, "validation-results.json")
        result = subprocess.run(["git", "check-ignore", str(path)], cwd=framework.ROOT, capture_output=True)
        self.assertEqual(result.returncode, 0)
        with self.assertRaisesRegex(ValueError, "tracked"):
            framework.report_path(framework.ROOT, "Cargo.toml")

    def test_missing_unconfigured_oracle_is_skipped(self):
        with mock.patch.dict(os.environ, {}, clear=True), mock.patch.object(framework.shutil, "which", return_value=None):
            result = framework.run_validation(self.subject(), oracle_config=self.oracle_config(), output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "passed")
        self.assertEqual(result["oracles"][1]["status"], "skipped")
        self.assertEqual(result["summary"]["external_oracles_skipped"], 1)

    def test_explicit_missing_oracle_is_failed_not_skipped(self):
        with mock.patch.dict(os.environ, {"OPENJPEG_DECODER": str(self.work / "missing")}, clear=True):
            result = framework.run_validation(self.subject(), oracle_config=self.oracle_config(), output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "failed")
        self.assertEqual(result["oracles"][1]["status"], "failed")
        self.assertEqual(result["summary"]["oracle_errors"], 1)

    def test_invalid_oracle_output_is_failed_not_a_rejection_or_skip(self):
        oracle = self.work / "oracle"
        oracle.write_text(f"#!{sys.executable}\nraise SystemExit(0)\n")
        oracle.chmod(0o700)
        with mock.patch.dict(os.environ, {"OPENJPEG_DECODER": str(oracle)}, clear=True):
            result = framework.run_validation(self.subject(), oracle_config=self.oracle_config(), output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "failed")
        self.assertGreater(result["summary"]["oracle_errors"], 0)
        self.assertTrue(any(
            record["outcomes"].get("openjpeg", {}).get("execution_failed")
            for record in result["records"]
        ))
        adjudications = json.loads((self.work / "oracle-adjudications.json").read_text())
        self.assertEqual(adjudications["status"], "blocked")

    def test_oracle_timeout_is_failure_not_skip(self):
        subject = self.subject()
        oracle = self.work / "oracle"
        shutil.copyfile(subject, oracle)
        oracle.chmod(0o700)
        original_run = framework._run_process

        def timeout_external(command, timeout):
            if command[0] == str(oracle):
                raise subprocess.TimeoutExpired(command, timeout)
            return original_run(command, timeout)

        with mock.patch.dict(os.environ, {"OPENJPEG_DECODER": str(oracle)}, clear=True), mock.patch.object(framework, "_run_process", side_effect=timeout_external):
            result = framework.run_validation(subject, oracle_config=self.oracle_config(), output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "failed")
        self.assertGreater(result["summary"]["oracle_errors"], 0)

    def test_subject_process_failure_does_not_pass_negative_case(self):
        parsed = framework.parse_subject_output(b"", b"crash", -9)
        self.assertTrue(parsed["execution_failed"])
        self.assertEqual(parsed["category"], "process-error")

    def test_disagreements_are_retained_and_external_adjudications_not_rewritten(self):
        oracle = self.work / "oracle"
        oracle.write_text(f"#!{sys.executable}\nraise SystemExit(1)\n")
        oracle.chmod(0o700)
        with mock.patch.dict(os.environ, {"OPENJPEG_DECODER": str(oracle)}, clear=True):
            result = framework.run_validation(self.subject(), oracle_config=self.oracle_config(), output_dir=self.work)
            self.assertEqual(result["summary"]["status"], "blocked")
            self.assertTrue(result["disagreements"])
            external = self.work / "external-adjudications.json"
            adjudications = json.loads((self.work / "oracle-adjudications.json").read_text())
            for record in adjudications["records"]:
                record.update(status="adjudicated", decision="retain observation", rationale="synthetic fixture decision", adjudicator="unit test", adjudicated_at="2026-10-19T00:00:00Z")
            external.write_text(json.dumps(adjudications))
            before = external.read_bytes()
            result = framework.run_validation(self.subject(), oracle_config=self.oracle_config(), output_dir=self.work, adjudication_file=external)
        self.assertEqual(result["summary"]["status"], "passed")
        self.assertTrue(result["disagreements"])
        self.assertEqual(external.read_bytes(), before)
        framework.validate_evidence_schemas(self.work)

    def test_schema_check_does_not_require_existing_results(self):
        result = framework.validate_evidence_schemas(self.work)
        self.assertEqual(result["status"], "passed")
        self.assertEqual(result["reports"], [])

    def test_clean_clone_without_private_root_evidence_runs_all(self):
        clone = self.work / "source"
        clone.mkdir()
        for directory in ("src", "specs", "proofs", "examples", "validation"):
            shutil.copytree(framework.ROOT / directory, clone / directory, ignore=shutil.ignore_patterns("__pycache__", "results"))
        for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml"):
            shutil.copyfile(framework.ROOT / name, clone / name)
        root_json = {path.name for path in clone.glob("*.json")}
        self.assertEqual(root_json, set())
        self.assertTrue((clone / "validation/normative-coverage.json").is_file())
        self.assertTrue((clone / "validation/normative-coverage.schema.json").is_file())
        source_hashes = {
            path: framework.sha256_file(path)
            for path in clone.rglob("*") if path.is_file()
        }
        completed = subprocess.run(
            [sys.executable, str(clone / "validation/run-validation.py"), "all", "--no-external", "--subject", str(self.subject())],
            cwd=clone, capture_output=True, text=True,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertTrue((clone / "target/validation/validation-results.json").is_file())
        self.assertFalse((clone / "validation/results").exists())
        self.assertEqual(source_hashes, {path: framework.sha256_file(path) for path in source_hashes})

    def test_budget_output_is_bounded_and_limit_failure_cannot_pass(self):
        subject = self.work / "noisy-subject"
        subject.write_text(f"#!{sys.executable}\nprint('x' * 100000)\n")
        subject.chmod(0o700)
        result = framework.run_budget(subject, max_output_bytes=512, output_dir=self.work)
        self.assertEqual(result["summary"]["status"], "failed")
        self.assertTrue(any("output budget" in failure for failure in result["summary"]["failures"]))

    def test_official_unconfigured_is_explicitly_blocked(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            result = framework.run_official_vectors(output_dir=self.work)
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["acquisition"]["access_status"], "not-configured")
        self.assertEqual(result["records"], [])
        framework.validate_evidence_schemas(self.work)

    def test_official_manifest_execution_uses_hashes_and_redacts_private_identifiers(self):
        path, manifest = self.external_manifest()
        result = framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)
        self.assertEqual(result["status"], "passed")
        self.assertEqual(result["source_url"], manifest["suite"]["source_url"])
        self.assertFalse(result["license"]["redistribution_permitted"])
        serialized = json.dumps(result)
        self.assertNotIn("private-fixture-id", serialized)
        self.assertNotIn(str(self.work), serialized)
        framework.validate_evidence_schemas(self.work)

    def test_malformed_official_manifests_fail_before_execution(self):
        path, original = self.external_manifest()
        mutations = [
            lambda m: m["suite"].pop("license"),
            lambda m: m["suite"]["license"].update(redistribution_permitted=True),
            lambda m: m["suite"].update(acquired_at="not-a-date"),
            lambda m: m["entries"][0].update(path="../outside.j2k"),
            lambda m: m["entries"][0].update(sha256="invalid"),
            lambda m: m["entries"][0].update(expected={"accepted": True}),
            lambda m: m["entries"].append(copy.deepcopy(m["entries"][0])),
        ]
        for mutate in mutations:
            manifest = copy.deepcopy(original)
            mutate(manifest)
            path.write_text(json.dumps(manifest))
            with self.subTest(mutation=mutate), mock.patch.object(framework, "_run_process_bounded") as run:
                with self.assertRaises(ValueError):
                    framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)
                run.assert_not_called()
        path.write_text("{")
        with self.assertRaisesRegex(ValueError, "invalid external official vector manifest"):
            framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)

    def test_official_hash_mismatch_and_escaped_symlink_fail(self):
        path, manifest = self.external_manifest()
        (self.work / "vector.j2k").write_bytes(b"wrong")
        result = framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)
        self.assertEqual(result["status"], "failed")
        outside = self.work.parent / f"outside-{uuid.uuid4().hex}.j2k"
        outside.write_bytes(b"outside fixture")
        self.addCleanup(outside.unlink)
        (self.work / "vector.j2k").unlink()
        (self.work / "vector.j2k").symlink_to(outside)
        with self.assertRaisesRegex(ValueError, "escapes"):
            framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)

    def test_official_invalid_archive_never_executes_a_vector(self):
        path, _ = self.external_manifest()
        (self.work / "suite.bin").write_bytes(b"wrong archive")
        with mock.patch.object(framework, "_run_process_bounded") as run:
            result = framework.run_official_vectors(self.subject(), self.work, path, output_dir=self.work)
            run.assert_not_called()
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["summary"]["executed"], 0)


if __name__ == "__main__":
    unittest.main()
