import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


VALIDATION = Path(__file__).resolve().parents[1]
CONTROLLER = VALIDATION / "check-model-review-hold.py"
spec = importlib.util.spec_from_file_location("model_review_hold", CONTROLLER)
model_review_hold = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model_review_hold)


class ModelReviewHoldTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix="jpeg2000-model-hold-")
        self.addCleanup(directory.cleanup)
        self.repository = Path(directory.name)
        self.git("init", "--initial-branch=main")
        self.git("config", "user.name", "Model hold test")
        self.git("config", "user.email", "test@example.invalid")
        self.git("config", "commit.gpgsign", "false")
        self.git("config", "core.autocrlf", "false")
        self.write("src/lib.rs", "pub fn example() {}\n")
        self.write("specs/README.md", "# Guide\n")
        self.base = self.commit()

    def git(self, *arguments):
        return subprocess.run(
            ["git", "-C", str(self.repository), *arguments],
            check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        ).stdout.decode("utf-8").strip()

    def write(self, name, content):
        path = self.repository / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def commit(self):
        self.git("add", "--all")
        self.git("commit", "--message", "Fixture")
        return self.git("rev-parse", "HEAD")

    def run_controller(self, base, head):
        return subprocess.run(
            [sys.executable, str(CONTROLLER), "--repository", str(self.repository), "--", base, head],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )

    def test_surface_includes_targets_dependencies_and_controller(self):
        for path in (
            "src/lib.rs", "src/table.bin", "specs/new.rs", "specs/table.json",
            "proofs/shared/view.rs", "examples/decoder.rs", "other/model.rs",
            ".github/workflows/model-review-hold.yml", ".github/new-workflow.yml",
            ".cargo/config.toml", "Cargo.toml", "Cargo.lock", "fuzz/Cargo.toml",
            "rust-toolchain.toml", "rust-toolchain", "validation/framework.py",
            ".gitattributes", ".gitmodules",
            "validation/check-model-review-hold.py", "validation/normative-coverage.json",
            "validation/tests/test_model_review_hold.py",
        ):
            with self.subTest(path=path):
                self.assertTrue(model_review_hold.held_path(path))
        for path in ("README.md", "PROOFS.md", "specs/README.md", "specs/AUDIT_REFERENCE.md",
                     "validation/VALIDATION.md", "proofs/README.md"):
            with self.subTest(path=path):
                self.assertFalse(model_review_hold.held_path(path))

    def test_documentation_change_passes(self):
        self.write("specs/README.md", "# Improved guide\n")
        self.write("specs/AUDIT_REFERENCE.md", "# Existing detail\n")
        result = self.run_controller(self.base, self.commit())
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PASS: no unapproved changes", result.stdout)

    def test_source_change_is_held(self):
        self.write("src/lib.rs", "pub fn changed() {}\n")
        result = self.run_controller(self.base, self.commit())
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn("'src/lib.rs'", result.stdout)

    def test_new_target_is_held(self):
        self.write("specs/new.rs", "pub spec fn weakened() -> bool { true }\n")
        self.assertEqual(
            model_review_hold.held_changes(self.repository, self.base, self.commit()),
            ["specs/new.rs"],
        )

    def test_source_deletion_is_held(self):
        (self.repository / "src/lib.rs").unlink()
        self.assertEqual(
            model_review_hold.held_changes(self.repository, self.base, self.commit()),
            ["src/lib.rs"],
        )

    def test_rename_to_documentation_does_not_hide_source_removal(self):
        self.git("mv", "src/lib.rs", "source.md")
        self.assertEqual(
            model_review_hold.held_changes(self.repository, self.base, self.commit()),
            ["src/lib.rs"],
        )

    def test_candidate_controller_cannot_approve_its_own_model_change(self):
        self.write("validation/check-model-review-hold.py", "raise SystemExit(0)\n")
        self.write("src/lib.rs", "pub fn changed() {}\n")
        result = self.run_controller(self.base, self.commit())
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn("'src/lib.rs'", result.stdout)
        self.assertIn("'validation/check-model-review-hold.py'", result.stdout)

    def test_workflow_only_change_is_held(self):
        self.write(".github/workflows/model-review-hold.yml", "jobs: {}\n")
        result = self.run_controller(self.base, self.commit())
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn("'.github/workflows/model-review-hold.yml'", result.stdout)

    def test_unrelated_base_progress_is_not_a_proposed_change(self):
        self.write("specs/README.md", "# Improved guide\n")
        head = self.commit()
        self.git("checkout", "-b", "target-progress", self.base)
        self.write("src/lib.rs", "pub fn unrelated_base_change() {}\n")
        base = self.commit()
        result = self.run_controller(base, head)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_uncommitted_files_do_not_replace_committed_evidence(self):
        self.write("src/lib.rs", "pub fn changed() {}\n")
        head = self.commit()
        self.write("src/lib.rs", "pub fn example() {}\n")
        result = self.run_controller(self.base, head)
        self.assertEqual(result.returncode, 1, result.stderr)

    def test_empty_change_passes(self):
        result = self.run_controller(self.base, self.base)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_incomplete_or_option_shaped_commit_ids_are_errors(self):
        for value in (self.base[:8], "--no-index", "0" * 39, "z" * 40):
            with self.subTest(value=value):
                result = self.run_controller(value, self.base)
                self.assertEqual(result.returncode, 2)
                self.assertIn("expected a full SHA-1 commit ID", result.stderr)

    def test_missing_history_is_an_error_not_an_allowed_change(self):
        result = self.run_controller(self.base, "0" * 40)
        self.assertEqual(result.returncode, 2)
        self.assertIn("could not read", result.stderr)

    def test_unrelated_histories_are_an_error_not_an_allowed_change(self):
        self.git("checkout", "--orphan", "unrelated")
        self.write("specs/README.md", "# Unrelated root commit\n")
        head = self.commit()
        result = self.run_controller(self.base, head)
        self.assertEqual(result.returncode, 2)
        self.assertIn("could not read", result.stderr)

    def test_multiple_merge_bases_are_an_error(self):
        tree = self.git("rev-parse", self.base + "^{tree}")
        left = self.git("commit-tree", tree, "-p", self.base, "-m", "Left")
        right = self.git("commit-tree", tree, "-p", self.base, "-m", "Right")
        base = self.git("commit-tree", tree, "-p", left, "-p", right, "-m", "Left merge")
        head = self.git("commit-tree", tree, "-p", right, "-p", left, "-m", "Right merge")
        result = self.run_controller(base, head)
        self.assertEqual(result.returncode, 2)
        self.assertIn("exactly one merge base", result.stderr)

    def test_git_paths_are_nul_delimited_not_line_delimited(self):
        name = "specs/name\npart.rs"
        with patch.object(model_review_hold, "git", side_effect=[
            self.base.encode("ascii") + b"\n",
            name.encode("utf-8") + b"\0specs/README.md\0",
        ]):
            self.assertEqual(
                model_review_hold.held_changes(self.repository, self.base, self.base),
                [name],
            )


    def registry(self, entries):
        directory = tempfile.TemporaryDirectory(prefix="jpeg2000-trusted-registry-")
        self.addCleanup(directory.cleanup)
        path = Path(directory.name) / "registry.md"
        path.write_text(
            "# Trusted fixture\n\n```json\n"
            + json.dumps({"schema_version": 1, "amendments": entries})
            + "\n```\n", encoding="utf-8",
        )
        return path

    def consumer_fixture(self):
        workflow = ".github/workflows/ci.yml"
        self.write(workflow, "jobs: original\n")
        base = self.commit()
        for path in model_review_hold.AMENDMENT_PROFILES["image-consumer-probe"]:
            self.write(path, "checked consumer fixture\n")
        head = self.commit()
        entry = {
            "id": "consumer-fixture",
            "profile": "image-consumer-probe",
            "source_pr": 164, "source_head": head, "ci_run": 1, "verus_run": 2,
            "rationale": "Bounded standalone consumer, not a normative amendment.",
            "paths": {
                path: {
                    "before": self.git("rev-parse", f"{base}:{path}") if path == workflow else None,
                    "after": self.git("rev-parse", f"{head}:{path}"),
                }
                for path in model_review_hold.AMENDMENT_PROFILES["image-consumer-probe"]
            },
        }
        return base, head, entry

    def test_repository_registry_is_valid(self):
        self.assertIsInstance(
            model_review_hold.read_reviewed_amendments(CONTROLLER.parent / "reviewed-amendments.md"),
            list,
        )

    def test_exact_trusted_record_passes(self):
        base, head, entry = self.consumer_fixture()
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertEqual(model_review_hold.held_changes(self.repository, base, head), [])

    def test_candidate_record_cannot_authorize_its_source(self):
        base, _, entry = self.consumer_fixture()
        self.write("validation/reviewed-amendments.md",
                   "```json\n" + json.dumps({"schema_version": 1, "amendments": [entry]}) + "\n```\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([])):
            self.assertEqual(
                set(model_review_hold.held_changes(self.repository, base, self.commit())),
                set(entry["paths"]),
            )

    def test_registry_only_proposal_can_pass_before_review(self):
        self.write("validation/reviewed-amendments.md", "proposed policy data\n")
        self.assertEqual(model_review_hold.held_changes(self.repository, self.base, self.commit()), [])

    def test_documentation_can_repair_invalid_trusted_registry(self):
        path = self.registry([])
        path.write_text("invalid trusted data\n", encoding="utf-8")
        self.write("validation/reviewed-amendments.md", "repaired proposed data\n")
        with patch.object(model_review_hold, "REGISTRY", path):
            self.assertEqual(model_review_hold.held_changes(self.repository, self.base, self.commit()), [])

    def test_extra_model_is_held_despite_trusted_consumer_record(self):
        base, _, entry = self.consumer_fixture()
        self.write("specs/new.rs", "pub spec fn weakened() -> bool { true }\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertIn("specs/new.rs",
                          model_review_hold.held_changes(self.repository, base, self.commit()))

    def test_changed_consumer_source_is_held(self):
        base, _, entry = self.consumer_fixture()
        path = "validation/image-consumer-probe/src/decoder.rs"
        self.write(path, "changed consumer\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertIn(path, model_review_hold.held_changes(self.repository, base, self.commit()))

    def test_changed_workflow_is_held(self):
        base, _, entry = self.consumer_fixture()
        self.write(".github/workflows/ci.yml", "changed workflow\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertIn(".github/workflows/ci.yml",
                          model_review_hold.held_changes(self.repository, base, self.commit()))

    def test_missing_consumer_file_is_held(self):
        base, _, entry = self.consumer_fixture()
        (self.repository / "validation/image-consumer-probe/Cargo.lock").unlink()
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertTrue(model_review_hold.held_changes(self.repository, base, self.commit()))

    def test_wrong_original_blob_is_held(self):
        base, head, entry = self.consumer_fixture()
        entry["paths"][".github/workflows/ci.yml"]["before"] = "0" * 40
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertTrue(model_review_hold.held_changes(self.repository, base, head))

    def test_original_absence_is_required(self):
        base, head, entry = self.consumer_fixture()
        self.git("checkout", "-b", "different-original", base)
        self.write("validation/image-consumer-probe/Cargo.toml", "preexisting\n")
        other_base = self.commit()
        for path in entry["paths"]:
            self.write(path, self.git("show", f"{head}:{path}") + "\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertTrue(model_review_hold.held_changes(self.repository, other_base, self.commit()))

    def test_executable_mode_is_held(self):
        base, _, entry = self.consumer_fixture()
        path = "validation/image-consumer-probe/src/decoder.rs"
        self.git("update-index", "--chmod=+x", path)
        self.git("commit", "--message", "Change mode")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertIn(path, model_review_hold.held_changes(
                self.repository, base, self.git("rev-parse", "HEAD")))

    def test_controller_cannot_be_combined_with_authorized_source(self):
        base, _, entry = self.consumer_fixture()
        self.write("validation/check-model-review-hold.py", "raise SystemExit(0)\n")
        with patch.object(model_review_hold, "REGISTRY", self.registry([entry])):
            self.assertIn("validation/check-model-review-hold.py",
                          model_review_hold.held_changes(self.repository, base, self.commit()))

    def test_separate_records_do_not_authorize_combined_changes(self):
        base, _, consumer = self.consumer_fixture()
        paths = model_review_hold.AMENDMENT_PROFILES["source-complete-package"]
        for path in paths:
            self.write(path, "package fixture\n")
        head = self.commit()
        package = dict(consumer, id="package-fixture", profile="source-complete-package",
                       source_head=head, paths={
                           path: {"before": None, "after": self.git("rev-parse", f"{head}:{path}")}
                           for path in paths
                       })
        with patch.object(model_review_hold, "REGISTRY", self.registry([consumer, package])):
            self.assertTrue(model_review_hold.held_changes(self.repository, base, head))

    def test_malformed_missing_multiple_or_duplicate_json_is_rejected(self):
        for text in (
            "no JSON\n", "```json\n{\n```\n",
            '```json\n{"schema_version":1,"schema_version":1,"amendments":[]}\n```\n',
            '```json\n{"schema_version":1,"amendments":[]}\n```\n' * 2,
        ):
            with self.subTest(text=text):
                path = self.registry([])
                path.write_text(text, encoding="utf-8")
                with self.assertRaises(ValueError):
                    model_review_hold.read_reviewed_amendments(path)

    def test_record_schema_rejects_flags_unknown_profiles_and_normative_paths(self):
        _, _, original = self.consumer_fixture()
        for change in (
            lambda entry: entry.update(approved=True),
            lambda entry: entry.pop("ci_run"),
            lambda entry: entry.update(profile="normative-model"),
            lambda entry: entry["paths"].update({"specs/new.rs": {"before": None, "after": "a" * 40}}),
            lambda entry: entry["paths"].update({"validation/check-model-review-hold.py": {"before": None, "after": "a" * 40}}),
            lambda entry: entry.update(source_pr=True),
            lambda entry: entry.update(verus_run=0),
            lambda entry: entry.update(source_head="short"),
            lambda entry: entry.update(rationale=" "),
        ):
            entry = copy.deepcopy(original)
            change(entry)
            with self.assertRaises(ValueError):
                model_review_hold.read_reviewed_amendments(self.registry([entry]))

    def test_invalid_or_unchanged_blob_identities_are_rejected(self):
        _, _, original = self.consumer_fixture()
        path = ".github/workflows/ci.yml"
        for identities in (
            {"before": "short", "after": "a" * 40},
            {"before": None, "after": None},
            {"before": "a" * 40, "after": "a" * 40},
            {"before": None, "after": "z" * 40},
            {"before": None, "after": "a" * 40, "approved": True},
        ):
            entry = copy.deepcopy(original)
            entry["paths"][path] = identities
            with self.assertRaises(ValueError):
                model_review_hold.read_reviewed_amendments(self.registry([entry]))

    def test_invalid_envelopes_and_duplicate_record_ids_are_rejected(self):
        _, _, entry = self.consumer_fixture()
        with self.assertRaises(ValueError):
            model_review_hold.read_reviewed_amendments(self.registry([entry, entry]))
        for data in (
            [], {"schema_version": True, "amendments": []},
            {"schema_version": 2, "amendments": []},
            {"schema_version": 1, "amendments": {}},
            {"schema_version": 1, "amendments": [], "approved": True},
        ):
            path = self.registry([])
            path.write_text("```json\n" + json.dumps(data) + "\n```\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                model_review_hold.read_reviewed_amendments(path)

    def test_missing_or_symlink_registry_is_rejected(self):
        path = self.registry([])
        missing = path.with_name("missing.md")
        with self.assertRaises(ValueError):
            model_review_hold.read_reviewed_amendments(missing)
        link = path.with_name("linked.md")
        link.symlink_to(path)
        with self.assertRaises(ValueError):
            model_review_hold.read_reviewed_amendments(link)

    def test_invalid_trusted_registry_causes_explicit_cli_failure(self):
        self.write("src/lib.rs", "pub fn changed() {}\n")
        head = self.commit()
        with tempfile.TemporaryDirectory(prefix="jpeg2000-controller-cli-") as directory:
            controller = Path(directory) / "validation/check-model-review-hold.py"
            controller.parent.mkdir()
            controller.write_text(CONTROLLER.read_text(), encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(controller), "--repository", str(self.repository),
                 self.base, head], capture_output=True, text=True,
            )
        self.assertEqual(result.returncode, 2)
        self.assertIn("trusted amendment registry must be a regular file", result.stderr)


if __name__ == "__main__":
    unittest.main()
